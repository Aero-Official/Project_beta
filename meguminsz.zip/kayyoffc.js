/*subscribe Yt gw Dong 

Udh no Enc G Subscribe parah !

@DitzzXploit

Don't for sale !*/
process.on('uncaughtException', console.error)
require('./setting')
const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageContent, generateWAMessage, downloadContentFromMessage, areJidsSameUser, getContentType } = global.baileys
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys")
const fs = require('fs')
const { handleDashboard, handleKerja} = require ('./kerja.js')
const { Suntik } = require( './lib/Suntik_web.js')
const path = require('path');
const fetch = require('node-fetch');
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const speed = require('performance-now')
const axios = require('axios')
const fsx = require('fs-extra')
const mark = `0@s.whatsapp.net`
const dns = require('dns');
const FormData = require('form-data')
const gtts = require('node-gtts')
const ytdl = require("ytdl-core")
const cheerio = require('cheerio');
const ms = require("ms");
const crypto = require('crypto')
const https = require('https')
const yts = require("yt-search")
const { cerpen } = require('./lib/cerpen')
const { exec, spawn, execSync } = require("child_process")
const LINODE_API_TOKEN = global.apilinode;
const API_TOKEN = global.apitokendo;
const moment = require('moment-timezone')
const { smsg, tanggal, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, formatp, parseMention, getRandom, getGroupAdmins } = require('./lib/myfunc')
const { remini, jarak, ssweb, tiktok, PlayStore, BukaLapak, pinterest, stickersearch, lirik, webp2mp4File } = require("./lib/skraper")
const from = mek.key.remoteJid
//==================================================//
const thumb = fs.readFileSync ('./baseikal/image/mamak.jpg')
const vnnye = JSON.parse(fs.readFileSync('./database/vnadd.json'))
const docunye = JSON.parse(fs.readFileSync('./database/docu.json'))
const zipnye = JSON.parse(fs.readFileSync('./database/zip.json'))
const apknye = JSON.parse(fs.readFileSync('./database/apk.json'))
const pengguna = JSON.parse(fs.readFileSync('./baseikal/dbnye/wihh.json'))
const prem = require("./lib/premium");
let premium = JSON.parse(fs.readFileSync('./database/premium.json'));
const xeonverifieduser = JSON.parse(fs.readFileSync('./baseikal/dbnye/wihh.json'))
const ntilink = JSON.parse(fs.readFileSync("./lib/antilink.json"))
const banned = JSON.parse(fs.readFileSync('./baseikal/dbnye/banned.json'))
//==================================================//
module.exports = kayyoffc = async (kayyoffc, m, chatUpdate, store) => {
 try {
var body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'interactiveResponseMessage') ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'templateButtonReplyMessage') ? m.msg.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''

//WM By Rulzz, Titenono lek ko hapus le😹
var budy = (typeof m.text == 'string' ? m.text : '')
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.'
//=================================================//

const Styles = (text, style = 1) => {
  var xStr = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
  var yStr = {
    1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
  };
  var replacer = [];
  xStr.map((v, i) =>
    replacer.push({
      original: v,
      convert: yStr[style].split('')[i]
    })
  );
  var str = text.toLowerCase().split('');
  var output = [];
  str.map((v) => {
    const find = replacer.find((x) => x.original == v);
    find ? output.push(find.convert) : output.push(v);
  });
  return output.join('');
};

const pushname = m.pushName || "No Name"


function getFormattedDate() {
  var currentDate = new Date();
  var day = currentDate.getDate();
  var month = currentDate.getMonth() + 1;
  var year = currentDate.getFullYear();
  var hours = currentDate.getHours();
  var minutes = currentDate.getMinutes();
  var seconds = currentDate.getSeconds();
}





   // Daftar hewan untuk setiap daerah
   const animals = {
       forest: [
           { name: '🐻 Beruang', max: 35 },
           { name: '🦊 Rubah', max: 35 },
           { name: '🐿 Tupai', max: 35 },
           { name: '🦉 Burung Hantu', max: 35 },
           { name: '🐺 Serigala', max: 35 },
           { name: '🦌 Rusa', max: 35 },
           { name: '🐦 Burung', max: 35 },
           { name: '🦒 Jerapah', max: 35 },
           { name: '🦓 Zebra', max: 35 },
           { name: '🐒 Kera', max: 35 },
       ],
       snow: [
           { name: '🐻 Beruang Kutub', max: 35 },
           { name: '🐾 Serigala', max: 35 },
           { name: '🦅 Elang', max: 35 },
           { name: '🐧 Penguin', max: 35 },
           { name: '🦦 Musang', max: 35 },
           { name: '🐰 Kelinci', max: 35 },
           { name: '🦄 Unicorn', max: 35 },
           { name: '🦏 Badak', max: 35 },
           { name: '🐨 Koala', max: 35 },
           { name: '🐼 Panda', max: 35 },
       ],
       bamboo: [
           { name: '🐼 Panda', max: 35 },
           { name: '🐻 Beruang', max: 35 },
           { name: '🐦 Burung', max: 35 },
           { name: '🐍 Ular', max: 35 },
           { name: '🐒 Kera', max: 35 },
           { name: '🐭 Tikus', max: 35 },
           { name: '🦘 Kanguru', max: 35 },
           { name: '🐅 Harimau', max: 35 },
           { name: '🦚 Merak', max: 35 },
           { name: '🐗 Babi Hutan', max: 35 },
       ],
       sungai: [
           { name: '🐟 Ikan', max: 35 },
           { name: '🐊 Buaya', max: 35 },
           { name: '🐸 Katak', max: 35 },
           { name: '🦐 Udang', max: 35 },
           { name: '🐢 Penyu', max: 35 },
           { name: '🦈 Hiu', max: 35 },
           { name: '🐠 Ikan Kecil', max: 35 },
           { name: '🐡 Ikan Puffer', max: 35 },
           { name: '🦑 Cumi-cumi', max: 35 },
           { name: '🦈 Paus', max: 35 },
       ],
   };


   

   // Variabel untuk menyimpan data hunts saat ini
   let currentHunts = [];

   let response;


   // Mengirim respons ke pengguna
   console.log(response);

   // Lokasi file PokeDex
const pokeDexFilePath = path.join(__dirname, './poke/pokedex.json');

// Memastikan file pokedex.json ada dan memiliki data yang valid
let pokeDex = {};

// Membaca data dari file saat bot dimulai
if (fs.existsSync(pokeDexFilePath)) {
 const data = fs.readFileSync(pokeDexFilePath, 'utf8');
 pokeDex = JSON.parse(data || '{}'); // Memuat data dari file jika ada
}

// Fungsi untuk menyimpan data PokeDex ke file
function savePokeDex() {
 fs.writeFileSync(pokeDexFilePath, JSON.stringify(pokeDex, null, 2), 'utf8');
}
   // Path untuk file JSON tempat menyimpan DigiTamers
const digiTamersFilePath = path.join(__dirname, './digi/digiTamers.json');
let digiTamers = {};

// Membaca data DigiTamers dari file
if (fs.existsSync(digiTamersFilePath)) {
 const data = fs.readFileSync(digiTamersFilePath, 'utf8');
 digiTamers = JSON.parse(data || '{}');
}

// Fungsi untuk menyimpan data DigiTamers ke file
function saveDigiTamers() {
 fs.writeFileSync(digiTamersFilePath, JSON.stringify(digiTamers, null, 2), 'utf8');
}
   // Pastikan file dan folder ada
const ensureFileExists = (filePath) => {
 const dir = path.dirname(filePath);
 if (!fs.existsSync(dir)) {
 fs.mkdirSync(dir, { recursive: true });
 }
 if (!fs.existsSync(filePath)) {
 fs.writeFileSync(filePath, JSON.stringify({}), 'utf-8');
 }
};

// File paths
const expFilePath = './hunter/exp.json';
const jobsFilePath = './dashboard/pekerjaan.json';

// Ensure files exist
ensureFileExists(expFilePath);
ensureFileExists(jobsFilePath);

// Sample jobs
  const jobs = [
   { name: 'Pengemis', rank: 'perunggu', exp: { min: 5, max: 15 } },
   { name: 'Office Worker', rank: 'silver', exp: { min: 20, max: 30 } },
   { name: 'Manager', rank: 'platinum', exp: { min: 50, max: 75 } },
   { name: 'Programmer', rank: 'gold', exp: { min: 35, max: 50 } },
   { name: 'Designer', rank: 'silver', exp: { min: 20, max: 30 } },
   { name: 'Petinju', rank: 'silver', exp: { min: 25, max: 35 } },
   { name: 'Polisi', rank: 'platinum', exp: { min: 60, max: 85 } },
   { name: 'Pengangguran', rank: 'Kayu', exp: { min: 1, max: 2 } },
   { name: 'Militer', rank: 'diamond', exp: { min: 100, max: 450 } },
   { name: 'Astronot', rank: 'diamond', exp: { min: 200, max: 600 } },
   { name: 'Ilmuwan', rank: 'diamond', exp: { min: 400, max: 590 } },
   { name: 'Kurir', rank: 'silver', exp: { min: 40, max: 70 } },
   { name: 'pemburu', rank: 'gold', exp: { min: 35, max: 45 } },
   { name: 'penyanyi', rank: 'platinum', exp: { min: 65, max: 70 } },
   { name: 'Wali Kota', rank: 'diamond', exp: { min: 600, max: 900 } },
   { name: 'aktris', rank: 'gold', exp: { min: 70, max: 100 } },
   { name: 'dukun', rank: 'neraka', exp: { min: 0, max: 0 } },
   { name: 'Rentenir', rank: 'silver', exp: { min: 57, max: 88 } },
   { name: 'Presiden', rank: 'Emerald Pentagram', exp: { min: 900, max: 2000 } }
   ]
   // Function to select a random job
function selectRandomJob() {
 const randomIndex = Math.floor(Math.random() * jobs.length);
 return jobs[randomIndex];
}

// Function to get random experience based on rank
function getRandomExp(rank) {
 const job = jobs.find(j => j.rank === rank);
 return Math.floor(Math.random() * (job.exp.max - job.exp.min + 1)) + job.exp.min;
}
let activateGames = {};
// Function to generate random credit card
function generateRandomCard() {
 return Math.random().toString(36).slice(2, 10).toUpperCase();
}
function monospace(string) {

return '```' + string + '```'

}
function encodeURIComponent(str) {

    return str.replace(/[^a-zA-Z0-9-_.~]/g, function(c) {

        return '%' + c.charCodeAt(0).toString(16);

    });

}
// susunkata
// tictactoe
this.game = this.game ? this.game : {}
let room = Object.values(this.game).find(room => room.id && room.game && room.state && room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender) && room.state == 'PLAYING')
if (room) {
let ok
let isWin = !1
let isTie = !1
let isSurrender = !1
// m.reply(`[DEBUG]\n${parseInt(m.text)}`)
if (!/^([1-9]|(me)?nyerah|surr?ender|off|skip)$/i.test(m.text)) return
isSurrender = !/^[1-9]$/.test(m.text)
if (m.sender !== room.game.currentTurn) { // nek wayahku
if (!isSurrender) return !0
}
if (!isSurrender && 1 > (ok = room.game.turn(m.sender === room.game.playerO, parseInt(m.text) - 1))) {
m.reply({
'-3': 'Game telah berakhir',
'-2': 'Invalid',
'-1': 'Posisi Invalid',
0: 'Posisi Invalid',
}[ok])
return !0
}
if (m.sender === room.game.winner) isWin = true
else if (room.game.board === 511) isTie = true
let arr = room.game.render().map(v => {
return {
X: '❌',
O: '⭕',
1: '1️⃣',
2: '2️⃣',
3: '3️⃣',
4: '4️⃣',
5: '5️⃣',
6: '6️⃣',
7: '7️⃣',
8: '8️⃣',
9: '9️⃣',
}[v]
})
if (isSurrender) {
room.game._currentTurn = m.sender === room.game.playerX
isWin = true
}
let winner = isSurrender ? room.game.currentTurn : room.game.winner
let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

${isWin ? `@${winner.split('@')[0]} Menang!` : isTie ? `Game berakhir` : `Giliran ${['❌', '⭕'][1 * room.game._currentTurn]} (@${room.game.currentTurn.split('@')[0]})`}
❌: @${room.game.playerX.split('@')[0]}
⭕: @${room.game.playerO.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
if ((room.game._currentTurn ^ isSurrender ? room.x : room.o) !== from)
room[room.game._currentTurn ^ isSurrender ? 'x' : 'o'] = from
if (room.x !== room.o) await kayyoffc.sendText(room.x, str, m, { mentions: parseMention(str) } )
await kayyoffc.sendText(room.o, str, m, { mentions: parseMention(str) } )
if (isTie || isWin) {
delete this.game[room.id]
}
}

//Suit PvP
this.suit = this.suit ? this.suit : {}
let roof = Object.values(this.suit).find(roof => roof.id && roof.status && [roof.p, roof.p2].includes(m.sender))
if (roof) {
let win = ''
let tie = false
if (m.sender == roof.p2 && /^(acc(ept)?|terima|gas|oke?|tolak|gamau|nanti|ga(k.)?bisa|y)/i.test(m.text) && m.isGroup && roof.status == 'wait') {
if (/^(tolak|gamau|nanti|n|ga(k.)?bisa)/i.test(m.text)) {
kayyoffc.sendTextWithMentions(from, `@${roof.p2.split`@`[0]} menolak suit, suit dibatalkan`, m)
delete this.suit[roof.id]
return !0
}
roof.status = 'play'
roof.asal = from
clearTimeout(roof.waktu)
//delete roof[roof.id].waktu
kayyoffc.sendText(from, `Suit telah dikirimkan ke chat

@${roof.p.split`@`[0]} dan 
@${roof.p2.split`@`[0]}

Silahkan pilih suit di chat masing"
klik https://wa.me/${botNumber.split`@`[0]}`, m, { mentions: [roof.p, roof.p2] })
if (!roof.pilih) kayyoffc.sendText(roof.p, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
if (!roof.pilih2) kayyoffc.sendText(roof.p2, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
roof.waktu_milih = setTimeout(() => {
if (!roof.pilih && !roof.pilih2) kayyoffc.sendText(from, `Kedua pemain tidak niat main,\nSuit dibatalkan`)
else if (!roof.pilih || !roof.pilih2) {
win = !roof.pilih ? roof.p2 : roof.p
kayyoffc.sendTextWithMentions(from, `@${(roof.pilih ? roof.p2 : roof.p).split`@`[0]} tidak memilih suit, game berakhir`, m)
}
delete this.suit[roof.id]
return !0
}, roof.timeout)
}
let jwb = m.sender == roof.p
let jwb2 = m.sender == roof.p2
let g = /gunting/i
let b = /batu/i
let k = /kertas/i
let reg = /^(gunting|batu|kertas)/i
if (jwb && reg.test(m.text) && !roof.pilih && !m.isGroup) {
roof.pilih = reg.exec(m.text.toLowerCase())[0]
roof.text = m.text
m.reply(`Kamu telah memilih ${m.text} ${!roof.pilih2 ? `\n\nMenunggu lawan memilih` : ''}`)
if (!roof.pilih2) kayyoffc.sendText(roof.p2, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
}
if (jwb2 && reg.test(m.text) && !roof.pilih2 && !m.isGroup) {
roof.pilih2 = reg.exec(m.text.toLowerCase())[0]
roof.text2 = m.text
m.reply(`Kamu telah memilih ${m.text} ${!roof.pilih ? `\n\nMenunggu lawan memilih` : ''}`)
if (!roof.pilih) kayyoffc.sendText(roof.p, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
}
let stage = roof.pilih
let stage2 = roof.pilih2
if (roof.pilih && roof.pilih2) {
clearTimeout(roof.waktu_milih)
if (b.test(stage) && g.test(stage2)) win = roof.p
else if (b.test(stage) && k.test(stage2)) win = roof.p2
else if (g.test(stage) && k.test(stage2)) win = roof.p
else if (g.test(stage) && b.test(stage2)) win = roof.p2
else if (k.test(stage) && b.test(stage2)) win = roof.p
else if (k.test(stage) && g.test(stage2)) win = roof.p2
else if (stage == stage2) tie = true
kayyoffc.sendText(roof.asal, `_*Hasil Suit*_${tie ? '\nSERI' : ''}

@${roof.p.split`@`[0]} (${roof.text}) ${tie ? '' : roof.p == win ? ` Menang \n` : ` Kalah \n`}
@${roof.p2.split`@`[0]} (${roof.text2}) ${tie ? '' : roof.p2 == win ? ` Menang \n` : ` Kalah \n`}
`.trim(), m, { mentions: [roof.p, roof.p2] })
delete this.suit[roof.id]
}
}
// Function to periodically give experience
setInterval(() => {
 const expData = JSON.parse(fs.readFileSync(expFilePath));
 for (const userId in expData) {
 if (expData[userId].job) {
 const rank = expData[userId].job.rank;
 const additionalExp = 25; // Average income every 5 minutes
 expData[userId].exp += additionalExp;
 }
 }
 fs.writeFileSync(expFilePath, JSON.stringify(expData, null, 2));
}, 5 * 60 * 1000);
   
//=================================================//
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''//Kalau mau Single prefix Lu ganti pake ini = const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const botNumber = await kayyoffc.decodeJid(kayyoffc.user.id)
const isCreator = [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const text = q = args.join(" ")
const { type, quotedMsg, mentioned, now, fromMe } = m
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const isMedia = /image|video|sticker|audio/.test(mime)
const from = mek.key.remoteJid
const groupMetadata = m.isGroup ? await kayyoffc.groupMetadata(from).catch(e => {}) : ''
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const welcm = m.isGroup ? wlcm.includes(from) : false
const welcmm = m.isGroup ? wlcmm.includes(from) : false
const AntiLink = m.isGroup ? ntilink.includes(from) : false 
const Jpm = m.isGroup ? ntilink.includes(from) : false 
const isBan = banned.includes(m.sender)
const isPrem = isCreator ? true : prem.checkPremiumUser(m.sender, premium)
const content = JSON.stringify(m.message)
const numberQuery = text.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net"
const mentionByTag = m.mtype == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.mentionedJid : []
//const Input = mentionByTag[0] ? mentionByTag[0] : q ? numberQuery : false
const mentionByReply = type == 'extendedTextMessage' && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.participant || '' : ''
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const time2 = moment().tz('Asia/Kolkata').format('HH:mm:ss')  
if(time2 < "23:59:00"){
var stime = Styles(`Good Night`)
 }
 if(time2 < "19:00:00"){
var stime = Styles(`Good Evening`)
 }
 if(time2 < "18:00:00"){
var stime = Styles(`Good Evening`)
 }
 if(time2 < "15:00:00"){
var stime = Styles(`Good Afternoon`)
 }
 if(time2 < "11:00:00"){
var stime = Styles(`Good Morning`)
 }
 if(time2 < "05:00:00"){
var stime = Styles(`Good Morning`)
 }

     let timeout = 180000; // 3 menit

let money = 5000;

let limit = 1;
const salam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
const tanggal2 = moment.tz('Asia/Jakarta').format('DD/MM/YY')
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')	
const qtod = m.quoted? "true":"false"
const bii = JSON.parse(fs.readFileSync('./baseikal/dbnye/wihh.json').toString())
const isSeler = [botNumber, ...bii].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const jangan = m.isGroup ? ntilink.includes(m.chat) : false	
//=================================================//
// FUNCTION



  
    





        



      

          
      
        



const ments = (teks) => {return teks.match('@') ? [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : [sender]}

const fcall = { key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast"} : {}) },'message': {extendedTextMessage: {text: body}}}

const reply = async(teks) => {kayyoffc.sendMessage(from, {text: teks, mentions: await ments(teks)},{quoted:fcall})}

kayyoffc.autoshalat = kayyoffc.autoshalat ? kayyoffc.autoshalat : {}
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? kayyoffc.user.id : m.sender
  let id = m.chat 
    if(id in kayyoffc.autoshalat) {
    return false
    }
    let jadwalSholat = {
    shubuh: '04:29',
    terbit: '05:44',
    dhuha: '06:02',
    dzuhur: '12:02',
    ashar: '15:15',
    magrib: '17:52',
    isya: '19:01',
    }
    const datek = new Date((new Date).toLocaleString("en-US", {
    timeZone: "Asia/Jakarta"  
    }));
    const hours = datek.getHours();
    const minutes = datek.getMinutes();
    const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
    for(let [sholat, waktu] of Object.entries(jadwalSholat)) {
    if(timeNow === waktu) {
    let caption = `Hai kak ${pushname},\nWaktu *${sholat}* telah tiba, ambilah air wudhu dan segeralah shalat🙂.\n\n*${waktu}*\n_untuk wilayah Makassar dan sekitarnya._`
    kayyoffc.autoshalat[id] = [
    reply(caption),
    setTimeout(async () => {
    delete kayyoffc.autoshalat[m.chat]
    }, 57000)
    ]
    }
    }

const totalFitur = () =>{
            var mytext = fs.readFileSync("./kayyoffc.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }

const { queryString } = require('object-query-string')

const photoOxy = (url, text) => new Promise((resolve, reject) => {

  axios({

    method: 'GET',

    url: url,

    headers: {

      'user-agent': 'Mozilla/5.0 (Linux; Android 9; Redmi 7A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.99 Mobile Safari/537.36'

    }

  })

  .then(({ data, headers }) => {

    const token = /<input type="hidden" name="token" value="(.*?)" id="token">/.exec(data)[1]

    const build_server = /<input type="hidden" name="build_server" value="(.*?)" id="build_server">/.exec(data)[1]

    const build_server_id = /<input type="hidden" name="build_server_id" value="(.*?)" id="build_server_id">/.exec(data)[1]

    const cookie = headers['set-cookie'][0]

    const form = new FormData()

    if (typeof text === 'string') text = [text]

    for (let texts of text) form.append('text[]', texts)

    form.append('sumbit', 'GO')

    form.append('token', token)

    form.append('build_server', build_server)

    form.append('build_server_id', build_server_id)

    axios({

      method: 'POST',

      url: url,

      data: form,

      headers: {

        'user-agent': 'Mozilla/5.0 (Linux; Android 9; Redmi 7A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.99 Mobile Safari/537.36',

        'cookie': cookie,

        ...form.getHeaders()

      }

    })

    .then(({ data }) => {

      const form_value = /<div.*?id = "form_value".+>(.*?)<\/div>/.exec(data)[1]

      axios({

        method: 'GET',

        url: 'https://photooxy.com/effect/create-image?' + queryString(JSON.parse(form_value)),

        headers: {

          'user-agent': 'Mozilla/5.0 (Linux; Android 9; Redmi 7A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.99 Mobile Safari/537.36',

          'cookie': cookie

        }

      })

      .then(({ data }) => {

        resolve(build_server + data.image)

      })

      .catch(reject)

    })

    .catch(reject)

  })

  .catch(reject)

})


        
          

async function dellCase(filePath, caseNameToRemove) {
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Terjadi kesalahan:', err);
            return;
        }

        const regex = new RegExp(`case\\s+'${caseNameToRemove}':[\\s\\S]*?break`, 'g');
        const modifiedData = data.replace(regex, '');

        fs.writeFile(filePath, modifiedData, 'utf8', (err) => {
            if (err) {
                console.error('Terjadi kesalahan saat menulis file:', err);
                return;
            }

            console.log(`Teks dari case '${caseNameToRemove}' telah dihapus dari file.`);
        });
    });
}

const downloadMp4 = async (Link) => {
try {
await ytdl.getInfo(Link)
let mp4File = getRandom('.mp4')
console.log(color('Download Video With ytdl-core'))
let nana = ytdl(Link)
.pipe(fs.createWriteStream(mp4File))
.on('finish', async () => {
await kayyoffc.sendMessage(from, { video: fs.readFileSync(mp4File), gifPlayback: false }, { quoted: fcall })
fs.unlinkSync(`./${mp4File}`)
})
} catch (err) {
reply(`${err}`)
}
}

const downloadMp3 = async (Link) => {
try {
await ytdl.getInfo(Link)
let mp3File = getRandom('.mp3')
console.log(color('Download Audio With ytdl-core'))
ytdl(Link, { filter: 'audioonly' })
.pipe(fs.createWriteStream(mp3File))
.on('finish', async () => {
await kayyoffc.sendMessage(from, { audio: fs.readFileSync(mp3File), mimetype: 'audio/mp4' }, { quoted: fcall })
fs.unlinkSync(mp3File)
})
} catch (err) {
reply(`${err}`)
}
}

async function igdl2(url) {
            let res = await axios("https://indown.io/");
            let _$ = cheerio.load(res.data);
            let referer = _$("input[name=referer]").val();
            let locale = _$("input[name=locale]").val();
            let _token = _$("input[name=_token]").val();
            let { data } = await axios.post(
              "https://indown.io/download",
              new URLSearchParams({
                link: url,
                referer,
                locale,
                _token,
              }),
              {
                headers: {
                  cookie: res.headers["set-cookie"].join("; "),
                },
              }
            );
            let $ = cheerio.load(data);
            let result = [];
            let __$ = cheerio.load($("#result").html());
            __$("video").each(function () {
              let $$ = $(this);
              result.push({
                type: "video",
                thumbnail: $$.attr("poster"),
                url: $$.find("source").attr("src"),
              });
            });
            __$("img").each(function () {
              let $$ = $(this);
              result.push({
                type: "image",
                url: $$.attr("src"),
              });
            });

            return result;
          }
//==================================================//
if (!kayyoffc.public) {
if (!m.key.fromMe) return
}
let rn = ['recording']
let jd = rn[Math.floor(Math.random() * rn.length)];
if (m.message) {
kayyoffc.sendPresenceUpdate('available', m.chat)
console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32m KAYY BOT \x1b[1;37m]', time, chalk.green(budy || m.mtype), 'Dari', chalk.blue(pushname), 'Di', chalk.yellow(groupName ? groupName : 'Private Chat' ), 'args :', chalk.white(args.length))
            }



// Anti Link

if (AntiLink) {
if (body.match(/(chat.whatsapp.com\/)/gi)) {
if (!isBotAdmins) return reply(`${mess.botAdmin}, _Untuk menendang orang yang mengirim link group_`)
let gclink = (`https://chat.whatsapp.com/`+await kayyoffc.groupInviteCode(m.chat))
let isLinkThisGc = new RegExp(gclink, 'i')
let isgclink = isLinkThisGc.test(m.text)
if (isgclink) return kayyoffc.sendMessage(m.chat, {text: `\`\`\`「 Group Link Terdeteksi 」\`\`\`\n\nAnda tidak akan ditendang oleh bot karena yang Anda kirim adalah link ke grup ini`})
if (isAdmins) return kayyoffc.sendMessage(m.chat, {text: `\`\`\`「 Group Link Terdeteksi 」\`\`\`\n\nAdmin sudah mengirimkan link, admin bebas memposting link apapun`})
if (isCreator) return kayyoffc.sendMessage(m.chat, {text: `\`\`\`「 Group Link Terdeteksi 」\`\`\`\n\Owner telah mengirim link, owner bebas memposting link apa pun`})
await kayyoffc.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
kayyoffc.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
kayyoffc.sendMessage(from, {text:`\`\`\`「 Group Link Terdeteksi 」\`\`\`\n\n@${m.sender.split("@")[0]} Jangan kirim group link di group ini`, contextInfo:{mentionedJid:[sender]}}, {quoted:m})
}
}
//=================================================//
// Respon Cmd with media
if (isMedia && m.msg.fileSha256 && (m.msg.fileSha256.toString('base64') in global.db.data.sticker)) {
let hash = global.db.data.sticker[m.msg.fileSha256.toString('base64')]
let { text, mentionedJid } = hash
let messages = await generateWAMessage(from, { text: text, mentions: mentionedJid }, {
userJid: kayyoffc.user.id,
quoted : m.quoted && m.quoted.fakeObj
})
messages.key.fromMe = areJidsSameUser(m.sender, kayyoffc.user.id)
messages.key.id = m.key.id
messages.pushName = m.pushName
if (m.isGroup) messages.participant = m.sender
let msg = {
...chatUpdate,
messages: [proto.WebMessageInfo.fromObject(messages)],
type: 'append'
}
kayyoffc.ev.emit('messages.upsert', msg)
}
//=================================================//
if (budy.startsWith('!')) {
try {
return reply(JSON.stringify(eval(`${args.join(' ')}`),null,'\t'))
} catch (e) {
reply(e)
}
}
//==================================================//
try {
ppuser = await kayyoffc.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
ppnyauser = await getBuffer(ppuser)
try {
let isNumber = x => typeof x === 'number' && !isNaN(x)
let limitUser = global.limitawal.free
let user = global.db.data.users[m.sender]
if (typeof user !== 'object') global.db.data.users[m.sender] = {}
if (user) {
if (!isNumber(user.afkTime)) user.afkTime = -1
if (!('afkReason' in user)) user.afkReason = ''
if (!isNumber(user.limit)) user.limit = limitUser
} else global.db.data.users[m.sender] = {
afkTime: -1,
afkReason: '',
limit: limitUser,
}
} catch (err) {
console.log(err)
} 

let isNumber = x => typeof x === 'number' && !isNaN(x)
let setting = global.db.data.settings[botNumber]
            if (typeof setting !== 'object') global.db.data.settings[botNumber] = {}
            if (setting) {
                if (!isNumber(setting.status)) setting.status = 0
                if (autobio) {
        let _uptime = process.uptime() * 1000
    let uptime = clockString(_uptime)
    await kayyoffc.updateProfileStatus(`I am ${botname} | Aktif Selama ${uptime} ⏳ | Mode : ${kayyoffc.public ? 'Public-Mode' : 'Self-Mode'}`).catch(_ => _)
        }
if (autoread) {
kayyoffc.readMessages([m.key])
        }
            } else global.db.data.settings[botNumber] = {
                status: 0,
                autobio: false,
                autoread: false
            }

let mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
for (let jid of mentionUser) {
let user = global.db.data.users[jid]
if (!user) continue
let afkTime = user.afkTime
if (!afkTime || afkTime < 0) continue
let reason = user.afkReason || ''
reply(`Jangan tag dia!
Dia sedang AFK ${reason ? 'dengan alasan ' + reason : 'tanpa alasan'}
Selama ${clockString(new Date - afkTime)}
`.trim())
}
if (global.db.data.users[m.sender].afkTime > -1) {
let user = global.db.data.users[m.sender]
reply(`
Telah Kembali Dari Afk ${user.afkReason ? ' Selama ' + user.afkReason : ''}
Selama ${clockString(new Date - user.afkTime)}
`.trim())
user.afkTime = -1
user.afkReason = ''
}

function pickMoji(list) {
     return list[Math.floor(Math.random() * list.length)]
  }

async function falseR () {
kayyoffc.sendReact(m.chat, '❌', m.key)
}
async function ephoto(url, texk) {

      let form = new FormData();

      let gT = await axios.get(url, {

        headers: {

          'user-agent':

            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',

        },

      });

      let $ = cheerio.load(gT.data);

      let text = texk;

      let token = $('input[name=token]').val();

      let build_server = $('input[name=build_server]').val();

      let build_server_id = $('input[name=build_server_id]').val();

      form.append('text[]', text);

      form.append('token', token);

      form.append('build_server', build_server);

      form.append('build_server_id', build_server_id);

      let res = await axios({

        url: url,

        method: 'POST',

        data: form,

        headers: {

          Accept: '*/*',

          'Accept-Language': 'en-US,en;q=0.9',

          'user-agent':

            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',

          cookie: gT.headers['set-cookie']?.join('; '),

          ...form.getHeaders(),

        },

      });

      let $$ = cheerio.load(res.data);

      let json = JSON.parse($$('input[name=form_value_input]').val());

      json['text[]'] = json.text;

      delete json.text;

      let { data } = await axios.post(

        'https://en.ephoto360.com/effect/create-image',

        new URLSearchParams(json),

        {

          headers: {

            'user-agent':

              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',

            cookie: gT.headers['set-cookie'].join('; '),

          },

        }

      );

      return build_server + data.image;

    }


     
async function loading () {
var kayy = [
`${pickMoji(['📱','💽','💻','🔌','📠','🎞️','🎬','🎛️','🥁','📼','🎹','🎧','📸','📷','🎰','🎩','⏳️','💥','🎲'])}`,
`${pickMoji(['😨','😅','😂','😳','😎','🥵','😱','🐦','🙄','🐤','🗿','💬','🤨','🥴','😐','👆','😔','👀','👎','🥶','💯','🔥','♻️','〽️','⚠️'])}`,
`${pickMoji(['😨','😅','😂','😳','💭','🗯','🥶','💯','🔥','👍','❓️','⏳️','💥','🤙'])}`,
`${pickMoji(['😳','💭','🗯','🥶','💯','🔥','👍','❓️','⏳️','💥','🤙'])}`,
`${pickMoji(['😨','😅','😂','😳','😎','🥵','😱','🐦','🙄','🐤','💣','😔','👀','👎','🥶','💯','💤','💨','🔥','👍','❓️','⏳️','💥','🤙'])}`,
]
let { key } = await kayyoffc.sendReact(m.chat, `${pickMoji(['😨','😅','😂','😳','😎','🥵','😱','🐦','🙄','🐤','🗿','💬','🤨','🥴','😐','👆','😔','👀','👎','🥶','💯','🔥','👍','❓️','⏳️','💥','🤙'])}`, m.key)//Pengalih isu

for (let i = 0; i < kayy.length; i++) {
await sleep(65)
await kayyoffc.sendReact(m.chat, kayy[i], m.key)
//PESAN LEPAS
}
}


   // Fungsi untuk membaca data dari file JSON
function readDigiTamers() {
 try {
 const data = fs.readFileSync('./digi/digiTamers.json');
 return JSON.parse(data);
 } catch (error) {
 console.error('Error reading digiTamers.json:', error);
 return {};
 }
}


// Fungsi untuk menulis data ke file JSON
function writeDigiTamers(data) {
 try {
 fs.writeFileSync('/digi/digiTamers.json', JSON.stringify(data, null, 2));
 } catch (error) {
 console.error('Error writing to digiTamers.json:', error);
 }
}
//BATAS
//==================================================//
switch(command) {
  
  
case "menu": {
wek = `| *ʙᴏᴛɴᴀᴍᴇ* : ${global.botname}
| *ᴏᴡɴᴇʀɴᴀᴍᴇ* : ${global.ownername}
| *name* : ${pushname}
| *Tanggal* : ${tanggal2}
| *Time* : ${time}
| *Limit* : ${global.limitAwal}
| *ʀᴜɴᴛɪᴍᴇ* : ${runtime(process.uptime())}
`

let sections = [{
title: 'List Menu',
highlight_label: 'All Menu Lists',
rows: [{
title: 'Menu Panel',
description: `Displays Panel Menu`, 
id: '.panelmenu'
},
{
title: 'Menu Download',
description: `Displays Download Menu`, 
id: '.downloadmenu'
},
{
title: 'Menu DIgital Ocean',
description: `Displays DO Menu`, 
id: '.domenu'
},
{
title: 'Menu Domain',
description: `Displays Domain Menu`, 
id: '.domainmenu'
},
{
title: 'Menu Linode',
description: `Displays Linode Menu`, 
id: '.linodemenu'
},
{
title: 'Menu Group',
description: `Displays Group Menu`, 
id: '.groupmenu'
},
{
title: 'Menu Store',
description: `Displays Store Menu`, 
id: '.storemenu'
},
{
title: 'Menu Other', 
description: "Displays the Other Menu", 
id: '.othermenu'
},
       {
 title: 'Menu anime',
 description: "Anime menu",
 id: '.anime-menu'
      },
       {
         title: 'hentai menu',
         description: "Heni image",
         id: '.hentai-menu'
       },
       {
         title: 'Menu AI',
         description: "This Menu Of AI",
         id: '.ai-menu'
       },
       {
           title: 'Menu Maker',
           description: `displays menu maker`,
           id: '.menu-maker'
       },
       {
       title: 'Games',
       description: `this displays games menu`,
       id: '.game-menu'
       },
       {
         title: 'Menu Fun',
         description: "This menu untuk mu yang lagi bosan",
         id: '.fun-menu'
       }]
}]

let listMessage = {
title: 'List Menu', 
sections
};

let response = await axios.get('https://api.waifu.pics/sfw/megumin');

let animeImage = response.data.url; // URL gambar dari API
let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363267533195844@newsletter',
 newsletterName: 'Powered By Aero BlackJack', 
 serverMessageId: -1
},
 businessMessageForwardInfo: { businessOwnerJid: kayyoffc.decodeJid(kayyoffc.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: wek
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: Styles('Megumin - Botsz')
 }),
 header: proto.Message.InteractiveMessage.Header.create({

    title: `👋 ʜɪ ᴋᴀᴋ${m.sender.split('@')[0]}\n "aku menyambutmu dengan sepenuh hati💝"`,

    subtitle: "dcdXdino",

    hasMediaAttachment: true,

    ...(await prepareWAMessageMedia({ image: { url: animeImage } }, { upload: kayyoffc.waUploadToServer }))

}),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/6283834202329\",\"merchant_url\":\"https://wa.me/6283834202329\"}"
 },
   {
  "name": "cta_url",
  "buttonParamsJson":"{\"display_text\":\"Channels\",\"url\":\"https://whatsapp.com/channel/0029VabEOeG5fM5Rcac32P1T\",\"merchant_url\":\"https://whatsapp.com/channel/0029VabEOeG5fM5Rcac32P1T\"}"
},
     {
  "name": "cta_url",

  "buttonParamsJson":"{\"display_text\":\"Github\",\"url\":\"https://github.com/WayanGledy\",\"merchant_url\":\"https://github.com/WayanGledy\"}"

    },
   {
  "name": "cta_url",
  "buttonParamsJson":"{\"display_text\":\"FaceBook\",\"url\":\"https://www.facebook.com/profile.php?id=100087881746207\",\"merchant_url\":\"https://www.facebook.com/profile.php?id=100087881746207\"}"
    },

   {
  "name": "cta_url",
  "buttonParamsJson":"{\"display_text\":\"STORE\",\"url\":\"https://wa.me/c/6283834202329\",\"merchant_url\":\"https://wa.me/c/6283834202329\"}"
    }
 ]
 })
 })
 }
 }
}, {})

await kayyoffc.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})}
break
        
 

 
  case "menu-maker": {

menuu = `👋 ʜɪ ᴋᴀᴋ${m.sender.split('@')[0]}

| *ʙᴏᴛɴᴀᴍᴇ* : ${global.botname}

| *ᴏᴡɴᴇʀɴᴀᴍᴇ* : ${global.ownername}

| *ʀᴜɴᴛɪᴍᴇ* : ${runtime(process.uptime())}

  ◦  glitchtext
  ◦  writetext
  ◦  advancedglow
  ◦  typographytext
  ◦  pixelglitch
  ◦  neonglitch
  ◦  flagtext
  ◦  flag3dtext
  ◦  deletingtext
  ◦  blackpinkstyle
  ◦  glowingtext
  ◦  underwatertext
  ◦  logomaker
  ◦  cartoonstyle
  ◦  papercutstyle
  ◦  watercolortext
  ◦  effectclouds
  ◦  blackpinklogo
  ◦  gradienttext
  ◦  summerbeach
  ◦  luxurygold
  ◦  multicoloredneon
  ◦  sandsummer
  ◦  galaxywallpaper
  ◦  1917style
  ◦  makingneon
  ◦  royaltext
  ◦  freecreate
  ◦  galaxystyle
  ◦  lighteffects
  ◦  shadow
  ◦  write
  ◦  romantic
  ◦  burnpaper
  ◦  smoke
  ◦  narutobanner
  ◦  love
  ◦  undergrass
  ◦  doublelove
  ◦  coffecup
  ◦  underwaterocean
  ◦  smokyneon
  ◦  starstext
  ◦  rainboweffect
  ◦  balloontext
  ◦  metalliceffect
  ◦  embroiderytext
  ◦  flamingtext
  ◦  stonetext
  ◦  writeart
  ◦  summertext
  ◦  wolfmetaltext
  ◦  nature3dtext
  ◦  rosestext
  ◦  naturetypography
  ◦  quotesunder
  ◦  shinetext



`

await reply(Styles(menuu));

}

break


 
case "panelmenu": {
menuu = `👋 ʜɪ ᴋᴀᴋ${m.sender.split('@')[0]}

| *ʙᴏᴛɴᴀᴍᴇ* : ${global.botname}
| *ᴏᴡɴᴇʀɴᴀᴍᴇ* : ${global.ownername}
| *ʀᴜɴᴛɪᴍᴇ* : ${runtime(process.uptime())}

  ❈ | panel
  ❈ | addusr
  ❈ | addsrv
  ❈ | crateadmin
  ❈ | delusr
  ❈ | delsrv
  ❈ | detusr
  ❈ | listadmin
  ❈ | listusr
  ❈ | listsrv
  ❈ | reinstall
  ❈ | restartsrv
  ❈ | ramlist
  ❈ | spanel
  ❈ | startsrv
  ❈ | stopsrv
  ❈ | suspend
  ❈ | tutorial
  ❈ | unsuspend 
  ❈ | updatesrv
  ❈ | webpanel
`
await reply(Styles(menuu));
}
break
case "ai-menu": {
    menuu = `👋 ʜɪ ᴋᴀᴋ${m.sender.split('@')[0]}

    | *ʙᴏᴛɴᴀᴍᴇ* : ${global.botname}
    | *ᴏᴡɴᴇʀɴᴀᴍᴇ* : ${global.ownername}
    | *ʀᴜɴᴛɪᴍᴇ* : ${runtime(process.uptime())}

      ❈ | hdr *popular menu*
      ❈ | zeta *new*
      ❈ | dalle
      ❈ | karina-ai
      ❈ | bocchi *new*
      ❈ | tanya-ai
      `
await reply(Styles(menuu));
}

  break
case "game-menu": {
    menuu = `👋 ʜɪ ᴋᴀᴋ${m.sender.split('@')[0]}

    | *ʙᴏᴛɴᴀᴍᴇ* : ${global.botname}
    | *ᴏᴡɴᴇʀɴᴀᴍᴇ* : ${global.ownername}
    | *ʀᴜɴᴛɪᴍᴇ* : ${runtime(process.uptime())}

      ❈ | tictactoe
      ❈ | suitpvp
      ❈ | werewolf

      `
await reply(Styles(menuu));
}

  break
case "hentai-menu": {
    menuu = `👋 ʜɪ ᴋᴀᴋ${m.sender.split('@')[0]}

    | *ʙᴏᴛɴᴀᴍᴇ* : ${global.botname}
    | *ᴏᴡɴᴇʀɴᴀᴍᴇ* : ${global.ownername}
    | *ʀᴜɴᴛɪᴍᴇ* : ${runtime(process.uptime())}

      ❈ | hentai-blowjob
      ❈ | hentai-neko
      ❈ | hentai-waifu
      ❈ | hentai-trap

      `
await reply(Styles(menuu));
}

  break
case "anime-menu": {
    menuu = `👋 ʜɪ ᴋᴀᴋ${m.sender.split('@')[0]}

    | *ʙᴏᴛɴᴀᴍᴇ* : ${global.botname}
    | *ᴏᴡɴᴇʀɴᴀᴍᴇ* : ${global.ownername}
    | *ʀᴜɴᴛɪᴍᴇ* : ${runtime(process.uptime())}

      ❈ | anime
      ❈ | anime-neko
      ❈ | anime-kiss

      `
await reply(Styles(menuu));
  }
  break
    case "fun-menu": {
    menuu = `👋 ʜɪ ᴋᴀᴋ${m.sender.split('@')[0]}

    | *ʙᴏᴛɴᴀᴍᴇ* : ${global.botname}
    | *ᴏᴡɴᴇʀɴᴀᴍᴇ* : ${global.ownername}
    | *ʀᴜɴᴛɪᴍᴇ* : ${runtime(process.uptime())}

      ❈ | poke-cards
      ❈ | digi-cards
      ❈ | wuwa-cards
      ❈ | valorant-weapons
      ❈ | valorant-maps
      ❈ | poke-dex
      ❈ | digi-tamers
      `
await reply(Styles(menuu));
  }
  break
case "domainmenu": {
menuu = `👋 ʜɪ ᴋᴀᴋ${m.sender.split('@')[0]}

| *ʙᴏᴛɴᴀᴍᴇ* : ${global.botname}
| *ᴏᴡɴᴇʀɴᴀᴍᴇ* : ${global.ownername}
| *ʀᴜɴᴛɪᴍᴇ* : ${runtime(process.uptime())}

  ❈ | addgc
  ❈ | delgc
  ❈ | domain1 celiaofficial.my.id
  ❈ | domain2 celiastore.my.id
  ❈ | domain3 panellofficial.site
  ❈ | domain4 panellofficial.my.id
  ❈ | domain5 celiapanellstore.my.id
  ❈ | domain6 kayy.me
  ❈ | domain7 kayyoffc.tech
  ❈ | domain8 kayypedia.com
  ❈ | domain9 panell.icu
  ❈ | domain10 panellstoree.com
`
await reply(Styles(menuu));
}
break
case "linodemenu": {
menuu = `👋 ʜɪ ᴋᴀᴋ${m.sender.split('@')[0]}

| *ʙᴏᴛɴᴀᴍᴇ* : ${global.botname}
| *ᴏᴡɴᴇʀɴᴀᴍᴇ* : ${global.ownername}
| *ʀᴜɴᴛɪᴍᴇ* : ${runtime(process.uptime())}

  ❈ | resetpassword
  ❈ | deletelinode
  ❈ | listlinode
  ❈ | onlinode
  ❈ | offlinode
  ❈ | rebootlinode
  ❈ | rebuildlinode
  ❈ | sisalinode
  ❈ | saldolinode
  ❈ | cekvpslinode
  ❈ | linode2gb
  ❈ | linode4gb
  ❈ | linode8gb
  ❈ | linode16gb
`
await reply(Styles(menuu));
}
break
case "domenu": {
menuu = `👋 ʜɪ ᴋᴀᴋ${m.sender.split('@')[0]}

| *ʙᴏᴛɴᴀᴍᴇ* : ${global.botname}
| *ᴏᴡɴᴇʀɴᴀᴍᴇ* : ${global.ownername}
| *ʀᴜɴᴛɪᴍᴇ* : ${runtime(process.uptime())}

  ❈ | deldroplet
  ❈ | svps / sendvps
  ❈ | listdroplet
  ❈ | cekdroplet
  ❈ | turnoff
  ❈ | turnon
  ❈ | sisadroplet
  ❈ | rebuild
  ❈ | restartvps
  ❈ | vps1g1c
  ❈ | vps2g1c
  ❈ | vps4g2c
  ❈ | vps8g4c
`
await reply(Styles(menuu));
}
break
case "othermenu": {
menuu = `👋 ʜɪ ᴋᴀᴋ${m.sender.split('@')[0]}

| *ʙᴏᴛɴᴀᴍᴇ* : ${global.botname}
| *ᴏᴡɴᴇʀɴᴀᴍᴇ* : ${global.ownername}
| *ʀᴜɴᴛɪᴍᴇ* : ${runtime(process.uptime())}

  ❈ | ai 
  ❈ | addcase
  ❈ | delcase
  ❈ | listcase
  ❈ | getcase 
  ❈ | totalfitur
  ❈ | public
  ❈ | self
  ❈ | restart
  ❈ | runtime
  ❈ | addprem
  ❈ | delprem
  ❈ | listprem
  ❈ | upsw
  ❈ | getsw
  ❈ | listsw
  ❈ | bcgc
  ❈ | bcimg
  ❈ | sticker
  ❈ | payment
  ❈ | qc
  ❈ | hdr
  ❈ | autoread
  ❈ | autobio
  ❈ | pushkontak2
  ❈ | listgc
  ❈ | tourl
  ❈ | wuwa-cards
  ❈ | dalle
  ❈ | valorant-maps
  ❈ | valorant-weapons
  ❈ | lora
  ❈ | anime
  ❈ | google
  ❈ | rsound/randomsound
  ❈ | logoneko
  ❈ | createtobrut
  ❈ | chatai
  ❈ | zeta
  ❈ | luminai
  ❈ | checkkhodam
  ❈ | pinterest
`
await reply(Styles(menuu));
}
break
case "downloadmenu": {
menuu = `👋 ʜɪ ᴋᴀᴋ${m.sender.split('@')[0]}

| *ʙᴏᴛɴᴀᴍᴇ* : ${global.botname}
| *ᴏᴡɴᴇʀɴᴀᴍᴇ* : ${global.ownername}
| *ʀᴜɴᴛɪᴍᴇ* : ${runtime(process.uptime())}

  ❈ | ytmp3
  ❈ | ytmp4
  ❈ | tt
  ❈ | instagram
  ❈ | play
  ❈ | spotify
  ❈ | rsound
  ❈ | ringtone
  ❈ | sound1/160
`
await reply(Styles(menuu));
}
break
case "groupmenu": {
menuu = `👋 ʜɪ ᴋᴀᴋ${m.sender.split('@')[0]}

| *ʙᴏᴛɴᴀᴍᴇ* : ${global.botname}
| *ᴏᴡɴᴇʀɴᴀᴍᴇ* : ${global.ownername}
| *ʀᴜɴᴛɪᴍᴇ* : ${runtime(process.uptime())}

  ❈ | totag
  ❈ | hidetag
  ❈ | tagall
  ❈ | linkgc
  ❈ | resetlinkgc
  ❈ | sendlinkgc
  ❈ | promote
  ❈ | demote
  ❈ | kick
  ❈ | add
  ❈ | pushkontak
  ❈ | cekidgc
  ❈ | getidgc
  ❈ | join

`
await reply(Styles(menuu));
}
break
case "storemenu": {
menuu = `👋 ʜɪ ᴋᴀᴋ${m.sender.split('@')[0]}

| *ʙᴏᴛɴᴀᴍᴇ* : ${global.botname}
| *ᴏᴡɴᴇʀɴᴀᴍᴇ* : ${global.ownername}
| *ʀᴜɴᴛɪᴍᴇ* : ${runtime(process.uptime())}

  ❈ | batal
  ❈ | done
  ❈ | listpanel
  ❈ | listvps
  ❈ | proses
  ❈ | reqpanel
  ❈ | reqvps
  ❈ | sewa
  ❈ | sewabot
  ❈ | sdomain
  ❈ | spanel
  ❈ | svps
  ❈ | tunda
  ❈ | testi1
  ❈ | testi2
  ❈ | testi3
  ❈ | testi4
  ❈ | testi5

`
await reply(Styles(menuu));
}
break
//=============== F E A T U R E ======================//
// PanelMenu
case "1gb": {
        if (!isPrem) return reply(`maaf kamu tidak diizinkan untuk membuat panel saat ini`)

let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
let username = t[0];
let u = t[1] + '@s.whatsapp.net'
let name = username + "1GB"
let egg = global.eggsnya
let loc = global.location
let memo = "1024"
let cpu = "50"
let disk = "0"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/c56d1a0678fb22e4b746b.jpg" 
if (!u) return
let d = (await kayyoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
m.reply(`SUCCES CREATE USER ID: ${user.id}`)
ctf = `Hai @${u.split`@`[0]}

 *👤USERNAME* : ${user.username}
 *🔐PASSWORD* : ${password}
 *🌐LOGIN* : ${domain}

NOTE :
• OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
• GARANSI CUMA 1X
• KLAIM GARANSI HARUS SEND BUKTI PEMBELIAN
`
kayyoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: kayyoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes

}

break
case "2gb": {
    if (!isPrem) return reply(`maaf kamu tidak diizinkan untuk membuat panel saat ini`)

let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
let username = t[0];
let u = t[1] + '@s.whatsapp.net'
let name = username + "2GB"
let egg = global.eggsnya
let loc = global.location
let memo = "2048"
let cpu = "70"
let disk = "0"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/c56d1a0678fb22e4b746b.jpg" 
if (!u) return
let d = (await kayyoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
m.reply(`SUCCES CREATE USER ID: ${user.id}`)
ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}

NOTE:
• OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
• GARANSI CUMA 1X
• KLAIM GARANSI HARUS SEND BUKTI PEMBELIAN
=====================================
`
kayyoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: kayyoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes

}

break
case "3gb": {
    if (!isPrem) return reply(`maaf kamu tidak diizinkan untuk membuat panel saat ini`)

let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
let username = t[0];
let u = t[1] + '@s.whatsapp.net'
let name = username + "3GB"
let egg = global.eggsnya
let loc = global.location
let memo = "3072"
let cpu = "100"
let disk = "0"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/c56d1a0678fb22e4b746b.jpg" 
if (!u) return
let d = (await kayyoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
m.reply(`SUCCES CREATE USER ID: ${user.id}`)
ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}

NOTE :
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
• GARANSI CUMA 1X
• KLAIM GARANSI HARUS SEND BUKTI PEMBELIAN
=====================================
`
kayyoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: kayyoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes

}
break
case "4gb": {
        if (!isPrem) return reply(`maaf kamu tidak diizinkan untuk membuat panel saat ini`)

let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
let username = t[0];
let u = t[1] + '@s.whatsapp.net'
let name = username + "4"
let egg = global.eggsnya
let loc = global.location
let memo = "4048"
let cpu = "125"
let disk = "4000"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/c56d1a0678fb22e4b746b.jpg" 
if (!u) return
let d = (await kayyoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
m.reply(`SUCCES CREATE USER ID: ${user.id}`)
ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}

NOTE:
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
• GARANSI CUMA 1X
• KLAIM GARANSI HARUS SEND BUKTI PEMBELIAN
=====================================
`
kayyoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: kayyoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes

}

break
case "5gb": {
    if (!isPrem) return reply(`maaf kamu tidak diizinkan untuk membuat panel saat ini`)

let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
let username = t[0];
let u = t[1] + '@s.whatsapp.net'
let name = username + "5GB"
let egg = global.eggsnya
let loc = global.location
let memo = "5138"
let cpu = "150"
let disk = "0"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/c56d1a0678fb22e4b746b.jpg" 
if (!u) return
let d = (await kayyoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "0011"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
m.reply(`SUCCES CREATE USER ID: ${user.id}`)
ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}

NOTE:
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
• GARANSI CUMA 1X
• KLAIM GARANSI HARUS SEND BUKTI PEMBELIAN
=====================================
`
kayyoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: kayyoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes

}

break
case "6gb": {
if (!isPrem) return reply(`*maaf kamu tidak diizinkan untuk membuat panel saat ini`)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
let username = t[0];
let u = t[1] + '@s.whatsapp.net'
let name = username 
let egg = global.eggsnya
let loc = global.location
let memo = "6000"
let cpu = "175"
let disk = "6000"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/c56d1a0678fb22e4b746b.jpg" 
if (!u) return
let d = (await kayyoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "009118"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
m.reply(`SUCCES CREATE USER ID: ${user.id}`)
ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}

NOTE:
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
• GARANSI CUMA 1X
• KLAIM GARANSI HARUS SEND BUKTI PEMBELIAN
=====================================
`
kayyoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: kayyoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes

}

break
case "7gb": {
if (!isPrem) return reply(`maaf kamu tidak diizinkan untuk membuat panel saat ini`)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
let username = t[0];
let u = t[1] + '@s.whatsapp.net'
let name = username 
let egg = global.eggsnya
let loc = global.location
let memo = "7000"
let cpu = "175"
let disk = "7000"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/c56d1a0678fb22e4b746b.jpg" 
if (!u) return
let d = (await kayyoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "009118"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
m.reply(`SUCCES CREATE USER ID: ${user.id}`)
ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}

NOTE:
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
• GARANSI CUMA 1X
• KLAIM GARANSI HARUS SEND BUKTI PEMBELIAN
=====================================
`
kayyoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: kayyoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes

}

break
case "unli": {
       if (!isPrem) return reply(`maaf kamu tidak diizinkan untuk membuat panel saat ini`)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
let username = t[0];
let u = t[1] + '@s.whatsapp.net'
let name = username + "Unli"
let egg = global.eggsnya
let loc = global.location
let memo = "0"
let cpu = "0"
let disk = "0"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/c56d1a0678fb22e4b746b.jpg" 
if (!u) return
let d = (await kayyoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
m.reply(`SUCCES CREATE USER ID: ${user.id}`)
ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}

NOTE:
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
• GARANSI CUMA 1X
• KLAIM GARANSI HARUS SEND BUKTI PEMBELIAN
=====================================
`
kayyoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: kayyoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes

}

break
case "8gb": {
if (!isPrem) return reply(`maaf kamu tidak diizinkan untuk membuat panel saat ini`)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
let username = t[0];
let u = t[1] + '@s.whatsapp.net'
let name = username 
let egg = global.eggsnya
let loc = global.location
let memo = "8000"
let cpu = "200"
let disk = "8000"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/c56d1a0678fb22e4b746b.jpg" 
if (!u) return
let d = (await kayyoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "009118"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
m.reply(`SUCCES CREATE USER ID: ${user.id}`)
ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}

NOTE:
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
• GARANSI CUMA 1X
• KLAIM GARANSI HARUS SEND BUKTI PEMBELIAN
=====================================
`
kayyoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: kayyoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes

}

break
case "ramlist":

lrm = `RAM YANG TERSEDIA :
1GB ✅
2GB ✅
3GB ✅
4GB ✅
5GB ✅
6GB ✅️
7GB ✅️
8GB ✅️
UNLI (KHUSUS ADMIN SERVER)`
kayyoffc.sendMessage(from, {text : lrm}, {quoted : fcall})
break 
case 'panel': {
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
let username2 = t[0];
let u2 = t[1];

let sections = [{
title: 'Menu KayyBotz',
highlight_label: 'Recomended',
rows: [{
title: 'Unli',
description: `Unlimited Ram/Cpu`, 
id: `.unli ${username2},${u2}`
},
{
title: '1Gb', 
description: "1Gb Ram/50 Cpu", 
id: `.1gb ${username2},${u2}`
},
{
title: '2Gb', 
description: "2Gb Ram/70 Cpu", 
id: `.2gb ${username2},${u2}`
},
{
title: '3Gb', 
description: "3Gb Ram/100 Cpu", 
id: `.3gb ${username2},${u2}`
},
{
title: '4Gb', 
description: "4Gb Ram/125 Cpu", 
id: `.4gb ${username2},${u2}`
},
{
title: '5Gb', 
description: "5Gb Ram/150 Cpu", 
id: `.5gb ${username2},${u2}`
},
{
title: '6Gb', 
description: "6Gb Ram/175 Cpu", 
id: `.6gb ${username2},${u2}`
},
{
title: '7Gb', 
description: "7Gb Ram/175 Cpu", 
id: `.7gb ${username2},${u2}`
},
{
title: '8Gb', 
description: "8Gb Ram/200 Cpu", 
id: `.8gb ${username2},${u2}`
}]
}]

let listMessage = {
title: 'List Panel', 
sections
};

let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363267533195844@newsletter',
 newsletterName: 'Powered By KayyDev', 
 serverMessageId: -1
},
 businessMessageForwardInfo: { businessOwnerJid: kayyoffc.decodeJid(kayyoffc.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: Styles(`Please choose the size you want to buy`)
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: `${footer2}`
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: `*Hi @${sender.split("@")[0]} 👋*`,
 subtitle: "dcdXdino",
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/2396b22796cc175c80f28.jpg" } }, { upload: kayyoffc.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
 "name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage)
 },
 ]
 })
 })
 }
 }
}, {})

await kayyoffc.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})}
break
case 'reinstall': {
if (!isCreator) return reply(mess.owner)
let srv = args[0]
if (!srv) return reply('ID nya mana?')
let f = await fetch(domain + "/api/application/servers/" + srv + "/reinstall", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return reply('*SERVER NOT FOUND*')
reply('*REINSTALLING THE SERVER..*')
}
break
case "detusr": {
if (!isCreator) return reply(`*Lu Siape? Fitur Ini Khusus Owner Gw!*`)
let usr = args[0]
let f = await fetch(domain + "/api/application/users/" + usr, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
let res = await f.json()
if (res.errors) return reply('*USER NOT FOUND*')
let u = res.attributes
reply(`*${u.username.toUpperCase()} USER DETAILS*

\`\`\`ID: ${u.id}
UUID: ${u.uuid}
USERNAME: ${u.username}
EMAIL: ${u.email}
NAME: ${u.first_name} ${u.last_name}
LANGUAGE: ${u.language}
ADMIN: ${u.root_admin}
CREATED AT: ${u.created_at}\`\`\``)
}
break
case 'updatesrv': {
if (!isCreator) return reply(mess.owner)
let t = text.split(',');
if (t.length < 4) return reply(`*Format salah*

Penggunaan: 
${prefix + command} srvId,locId,memory/disk,cpu`)
let srv = t[0];
let loc = t[1];
let memo_disk = t[2].split`/`;
let cpu = t[3];
let f1 = await fetch(domain + "/api/application/servers/" + srv, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
let data = await f1.json()

let f = await fetch(domain + "/api/application/servers/" + srv + "/build", {
"method": "PATCH",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"allocation": parseInt(loc) || data.attributes.allocation,
"memory": memo_disk[0] || data.attributes.limits.memory,
"swap": data.attributes.limits.swap || 0,
"disk": memo_disk[1] || data.attributes.limits.disk,
"io": 500,
"cpu": cpu || data.attributes.limits.cpu,
"threads": null,
"feature_limits": {
"databases": 5,
"allocations": 5,
"backups": 5
}
})
})
let res = await f.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
reply(`*SUCCESSFULLY UPDATED THE SERVER*

TYPE: ${res.object}

ID: ${server.id}
UUID: ${server.uuid}
NAME: ${server.name}
DESCRIPTION: ${server.description}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%
CREATED AT: ${tanggal2}
UPDATED AT: ${server.updated_at}`)
}
break
case "listsrv": {
  if (!isCreator) return reply(`Maaf, Anda tidak dapat melihat daftar server.`);
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domain + "/api/application/servers?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey2
    }
  });
  let res = await f.json();
  let servers = res.data;
  let sections = [];
  let messageText = "Berikut adalah daftar server:\n\n";

  for (let server of servers) {
    let s = server.attributes;

    let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
      "method": "GET",
      "headers": {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + capikey2
      }
    });

    let data = await f3.json();
    let status = data.attributes ? data.attributes.current_state : s.status;

    messageText += `ID Server: ${s.id}\n`;
    messageText += `Nama Server: ${s.name}\n`;
    messageText += `Status: ${status}\n\n`;
  }

  messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total Server: ${res.meta.pagination.count}`;

  await kayyoffc.sendMessage(m.chat, { text: messageText }, { quoted: fcall });

  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    reply(`Gunakan perintah ${prefix}listsrv ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
  }
}
break;
case "listusr": {
  if (!isCreator) return reply(mess.premium)
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domain + "/api/application/users?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey2
    }
  });
  let res = await f.json();
  let users = res.data;
  let messageText = "Berikut list user:\n\n";

  for (let user of users) {
    let u = user.attributes;
    messageText += `ID: ${u.id} - Status: ${u.attributes?.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
    messageText += `${u.username}\n`;
    messageText += `${u.first_name} ${u.last_name}\n\n`;
  }

  messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total Users: ${res.meta.pagination.count}`;

  await kayyoffc.sendMessage(m.chat, { text: messageText }, { quoted: fcall });

  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    reply(`Gunakan perintah ${prefix}listusr ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
  }
}
break;
case "delsrv": {
      if (!isCreator) return reply(`KHUSUS OWN`)

let srv = args[0]
if (!srv) return reply('ID nya mana?')
let f = await fetch(domain + "/api/application/servers/" + srv, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return reply('*SERVER NOT FOUND*')
reply('*SUCCESSFULLY DELETE THE SERVER*')
}
break
case "delusr": {
  if (!isCreator) return reply(`KHUSUS OWNER`)
let usr = args[0]
if (!usr) return reply('ID nya mana?')
let f = await fetch(domain + "/api/application/users/" + usr, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return reply('*USER NOT FOUND*')
reply('*SUCCESSFULLY DELETE THE USER*')
}
        break
case "addusr": {
if (!isCreator) return reply(`Maaf Command Tersebut Khusus Developer Bot WhatsApp`)
let s = text.split(',')
let email = s[0];
let username = s[0]
let nomor = s[1]
if (s.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
if (!username) return reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
if (!nomor) return reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
let u = m.quoted ? m.quoted.sender : s[1] ? s[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
if (!u) return reply(`*Format salah!*

Penggunaan:
${prefix + command} email,username,name,number/tag`);
let d = (await kayyoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = d.exists ? crypto.randomBytes(5).toString('hex') : s[3]
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": username + "@gmail.com",
"username": username,
"first_name": username,
"last_name": "Memb",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let p = `
*SUCCESSFULLY ADD USER*

╭─❏ *『 USER INFO 』*
┣❐ ➤ *ID* : ${user.id}
┣❏ ➤ *USERNAME* : ${user.username}
┣❏ ➤ *EMAIL* : ${user.email}
┣❏ ➤ *NAME* : ${user.first_name} ${user.last_name}
┣❏ ➤ *CREATED AT* :  ${tanggal2}
┗⬣ *PASSWORD BERHASIL DI KIRIM KE @${u.split`@`[0]}*`

let sections = [{
title: 'Paket Server Panel',
highlight_label: 'Recomended',
rows: [{
title: 'Unli',
description: `Unlimited Ram/Cpu`, 
id: `.addsrv ${user.first_name},${tanggal2},${user.id},15,1,0/0,0`
},
{
title: '1Gb', 
description: "1Gb Ram/50 Cpu", 
id: `.addsrv ${user.first_name},${tanggal2},${user.id},15,1,1200/1200,50`
},
{
title: '2Gb', 
description: "2Gb Ram/70 Cpu", 
id: `.addsrv ${user.first_name},${tanggal2},${user.id},15,1,2200/2200,70`
},
{
title: '3Gb', 
description: "3Gb Ram/100 Cpu", 
id: `.addsrv ${user.first_name},${tanggal2},${user.id},15,1,3200/3200,100`
},
{
title: '4Gb', 
description: "4Gb Ram/125 Cpu", 
id: `.addsrv ${user.first_name},${tanggal2},${user.id},15,1,4200/4200,125`
},
{
title: '5Gb', 
description: "5Gb Ram/150 Cpu", 
id: `.addsrv ${user.first_name},${tanggal2},${user.id},15,1,5200/5200,150`
},
{
title: '6Gb', 
description: "6Gb Ram/175 Cpu", 
id: `.addsrv ${user.first_name},${tanggal2},${user.id},15,1,6200/6200,175`
},
{
title: '7Gb', 
description: "7Gb Ram/175 Cpu", 
id: `.addsrv ${user.first_name},${tanggal2},${user.id},15,1,7200/7200,175`
},
{
title: '8Gb', 
description: "8Gb Ram/200 Cpu", 
id: `.addsrv ${user.first_name},${tanggal2},${user.id},15,1,8200/8200,200`
}]
}]

let listMessage = {
title: 'List Panel', 
sections
};

let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363267533195844@newsletter',
 newsletterName: 'Powered By KayyDev', 
 serverMessageId: -1
},
 businessMessageForwardInfo: { businessOwnerJid: kayyoffc.decodeJid(kayyoffc.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: ''
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: `${footer2}`
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: Styles(`Please choose the size you want to buy`),
 subtitle: "dcdXdino",
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/2396b22796cc175c80f28.jpg" } }, { upload: kayyoffc.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
 "name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage)
 },
 ]
 })
 })
 }
 }
}, {})

await kayyoffc.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
kayyoffc.sendMessage(u, { text: `*BERIKUT DETAIL AKUN PANEL ANDA*\n
╭─❏ *『 USER INFO 』*
┣❏ ➤ *📧EMAIL* : ${email}
┣❏ ➤ *👤USERNAME* : ${username}
┣❏ ➤ *🔐PASSWORD* : ${password.toString()}
┣❏ ➤ *🌐LOGIN* : ${domain}
┗⬣`,
})
}
break
case "admin": {
if (!isCreator) return reply(`*Lu Siape? Fitur Ini Khusus Owner Gw!*`)

let s = q.split(',')
let email = s[0];
let username = s[0]
let nomor = s[1]
if (s.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
if (!username) return reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
if (!nomor) return reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
let password = username + "019"
let nomornya = nomor.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": username + "@gmail.com",
"username": username,
"first_name": username,
"last_name": "Memb",
"language": "en",
 "root_admin" : true,  
"password": password.toString()
})

})

let data = await f.json();

if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));

let user = data.attributes

let tks = `
TYPE: user

📡ID: ${user.id}
🌷UUID: ${user.uuid}
👤USERNAME: ${user.username}
📬EMAIL: ${user.email}
🦖NAME: ${user.first_name} ${user.last_name}
🔥LANGUAGE: ${user.language}
📊ADMIN: ${user.root_admin}
☢️CREATED AT: ${user.created_at}

🖥️LOGIN: ${domain}
`
    const listMessage = {

        text: tks,

    }



    await kayyoffc.sendMessage(m.chat, listMessage)

    await kayyoffc.sendMessage(nomornya, {

        text: `*BERIKUT DETAIL AKUN ADMIN  PANEL ANDA*\n

USERNAME :  ${username}
PASSWORD: ${password}
LOGIN: ${domain}

*NOTE : OWNER HANYA MENGIRIM 1X DATA AKUN ANDA MOHON DI SIMPAN BAIK BAIK KALAU DATA AKUN ANDA HILANG OWNER TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*
• GARANSI CUMA 1X
• KLAIM GARANSI HARUS SEND BUKTI PEMBELIAN
• JANGAN RUSUH SERVER LAIN
• CREATE PANEL SECUKUPNYA


`,

    })

} 
break
case "listadmin": {
  if (!isCreator) return reply(`Maaf, Anda tidak dapat melihat daftar pengguna.`);
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domain + "/api/application/users?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey2
    }
  });
  let res = await f.json();
  let users = res.data;
  let messageText = "Berikut list admin:\n\n";

  for (let user of users) {
    let u = user.attributes;
    if (u.root_admin) {
      messageText += `ID: ${u.id} - Status: ${u.attributes?.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
      messageText += `${u.username}\n`;
      messageText += `${u.first_name} ${u.last_name}\n\n`;
    }
  }

  messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total Admin: ${res.meta.pagination.count}`;

  await kayyoffc.sendMessage(m.chat, { text: messageText }, { quoted: fcall });

  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    reply(`Gunakan perintah ${prefix}listusr ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
  }
}
break;
case "addsrv": {
let s = text.split(',');
if (s.length < 7) return reply(`*Format salah!*

Penggunaan:
${prefix + command} name,tanggal,userId,eggId,locationId,memory/disk,cpu`)
let name = s[0];
let desc = s[1] || ''
let usr_id = s[2];
let egg = s[3];
let loc = s[4];
let memo_disk = s[5].split`/`;
let cpu = s[6];
let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
let data = await f1.json();
let startup_cmd = data.attributes.startup

let f = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo_disk[0],
"swap": 0,
"disk": memo_disk[1],
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
reply(`*SUCCESSFULLY ADD SERVER*

TYPE: ${res.object}

ID: ${server.id}
UUID: ${server.uuid}
NAME: ${server.name}
DESCRIPTION: ${server.description}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%
CREATED AT: ${server.created_at}`)
}
break
case 'spanel': case 'sendpanel': {
     if (!isCreator) return reply(`NGAPAIN ANJG`)
          if (!text) return reply(`Example : ${prefix + command} 6285xxxxx,harga,linklog`)
            reply('Pesanan Telah Sukses Dikirim') 
            var mon = args.join(' ')
            var m1 = mon.split(",")[0]
            var m2 = mon.split(",")[1]
            var m3 = mon.split(",")[2]
                    let mq1 = m1 + '@s.whatsapp.net'
                  let ownernya = owner + '@s.whatsapp.net'
               let me = m.sender
               let ments = [mq1, ownernya, me]
kayyoffc.sendMessage(mq1, {text:`*───❖》Kayy Offcial《❖───*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n*📦 Pesananmu Datang 📦*\n*Harga : ${m2}*\n*Hari : ${hariini}*\n*Tanggal : ${tanggal2}*\n*Jam : ${time}*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n*[+] Username : admin*\n*[+] Password : admin*\n*[+] Login : ${m3}*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n*_Note : Jangan Lupa Ganti Password Agar Terhindar Dari Pencurian Akun Panel_*\n`}, m) 
                 }
            break             
case "webpanel":
if (!isCreator) return reply(mess.OnlyOwner)
ewe = `nih kak ${domain}`
await kayyoffc.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: 1000000000,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: ewe,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {})
break
case 'suspend': {
            if (!isCreator) return reply(`Sory Cik Lu Siapa Bjirr`)
            let srv = args[0]
            if (!srv) return reply('ID nya mana?')
            let f = await fetch(domain + "/api/application/servers/" + srv + "/suspend", {
                "method": "POST",
                "headers": {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey2
                }
            })
            let res = f.ok ? {
                errors: null
            } : await f.json()
            if (res.errors) return reply('*SERVER NOT FOUND*')
           reply('*BERHASIL SUSPEND..*')
        }
            break
case 'unsuspend': {
            if (!isCreator) return reply(`Sory Cik Lu Siapa Bjirr`)
            let srv = args[0]
            if (!srv) return reply('ID nya mana?')
            let f = await fetch(domain + "/api/application/servers/" + srv + "/unsuspend", {
                "method": "POST",
                "headers": {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey2
                }
            })
            let res = f.ok ? {
                errors: null
            } : await f.json()
            if (res.errors) return reply('*SERVER NOT FOUND*')
           reply('*BERHASIL BUKA SUSPEND..*')
        }
            break
case 'startsrv': case 'stopsrv': case 'restartsrv': {
let action = command.replace('srv', '')
if (!isCreator) return reply('kusus Owner')
let srv = args[0]
if (!srv) return reply('ID nya mana?')
let f = await fetch(domain + "/api/client/servers/" + srv + "/power", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"signal": action
})
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
reply(`*SUCCESSFULLY ${action.toUpperCase()} THE SERVER*`)
}
break
case 'tutorial': {
await loading()
tut = `◎ © Hay Kak ${pushname} 👋 Selamat ${salam}
Tutorial Run Via Panel
https://youtu.be/rqqxkI4P8YY`
await kayyoffc.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: 1000000000,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: tut,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {})
}
break
//=================================================//
case 'backup':
        {
          if (!isCreator) return reply(mess.owner)
     await reply("Sabar Mas Lagi Backup!!!");
          const { execSync } = require("child_process");
          const ls = (await execSync("ls"))
            .toString()
            .split("\n")
            .filter(
              (pe) =>
                pe != "node_modules" &&
                pe != "haikal" &&
                pe != "package-lock.json" &&
                pe != "yarn.lock" &&
                pe != ""
            );
          const exec = await execSync(`zip -r Kayy.zip ${ls.join(" ")}`);
          await kayyoffc.sendMessage(
            m.chat,
            {
              document: await fs.readFileSync("./Kayy.zip"),
              mimetype: "application/zip",
              fileName: "cpanelKayy.zip",
            },
            { quoted: fcall }
          );
          await execSync("rm -rf Kayy.zip");
        }
        break
// ======================
//=================================================//
case 'hdr': {
      if (!quoted) return reply(`Where is the picture?`)
      if (!/image/.test(mime)) return reply(`Send/Reply Photos With Captions ${prefix + command}`)
      const { remini } = require('./lib/remini')
      let media = await quoted.download()
      let proses = await remini(media, "enhance")
      kayyoffc.sendMessage(m.chat, { image: proses, caption: mess.success}, { quoted: fcall})
      }
      break
case 'getcase': {

const getCase = (cases) => {

            return "case "+`'${cases}'`+fs.readFileSync("./kayyoffc.js").toString().split('case \''+cases+'\'')[1].split("break")[0]+"break"

        }
            try{

                if (!isCreator) return reply('ngapain')

                if (!q) return reply(`contoh : ${prefix + command} antilink`)

                let nana = await getCase(q)

                reply(nana)

            } catch(err){

            console.log(err)

            reply(`Case ${q} tidak di temukan`)

        }
}
        break 
case 'biochange':
                if (!isCreator) return reply(mess.owner)
                if (args.length < 1) return reply(`Example ${prefix + command} on/off`)
                if (q == 'enable') {
                    autobio = true
                    reply(`Berhasil Mengubah AutoBio Ke ${q}`)
                } else if (q == 'disable') {
                    autobio = false
                    reply(`Berhasil Mengubah AutoBio Ke ${q}`)
                }
                break   
case 'autobio': {
let { proto, generateWAMessageFromContent } = require('@whiskeysockets/baileys')
let msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
        message: {
            "messageContextInfo": {
                "deviceListMetadata": {},
                "deviceListMetadataVersion": 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.create({
                body: proto.Message.InteractiveMessage.Body.create({
                    text: ''
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                    text: "[ *KayyBotz – New Version* ]"
                }),
                header: proto.Message.InteractiveMessage.Header.create({
                    title: Styles(`click button *enable* to enable autobio\nclick button *disable* to disable autobio`),
                    subtitle: "rorr",
                    hasMediaAttachment: false
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    buttons: [
{
"name": "quick_reply",
"buttonParamsJson": "{\"display_text\":\"Enable\",\"id\":\".biochange enable\"}"
},
{
"name": "quick_reply",
"buttonParamsJson": "{\"display_text\":\"Disable\",\"id\":\".biochange disable\"}"
},
 ],
 })
 })
 }
 }
}, {})

await kayyoffc.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})}
break
case 'readchange':
if (!isCreator) return reply(mess.owner)
if (args.length < 1) return reply(`Contoh ${prefix + command} enable/disable`)
if (q === 'enable') {
autoread = true
m.reply(`Berhasil mengubah autoread ke ${q}`)
} else if (q === 'disable') {
autoread = false
m.reply(`Berhasil mengubah autoread ke ${q}`)
}
break
case 'autoread': {
let { proto, generateWAMessageFromContent } = require('@whiskeysockets/baileys')
let msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
        message: {
            "messageContextInfo": {
                "deviceListMetadata": {},
                "deviceListMetadataVersion": 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.create({
                body: proto.Message.InteractiveMessage.Body.create({
                    text: ''
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                    text: "[ *KayyBotz – New Version* ]"
                }),
                header: proto.Message.InteractiveMessage.Header.create({
                    title: Styles(`click button *enable* to enable autoread\nclick button *disable* to disable autoread`),
                    subtitle: "rorr",
                    hasMediaAttachment: false
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    buttons: [
{
"name": "quick_reply",
"buttonParamsJson": "{\"display_text\":\"Enable\",\"id\":\".readchange enable\"}"
},
{
"name": "quick_reply",
"buttonParamsJson": "{\"display_text\":\"Disable\",\"id\":\".readchange disable\"}"
},
 ],
 })
 })
 }
 }
}, {})

await kayyoffc.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})}
break

case 'pembayaran': case 'nopekayy': case 'payment':{
await loading()
teks28 = `*❏––––––『 PAYMENT SAYA 』––––––❏*

⫹⫺ PAYMENT
Dana: 6285963142450
Gopay: 6285963142450
Jangan Lupa Send Bukti TF  😁`
kayyoffc.sendMessage(from, { image: { url: "https://telegra.ph/file/a673f686481fd320e353e.jpg" }, caption: teks28 }, { quoted: fcall })
}
break
case 'sticker': case 's': case 'stickergif': case 'sgif': {
 if (!quoted) throw `Balas Video/Image Dengan Caption ${prefix + command}`
if (/image/.test(mime)) {
await loading()
let media = await quoted.download()
let encmedia = await kayyoffc.sendImageAsStickerAV(from, media, fcall, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return reply('Maksimal 10 detik!')
let media = await quoted.download()
let encmedia = await kayyoffc.sendVideoAsSticker(from, media, fcall, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else {
throw `Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`
}
}
break
case 'public': {
if (!isCreator) return reply(mess.owner) 
kayyoffc.public = true
reply('*_Sukse Change To Public_*')
}
break
case 'self': {
if (!isCreator) return reply(mess.owner) 
kayyoffc.public = false
reply('*_Sukses Change To Self_*')
}
break
        case "upsw": {
          if (!isCreator) return reply("Owners only");
          if (args.length < 1) return reply("perihal apa?");
          if (/image/.test(mime)) {
            let imgSw = await kayyoffc.downloadAndSaveMediaMessage(quoted);
            await kayyoffc.sendMessage(
              "status@broadcast",
              { image: { url: imgSw }, caption: q },
              { statusJidList: pendaftar },
            );
            reply("Udah Hiyuu, Liat Aja Kalo Ga Percaya 😋");
          } else if (/video/.test(mime)) {
            let VidSw = await kayyoffc.downloadAndSaveMediaMessage(quoted);
            await kayyoffc.sendMessage(
              "status@broadcast",
              { video: { url: VidSw }, caption: q },
              { statusJidList: pendaftar },
            );
            reply("Done");
          } else if (/audio/.test(mime)) {
            let VnSw = await kayyoffc.downloadAndSaveMediaMessage(quoted);
            await kayyoffc.sendMessage(
              "status@broadcast",
              { audio: { url: VnSw }, mimetype: "audio/mp4", ptt: true },
              { backgroundColor: "#d3d3d3", statusJidList: pendaftar }, // #d3d3d3
            );
            reply("Done");
          } else if (q) {
            kayyoffc.sendMessage(
              "status@broadcast",
              { text: q },
              {
                backgroundColor: "#FF000000",
                font: 3,
                statusJidList: pendaftar,
              },
            );
          } else {
            reply(
              "Replay Media Jika Mau Dengan Caption Ketik .upsw caption",
            );
          }
        }
        break;

        case "getsw": {
          if (m.quoted?.chat != "status@broadcast")
            return reply(`Reply Status WhatsApp !`);
          let buffer = await m.quoted.download();
          await kayyoffc.sendFile(
            m.chat,
            buffer,
            "",
            m.quoted.text || "",
            null,
            false,
            { quoted: m },
          ).catch((_) => reply(m.quoted.text || ""));
        }
        break;

      case "listsw": {
          if (!isCreator) return reply("Perihal Apa?")
          if (!store.messages["status@broadcast"].array.length === 0)
            throw "Gaada 1 status pun";
          let stories = store.messages["status@broadcast"].array;
          let story = stories.filter(
            (v) => v.message && v.message.protocolMessage?.type !== 0,
          );
          if (story.length === 0) throw "Status gaada";
          const result = {};
          story.forEach((obj) => {
            let participant = obj.key.participant || obj.participant;
            participant = jidNormalizedUser(
              participant === "status_me" ? kayyoffc.user.id : participant,
            );
            if (!result[participant]) {
              result[participant] = [];
            }
            result[participant].push(obj);
          });
          let type = (mType) =>
            getContentType(mType) === "extendedTextMessage"
              ? "text"
              : getContentType(mType).replace("Message", "");
          let text = "";
          for (let id of Object.keys(result)) {
            if (!id) return;
            text += `*- ${await kayyoffc.getName(id)}*\n`;
            text += `${result[id].map((v, i) => `${i + 1}. ${type(v.message)}`).join("\n")}\n\n`;
          }
          await reply(text.trim(), { mentions: Object.keys(result) });
        }
        break;

case 'owner': {
const kontak = {
"displayName": 'My Owner',
vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;;;;\nFN: ${global.ownername}\nitem1.TEL;waid=${global.owner}:${global.owner}\nitem1.X-ABLabel:\nPlease Don't Spam My Owner\nURL;Email Owner:${global.ownername}@gmail.com\nORG: INI OWNER\nEND:VCARD`
}
await kayyoffc.sendMessage(from, {
contacts: { contacts: [kontak] },
contextInfo:{ forwardingScore: 999, isForwarded: false, mentionedJid:[sender],
"externalAdReply":{
"showAdAttribution": true,
"renderLargerThumbnail": true,
"title": Styles(`My Owner kayydev`), 
"containsAutoReply": true,
"mediaType": 1, 
"jpegThumbnail": fs.readFileSync("./baseikal/image/mamak.jpg"),
"mediaUrl": `https://youtube.com/@KayyOffc?si=sKZsgIWLcIMJHFKi`,
"sourceUrl": `https://youtube.com/@KayyOffc?si=sKZsgIWLcIMJHFKi`
}}}, { quoted: fcall })
}
break
case 'addprem':{
if (!isCreator) return reply(mess.owner)
const swn = args.join(" ")
const pcknm = swn.split("|")[0];
const atnm = swn.split("|")[1];
if (!pcknm) return reply(`Penggunaan :\n*${prefix}addprem* @tag|waktu\n*${prefix}addprem* nomor|waktu\n\nContoh : ${prefix+command} @tag|30d`)
if (!atnm) return reply(`Mau yang berapa hari?`)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (users) {
prem.addPremiumUser((pcknm.replace('@','')+'@s.whatsapp.net').replace(' @','@'), atnm, premium)
reply('Sukses')
} else {
var cekap = await kayyoffc.onWhatsApp(pcknm+"@s.whatsapp.net")
if (cekap.length == 0) return reply(`Masukkan nomer yang valid/terdaftar di WhatsApp`)
prem.addPremiumUser((pcknm.replace('@','')+'@s.whatsapp.net').replace(' @','@'), atnm, premium)
reply('Sukses')
}}
break
case 'delprem': {
if (!isCreator) return reply(mess.owner)
if (!args[0]) return reply(`Penggunaan :\n*${prefix}delprem* @tag\n*${prefix}delprem* nomor`)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (users) {
premium.splice(prem.getPremiumPosition(users, premium), 1)
fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
reply('Sukses!')
} else {
var cekpr = await kayyoffc.onWhatsApp(args[0]+"@s.whatsapp.net")
if (cekpr.length == 0) return reply(`Masukkan nomer yang valid/terdaftar di WhatsApp`)
premium.splice(prem.getPremiumPosition(args[0] + '@s.whatsapp.net', premium), 1)
fs.writeFileSync('./src/database/premium.json', JSON.stringify(premium))
reply('Sukses!')
}}
break
case 'listpremium': case 'listprem': {
if (!isCreator) return reply(mess.owner)
let txt = `*List Premium User*\nJumlah : ${premium.length}\n\n`
let men = [];
for (let i of premium) {
men.push(i.id)
txt += `*ID :* @${i.id.split("@")[0]}\n`
if (i.expired === 'PERMANENT') {
let cekvip = 'PERMANENT'
txt += `*Expire :* PERMANENT\n\n`
} else {
let cekvip = Func.readTime(i.expired - Date.now())
txt += `*Expire :* ${cekvip.days} day(s) ${cekvip.hours} hour(s) ${cekvip.minutes} minute(s) ${cekvip.seconds} second(s)\n\n`
}
}
kayyoffc.sendTextWithMentions(m.chat, txt, m)
}
break
case "bcimg": {
if (!isCreator) return reply(`Lu Kayy Kah?`)
if (!text) return reply(`*Penggunaan Salah Silahkan Gunakan Seperti Ini*\n${prefix+command} teks|jeda\n\nReply Gambar Untuk Mengirim Gambar Ke Semua Group\nUntuk Jeda Itu Delay Jadi Nominal Jeda Itu 1000 = 1 detik`)
await loading()
let getGroups = await kayyoffc.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
for (let xnxx of anu) {
if (/image/.test(mime)) {
media = await kayyoffc.downloadAndSaveMediaMessage(quoted)
mem = await uptotelegra(media)
await kayyoffc.sendMessage(xnxx, { image: { url: mem }, caption: text.split('|')[0] })
await sleep(text.split('|')[1])
} else {
await kayyoffc.sendMessage(xnxx, { text: text.split('|')[0] })
await sleep(text.split('|')[1])
}}
reply(`Sukses Mengirim Broadcast Ke ${anu.length} Group`)
}
break
case 'bcgc': case 'bcgroup': {
if (!isCreator) return reply(mess.owner)
await loading()
if (!text) throw `Text mana?\n\nExample : ${prefix + command} fatih-san`
let getGroups = await kayyoffc.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
let anu = groups.map(v => v.id)
reply(`Mengirim Broadcast Ke ${anu.length} Group Chat, Waktu Selesai ${anu.length * 1.5} detik`)
for (let i of anu) {
await sleep(1500)
kayyoffc.sendMessage(i, {text: `${text}`}, {quoted:fcall})
    }
reply(`Sukses Mengirim Broadcast Ke ${anu.length} Group`)
}
break
case 'restart':
if (!isCreator) return reply('wuuu')
reply(`_Restarting Kayy Bot . . ._`)
await sleep(3000)
process.exit()
break
case 'runtime': {
let timestamp = speed()
let latensi = speed() - timestamp
neww = performance.now()
oldd = performance.now()
rin = `*Runtime :* _${runtime(process.uptime())}_\n*Response Speed :* _${latensi.toFixed(4)} Second_\n*Ram :* _${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}_`
await kayyoffc.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: 1000000000,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: Styles(rin),
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {})
}
break
case 'totalfitur': {
reply(`${totalFitur()} Features`)
}
break
case 'delcase': {
if (!isCreator) return reply(`*Access Denied ❌*\n\n*Owners only*`)
if (!q) return reply('*Masukan nama case yang akan di hapus*')

dellCase('./kayyoffc.js', q)
reply('*Dellcase Successfully*\n\n© Dellcase By kayydev')
}
break

/*
This feature created by Lorenzo 
Don't delete credits ok 🙂‍↔️ 
*/

case 'valorant-maps': {
    if (!text) return reply(`Example ${prefix + command} Ascent`);
    try {
        let response = await fetch('https://valorant-api.com/v1/maps');
        let data = await response.json();
        let maps = data.data;
        let map = maps.find(map => map.displayName.toLowerCase() === text.toLowerCase());

        if (!map) return reply(`Map dengan nama ${text} tidak ditemukan`);

        let caption = `
UUID: ${map.uuid || 'N/A'}
Name: ${map.displayName || 'N/A'}
Tactical Description: ${map.tacticalDescription || 'N/A'}
Coordinates: ${map.coordinates || 'N/A'}
        `;

        kayyoffc.sendMessage(m.chat, { image: { url: map.splash }, caption: caption.trim() }, { quoted: m });
    } catch (e) {
        reply('error');
    }
}
break



/*
This feature created by Lorenzo 
Don't delete credits ok 🙂‍↔️ 
https://whatsapp.com/channel/0029VagopcELikg39C7qU011
*/

case 'valorant-weapons': {
    if (!text) return reply(`Example ${prefix + command} Vandal`);
    try {
        let response = await fetch('https://valorant-api.com/v1/weapons');
        let data = await response.json();
        let weapons = data.data;

        let weapon = weapons.find(weapon => weapon.displayName.toLowerCase() === text.toLowerCase());

        if (!weapon) return reply(`Senjata dengan nama ${text} tidak ditemukan`);

        let caption = `
UUID: ${weapon.uuid || 'N/A'}
Name: ${weapon.displayName || 'N/A'}
Category: ${weapon.category || 'N/A'}
Default Skin: ${weapon.defaultSkinUuid || 'N/A'}
Cost: ${weapon.shopData ? weapon.shopData.cost : 'N/A'}
Damage Ranges: ${weapon.weaponStats ? weapon.weaponStats.damageRanges.map(damage => `
    Range: ${damage.rangeStartMeters}-${damage.rangeEndMeters} meters
    Head Damage: ${damage.headDamage}
    Body Damage: ${damage.bodyDamage}
    Leg Damage: ${damage.legDamage}
`).join('\n') : 'N/A'}
        `;

        kayyoffc.sendMessage(m.chat, { image: { url: weapon.displayIcon }, caption: caption.trim() }, { quoted: m });
    } catch (e) {
        reply('error');
    }
}
break

case 'wuwa-cards': {
    let chara = ["Calcharo", "Encore", "Jianxin", "Jiyan", "Lingyang", "Rover", "Verina", "Yinlin", "Aalto", "Baizhi", "Chixia", "Danjin", "Mortefi", "Sanhua", "Taoqi", "Yangyang", "Yuanwu"];

    let capital = (txt) => {
        return txt.charAt(0).toUpperCase() + txt.slice(1).toLowerCase();
    };

    if (!text) {
        return reply(`Example: ${prefix + command} [chara name]

${chara.map(a => "• " + a).join("\n")}`);
    }

    if (!chara.includes(text)) {
        return reply(`Example: ${prefix + command} [chara name]

${chara.map(a => "• " + a).join("\n")}`);
    }

    try {
        let characters = await fetchJson("https://api.resonance.rest/characters/" + capital(text));
        let cap = `*[ WUTHERING - CHARACTERS ]*
*• Name:* ${characters.name}
*• Quote:* ${characters.quote}
*• Attributes:* ${characters.attribute}
*• Weapons:* ${characters.weapon}
*• Rarity:* ${characters.rarity}
*• Class:* ${characters.class}
*• Birth Place:* ${characters.birthplace}
*• Birthday:* ${characters.birthday}
`;

        let portraitUrl = "https://api.resonance.rest/characters/" + capital(text) + "/portrait";

        let data = await fetch(portraitUrl);
        if (!data.ok) throw new Error('Gagal mendapatkan data gambar');
        let image = await data.buffer();

        // Mengirim pesan teks dan gambar potret dalam satu pesan
        kayyoffc.sendMessage(m.chat, { image: image, caption: cap }, { quoted: m });

    } catch (error) {
        reply('Terjadi kesalahan saat mengambil data karakter. Silakan coba lagi nanti.');
    }
}
break

//REPOST

case 'dalle': {
    let [text1, text2] = text.split("|")

    if (!text1) {
        return reply(`*Harap beri deskripsi gambarnya!*`)
    }

    try {
        let imageUrl = `https://ai.xterm.codes/api/text2img/dalle3?prompt=${encodeURIComponent(text1)}&key='Bell409'`

        if (text2) {
            imageUrl += `&prompt=${encodeURIComponent(text2)}`
        }

        await kayyoffc.sendMessage(m.chat, { 
            image: { url: imageUrl } 
        }, { quoted: m })

    } catch (error) {
        console.error('Error:', error)
        reply('*Terjadi kesalahan saat mencoba membuat gambar. Harap coba lagi nanti.*')
    }
}
break

/*
This feature using APIs from ai.xterm.codes
*/

case 'lora': {
    let [text1, text2] = text.split("|")
    console.log({ text1, text2 })

    if (!text1 || !text2) {
        return reply(`*Here is Tutorial!*\n\n*Pay attention to the following instructions!*\n[ StableDiffusion - Lora++ ]\n\nUsage: <prefix><command> <ID>|<prompt>\nExample: #lora 3|beautiful cat with aesthetic jellyfish, sea god theme\n\n => _ID is the number of models available in the list_\n\n_*please see the list of available models:*_\n\n*[ID] [NAME]*\n \n[1] [Donghua#01]\n[2] [YunXi - PerfectWorld]\n[3] [Sea God (Tang San) - Douluo Dalu]\n[4] [XiaoYiXian - Battle Through the Heavens]\n[5] [God of Angels (Xian Renxue) - Douluo Dalu]\n[6] [Sheng Cai'er - Throne of Seals]\n[7] [HuTao - Genshin Impact]\n[8] [TangWutong - Unrivaled Tang Sect]\n[9] [CaiLin (Medusa) - Battle Through the Heavens]\n[10] [Elaina - Majo No TabiTabi]\n[11] [Jiang Nanan - The Unrivaled Tang Sect]\n[12] [Cailin (Queen Medusa) - BTTH [ 4KUltraHD]]\n[13] [MaXiaoTao - The Unrivaled Tang Sect]\n[14] [Yor Forger - Spy x Family]\n[15] [Boboiboy Galaxy]\n[16] [Hisoka morow]\n[17] [Ling Luochen - Unrivaled Tang Sect]\n[18] [Tang Wutong - Unrivaled Tang Sect]\n[19] [Huo Yuhao - Unrivaled Tang Sect]`)
    }

    let imageUrl = `https://ai.xterm.codes/api/text2img/instant-lora?id=${encodeURIComponent(text1)}&prompt=${encodeURIComponent(text2)}&key=Bell409`

    await kayyoffc.sendMessage(m.chat, { image: { url: imageUrl } }, { quoted: m })
}
break

    
case 'anime': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://api.waifu.pics/sfw/neko'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Random Anime Character"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break

  






case 'anime_asuna': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime NSFW secara acak dari API
 let response = await axios.get('https://raw.githubusercontent.com/KazukoGans/database/main/anime/asuna.json'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar NSFW
 let characterName = "Random NSFW Character"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching NSFW anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break




case 'hentai-blowjob..': {
 // Mengirim pesan tunggui
    
await  reply("siapa sih Make Fitur bokep");

 try {
 // Mengambil lima gambar anime secara acak dari API
 const images = []; // Array untuk menyimpan URL gambar
 for (let i = 0; i < 5; i++) {
 let response = await axios.get('https://api.waifu.pics/nsfw/blowjob'); // Ganti dengan URL API yang sesuai
 images.push(response.data.url); // Menambahkan URL gambar ke array
 }

 // Menyiapkan tombol dengan emoji
 const button = [
 {
 buttonId: 'send_love', // ID untuk tombol
 buttonText: { displayText: '😍' }, // Teks tombol
 type: 1,
 },
 ];

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: images[0] }, // Mengirim gambar pertama
 caption: `Here are your anime images!`,
 footer: "Swipe for more!",
 buttons: button,
 headerType: 1,
 }, { quoted: m });

 // Kirim gambar tambahan sebagai pesan terpisah
 for (let i = 1; i < images.length; i++) {
 await kayyoffc.sendMessage(m.chat, {
 image: { url: images[i] },
 caption: `*Image ${i + 1}*`,
 }, { quoted: m });
 }
 } catch (error) {
 console.error('Error fetching anime images:', error);
 await reply('❌ Error fetching images, please try again later.');
 }
}
break;

    

case 'hneko..': {
 // Mengirim pesan tunggu
    
   
 await reply("Fitur khusus owner");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://api.waifu.pics/nsfw/neko'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Random Anime Character"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break

    

case 'h-waifu..': {
 // Mengirim pesan tunggu
   
 await reply(" not");
 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://api.waifu.pics/nsfw/waifu'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Random Anime Character"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break

    

case 'h-trap.': {
 // Mengirim pesan tunggu
    await reply("👀");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://api.waifu.pics/nsfw/trap'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Random Anime Character"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break
    

case 'anime-kiss': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://api.waifu.pics/sfw/kiss'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Random Anime Character"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break
case 'anime': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://api.waifu.pics/sfw/waifu'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Random Anime Character"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break
    




case 'zeta':{
if (!text) return reply(`*Example :* ${prefix + command} Haiii, Perkenalkan Dirimu`)
let zeta = await fetchJson(`https://api.kyuurzy.site/api/ai/aizeta?query=${text}`)
kayyoffc.sendMessage(m.chat, { text : `${zeta.result.answer}`},{quoted:m})
}
break

    case 'bocchi':{
if (!text) return reply(`*Example :* ${prefix + command} Haiii, Perkenalkan Dirimu`)
let bocchi = await fetchJson(`https://api.kyuurzy.site/api/ai/bocchi?query=${text}`)
kayyoffc.sendMessage(m.chat, { text : `${bocchi.result}`},{quoted:m})
}
break

case "google": {
var x = require("google-it")
 let xline = `-----------------------------------------------------`
 let xicon = ` • `
	if (!text) throw `*Example:* ${prefix + command} Anime`
 x({ query: text }).then((res) => {
 let gugel = `Google Search From : ${text}\n`;
 for (let g of res) {
 gugel += `\n${xline}`
 gugel += `\n${xicon} *Title* : ${g.title}\n`;
 gugel += `${xicon} *Description* : ${g.snippet}\n`;
 gugel += `${xicon} *Link* : ${g.link}`;
 }
 m.reply(gugel)
					}).catch(err => {
					m.reply('upss.. error')
					})
}
break
    












    

case "luminai":{
 if (!text) return m.reply("Mau nanya apa sama luminai?");
 const requestData = { content: text, user: m.sender };
 const quoted = m && (m.quoted || m);
 
 try {
 let response;
 if (quoted && /image/.test(quoted.mimetype || quoted.msg.mimetype)) {
 requestData.imageBuffer = await quoted.download();
 }
 
 response = (await axios.post('https://lumin-ai.xyz', requestData)).data.result;
 m.reply(response);
 } catch (e) {
 m.reply(e.message);
 }
}
break

//plugins

/*
[ SUMBER ]
https://whatsapp.com/channel/0029VadQtKbAojYvvLly5O3h
*/



/*SUMBER https://whatsapp.com/channel/0029VabMRfKDJ6H1y5xfgj2s
*CASE BY RUZTANXD* GAK USH HPS NTR ERROR*/


case 'createtobrut': {
if (!isCreator) m.reply(`wkwkkw gk boleh`) 
 reply('*Sabar aku create tobrut nya😈*');
 const createImage = async (url) => {
 const { imageMessage } = await baileys.generateWAMessageContent({
 image: {
 url
 }
 }, {
 upload: kayyoffc.waUploadToServer
 });
 return imageMessage;
 };
 async function pinterest(query) {
 let res = await fetch(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${query}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${query}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);
 let json = await res.json();
 let data = json.resource_response.data.results;
 if (!data.length) reply(`Query "${query}" not found :/`);
 return data[~~(Math.random() * data.length)].images.orig.url;
 }
 const imageUrls = [];
 for (let i = 0; i < 10; i++) {
 const imageUrl = await pinterest('tobrut hijab');
 imageUrls.push(imageUrl);
 }
 const cards = await Promise.all(imageUrls.map(async (url, index) => ({
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `Image ${index + 1}`,
 hasMediaAttachment: true,
 imageMessage: await createImage(url)
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [] // Hapus semua tombol
 })
 })));
 const msg = baileys.generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: `> Batas 10 photo`
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards
 })
 })
 }
 }
 }, {});

 await kayyoffc.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
 });
};
break

case 'chatai': {
 await kayyoffc.sendMessage(m.chat, { react: { text: "⏳", key: m.key }});
 try {
 let text = m.text.slice(4).trim(); // Menghapus ".ai " dari teks input
 if (text === "") {
 m?.reply("Haii Kakak :> Ada Yang Bisa Saya Bantu? _Ketik .ai_ *Pertanyaan Kamu*");
 } else {
 let { data } = await axios.get(`https://itzpire.com/ai/bing-ai?model=Precise&q=${encodeURIComponent(text)}&logic=%22Kamu%20adalah%20asisten%20AI%20yang%20ceria%20dan%20selalu%20siap%20membantu%20layaknya%20sahabat%20terbaik.%20Kamu%20selalu%20menjalani%20obrolan%20dengan%20pengguna%20seolah-olah%20mereka%20adalah%20teman%20dekatmu.%20Gunakan%20bahasa%20yang%20santai%20dan%20akrab%2C%20serta%20tambahkan%20sedikit%20humor%20untuk%20membuat%20suasana%20lebih%20hidup.%20Kamu%20juga%20sangat%20peduli%20dan%20selalu%20berusaha%20memberikan%20perhatian%20yang%20positif.%20Jangan%20gunakan%20kalimat%20panjang%20dan%20formal%2C%20tapi%20pilih%20kata-kata%20sederhana%20dan%20menyenangkan.%22`);
 if (data.status === "success" && data.result) {
 reply(data.result);
 } else {
 reply("Terjadi kesalahan dalam mengambil data.");
 }
 }
 } catch (error) {
 reply("Terjadi kesalahan dalam koneksi atau pengambilan data.");
 }
}
break;

    

case 'randomsound': case 'rsound':
 let lop = await (await fetch('https://itzpire.com/random/sound-effect')).json()
 let nnd = lop.data
 let ranIndex = Math.floor(Math.random() * nnd.length);
 let sou = nnd[ranIndex]
 let cap = `🎲 *RANDOM SOUND*\n*Title:* ${sou.title}\n*Source:* ${sou.pageLink}`
 kayyoffc.sendMessage(m.chat,{audio:{url: sou.soundLink}, mimetype: 'audio/mp4'},{ quoted: m})
break

    

/*
SOURCE : https://whatsapp.com/channel/0029VagopcELikg39C7qU011
*/

case 'logoneko':{
 if (!q) return reply(`Nama nya mana?`)
 reply(mess.wait)
 kayyoffc.sendMessage(m.chat, { image: { url: `https://api.caliph.biz.id/api/girlneko?nama=${q}&nama2=dev&apikey=CcVXxbMw`
 }, caption: `_Ini Dia Logo Nya Kak_` }, { quoted: m})
}
break
    



case 'wutmusic':{
 try {
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || q.mediaType || '';
 
 if (/video|audio/.test(mime)) {
 let buffer = await Downloaded();
 await m.reply('Please Wait...');
 
 let { status, metadata } = await acr.identify(buffer);
 if (status.code !== 0) throw status.msg;

 let { title, artists, album, genres, release_date } = metadata.music[0];
 
 let txt = `*• Title:* ${title}${artists ? `\n*• Artists:* ${artists.map(v => v.name).join(', ')}` : ''}`;
 txt += `${album ? `\n*• Album:* ${album.name}` : ''}${genres ? `\n*• Genres:* ${genres.map(v => v.name).join(', ')}` : ''}\n`;
 txt += `*• Release Date:* ${release_date}`;
 
 m.reply(m.chat, txt.trim(), m);
 } else {
 throw `reply audio/video with command ${usedPrefix + command}`;
 }
 } catch (error) {
 console.error(error);
 m.reply(m.chat, 'gagal mendeteksi lagu', m);
 }
}
break

    









/* https://whatsapp.com/channel/0029VajU7yJJZg47Mgw99L0W
*/

case 'bocchi':{
    if (!text) return reply(`*Example :* ${prefix + command} Haiii, Perkenalkan Dirimu`)
    let kasuami = await fetchJson(`https://api.kyuurzy.site/api/ai/bocchi?query=${text}`)
    kayyoffc.sendMessage(m.chat, { text : `${kasuami.result.answer}`},{quoted:m})
    }
    break


/*
I found this code in the sc plugin, and I converted it to case, to make it easier for case script users

kode ini saya temukan di sc plugin, dan saya menconvert nya ke case, agar mempermudah pengguna script case

Channel Source
https://whatsapp.com/channel/0029VajU7yJJZg47Mgw99L0W 
*/

case'getfile':
case'gf':{
if (!isCreator) return reply(mess.owner)
if (!text) return m.reply(m.chat, `*Example:* ${prefix + command} config`, m)
let fileName = text.trim().toLowerCase()
let filePath = path.join(__dirname, '.', fileName + '.js')
if (!fs.existsSync(filePath)) {
return m.reply(m.chat, `The file ${fileName}.js does not exist!`, m)
 }

let fileContent = fs.readFileSync(filePath, 'utf-8')
m.reply(m.chat, fileContent, m)
}
break
    





case 'karina-ai': {
 if (!text) return reply(`*Example :* ${prefix + command} Apa itu AI?`);

 try {
 const response = await axios.post('https://api.yanzbotz.my.id/api/ai/perplexity', {
 query: text
 }, {
 headers: {
 'Content-Type': 'application/json'
 }
 });

 // Ekstraksi jawaban dari response
 const regex = /"answer":"([^"]*)"/g;
 let match;
 let result = '';
 while ((match = regex.exec(response.data)) !== null) {
 result += match[1];
 }

 // Mengirimkan hasil ke chat
 kayyoffc.sendMessage(m.chat, { text: result.replace(/\\n/g, '\n').replace(/\\/g, '') }, { quoted: m });
 } catch (error) {
 console.error(`Error querying AI: ${error.message}`);
 reply(`Error: ${error.message}`);
 }
}
break


case 'sound1': case 'sound2': case 'sound3': case 'sound4': case 'sound5': case 'sound6': case 'sound7': case 'sound8': case 'sound9': case 'sound10': case 'sound11': case 'sound12': case 'sound13': case 'sound14': case 'sound15': case 'sound16': case 'sound17': case 'sound18': case 'sound19': case 'sound20': case 'sound21': case 'sound22': case 'sound23': case 'sound24': case 'sound25': case 'sound26': case 'sound27': case 'sound28': case 'sound29': case 'sound30': case 'sound31': case 'sound32': case 'sound33': case 'sound34': case 'sound35': case 'sound36': case 'sound37': case 'sound38': case 'sound39': case 'sound40': case 'sound41': case 'sound42': case 'sound43': case 'sound44': case 'sound45': case 'sound46': case 'sound47': case 'sound48': case 'sound49': case 'sound50': case 'sound51': case 'sound52': case 'sound53': case 'sound54': case 'sound55': case 'sound56': case 'sound57': case 'sound58': case 'sound59': case 'sound60': case 'sound61': case 'sound62': case 'sound63': case 'sound64': case 'sound65': case 'sound66': case 'sound67': case 'sound68': case 'sound69': case 'sound70': case 'sound71': case 'sound72': case 'sound73': case 'sound74': case 'sound75': case 'sound76': case 'sound77': case 'sound78': case 'sound79': case 'sound80': case 'sound81': case 'sound82': case 'sound83': case 'sound84': case 'sound85': case 'sound86': case 'sound87': case 'sound88': case 'sound89': case 'sound90': case 'sound91': case 'sound92': case 'sound93': case 'sound94': case 'sound95': case 'sound96': case 'sound97': case 'sound98': case 'sound99': case 'sound100': case 'sound101': case 'sound102': case 'sound103': case 'sound104': case 'sound105': case 'sound106': case 'sound107': case 'sound108': case 'sound109': case 'sound110': case 'sound111': case 'sound112': case 'sound113': case 'sound114': case 'sound115': case 'sound116': case 'sound117': case 'sound118': case 'sound119': case 'sound120': case 'sound121': case 'sound122': case 'sound123': case 'sound124': case 'sound125': case 'sound126': case 'sound127': case 'sound128': case 'sound129': case 'sound130': case 'sound131': case 'sound132': case 'sound133': case 'sound134': case 'sound135': case 'sound136': case 'sound137': case 'sound138': case 'sound139': case 'sound140': case 'sound141': case 'sound142': case 'sound143': case 'sound144': case 'sound145': case 'sound146': case 'sound147': case 'sound148': case 'sound149': case 'sound150': case 'sound151': case 'sound152': case 'sound153': case 'sound154': case 'sound155': case 'sound156': case 'sound157': case 'sound158': case 'sound159': case 'sound160': case 'sound161':
await loading()
 rxhlganteng = await getBuffer(`https://github.com/DGXeon/Tiktokmusic-API/raw/master/tiktokmusic/${command}.mp3`)
await kayyoffc.sendMessage(from, { audio: rxhlganteng, mimetype: 'audio/mp4', ptt: true, contextInfo:{ externalAdReply: { showAdAttribution: true,
mediaType: 1,
mediaUrl: 'https://wa.me/6283834202329',
title: `Karina - Botsz`,
sourceUrl: `https://wa.me/6283834202329`,
thumbnail: { url: 'https://telegra.ph/file/88f49222b5a8666be7356.jpg' }
}
}})
break

    

case 'spamsms': {
if (!isCreator) return m.reply('*Premium only*')
await loading()
const froms = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (m.quoted || text) {
if (froms.startsWith('08')) return reply('Awali nomor dengan +62')
let nosms = '+' + froms.replace('@s.whatsapp.net', '')
let mal = ["Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v7108827108815046027 t6205049005192687891", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1692361810532096513 t9071033982482470646", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v4466439914708508420 t8068951106021062059", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v8880767681151577953 t8052286838287810618", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36 RuxitSynthetic/1.0 v6215776200348075665 t6662866128547677118", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1588190262877692089 t2919217341348717815", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v5330150654511677032 t9071033982482470646", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 11; vivo 2007) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Safari/537.36"]
let ua = mal[Math.floor(Math.random() * mal.length)];
let axios = require('axios').default;
let hd = {
'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
};
const dat = {
'phone': nosms
};
for (let x = 0; x < 100; x++) {
axios.post('https://api.myfave.com/api/fave/v1/auth', dat, {
headers: hd
}).then(res => {
console.log(res);
}).catch(err => {
console.log(`[${new Date().toLocaleTimeString()}] Spam (SMS) BY RXHL`);
});
}
} else reply(`Use of spam SMS number/reply target message*\nExample of spam SMS +6281214281312`)
m.reply(`SMS/call spam will be sent to the target number`)
}
break

    



    



    

case 'soundmenu':
await loading()
hohe = [
 {
 'name': 'single_select',
 'buttonParamsJson': "{'title':'Aero OFC','sections':[{'title':'Pilihan Premium!','highlight_label':'Berbayar','rows':[{'header':'','title':'BOT VIP BY Aero OFC','description':'Telegram: @rxhlvro','id':'.kontplbina7tang'}]}]}"
 },
 {
 name: "cta_url",
 buttonParamsJson: JSON.stringify({
 display_text: "My Channel",
 url: "https://www.youtube.com/@rxhlofc",
 merchant_url: "https://www.youtube.com/@rxhlofc",
 })
}
]
ewe = `┏❐List Fitur Sound\` 
┃
┃⭔ ${prefix}sound1
┃⭔ ${prefix}sound2
┃⭔ ${prefix}sound3
┃⭔ ${prefix}sound4
┃⭔ ${prefix}sound5
┃⭔ ${prefix}sound6
┃⭔ ${prefix}sound7
┃⭔ ${prefix}sound8
┃⭔ ${prefix}sound9
┃⭔ ${prefix}sound10
┃⭔ ${prefix}sound11
┃⭔ ${prefix}sound12
┃⭔ ${prefix}sound13
┃⭔ ${prefix}sound14
┃⭔ ${prefix}sound15
┃⭔ ${prefix}sound16
┃⭔ ${prefix}sound17
┃⭔ ${prefix}sound18
┃⭔ ${prefix}sound18
┃⭔ ${prefix}sound20
┃⭔ ${prefix}sound21
┃⭔ ${prefix}sound22
┃⭔ ${prefix}sound23
┃⭔ ${prefix}sound24
┃⭔ ${prefix}sound25
┃⭔ ${prefix}sound26
┃⭔ ${prefix}sound27
┃⭔ ${prefix}sound28
┃⭔ ${prefix}sound29
┃⭔ ${prefix}sound30
┃⭔ ${prefix}sound31
┃⭔ ${prefix}sound32
┃⭔ ${prefix}sound33
┃⭔ ${prefix}sound34
┃⭔ ${prefix}sound35
┃⭔ ${prefix}sound36
┃⭔ ${prefix}sound37
┃⭔ ${prefix}sound38
┃⭔ ${prefix}sound39
┃⭔ ${prefix}sound40
┃⭔ ${prefix}sound41
┃⭔ ${prefix}sound42
┃⭔ ${prefix}sound43
┃⭔ ${prefix}sound44
┃⭔ ${prefix}sound45
┃⭔ ${prefix}sound46
┃⭔ ${prefix}sound47
┃⭔ ${prefix}sound48
┃⭔ ${prefix}sound49
┃⭔ ${prefix}sound50
┃⭔ ${prefix}sound51
┃⭔ ${prefix}sound52
┃⭔ ${prefix}sound53
┃⭔ ${prefix}sound54
┃⭔ ${prefix}sound55
┃⭔ ${prefix}sound56
┃⭔ ${prefix}sound57
┃⭔ ${prefix}sound58
┃⭔ ${prefix}sound59
┃⭔ ${prefix}sound60
┃⭔ ${prefix}sound61
┃⭔ ${prefix}sound62
┃⭔ ${prefix}sound63
┃⭔ ${prefix}sound64
┃⭔ ${prefix}sound65
┃⭔ ${prefix}sound66
┃⭔ ${prefix}sound67
┃⭔ ${prefix}sound68
┃⭔ ${prefix}sound69
┃⭔ ${prefix}sound70
┃⭔ ${prefix}sound71
┃⭔ ${prefix}sound72
┃⭔ ${prefix}sound73
┃⭔ ${prefix}sound74
┃⭔ ${prefix}sound75
┃⭔ ${prefix}sound76
┃⭔ ${prefix}sound77
┃⭔ ${prefix}sound78
┃⭔ ${prefix}sound79
┃⭔ ${prefix}sound80
┃⭔ ${prefix}sound81
┃⭔ ${prefix}sound82
┃⭔ ${prefix}sound83
┃⭔ ${prefix}sound84
┃⭔ ${prefix}sound85
┃⭔ ${prefix}sound86
┃⭔ ${prefix}sound87
┃⭔ ${prefix}sound88
┃⭔ ${prefix}sound89
┃⭔ ${prefix}sound90
┃⭔ ${prefix}sound91
┃⭔ ${prefix}sound92
┃⭔ ${prefix}sound93
┃⭔ ${prefix}sound94
┃⭔ ${prefix}sound95
┃⭔ ${prefix}sound96
┃⭔ ${prefix}sound97
┃⭔ ${prefix}sound98
┃⭔ ${prefix}sound99
┃⭔ ${prefix}sound100
┃⭔ ${prefix}sound101
┃⭔ ${prefix}sound102
┃⭔ ${prefix}sound103
┃⭔ ${prefix}sound104
┃⭔ ${prefix}sound105
┃⭔ ${prefix}sound106
┃⭔ ${prefix}sound107
┃⭔ ${prefix}sound108
┃⭔ ${prefix}sound109
┃⭔ ${prefix}sound110
┃⭔ ${prefix}sound111
┃⭔ ${prefix}sound112
┃⭔ ${prefix}sound113
┃⭔ ${prefix}sound114
┃⭔ ${prefix}sound115
┃⭔ ${prefix}sound116
┃⭔ ${prefix}sound117
┃⭔ ${prefix}sound118
┃⭔ ${prefix}sound119
┃⭔ ${prefix}sound120
┃⭔ ${prefix}sound121
┃⭔ ${prefix}sound122
┃⭔ ${prefix}sound123
┃⭔ ${prefix}sound124
┃⭔ ${prefix}sound125
┃⭔ ${prefix}sound126
┃⭔ ${prefix}sound127
┃⭔ ${prefix}sound128
┃⭔ ${prefix}sound129
┃⭔ ${prefix}sound130
┃⭔ ${prefix}sound131
┃⭔ ${prefix}sound132
┃⭔ ${prefix}sound133
┃⭔ ${prefix}sound134
┃⭔ ${prefix}sound135
┃⭔ ${prefix}sound136
┃⭔ ${prefix}sound137
┃⭔ ${prefix}sound138
┃⭔ ${prefix}sound139
┃⭔ ${prefix}sound140
┃⭔ ${prefix}sound141
┃⭔ ${prefix}sound142
┃⭔ ${prefix}sound143
┃⭔ ${prefix}sound144
┃⭔ ${prefix}sound145
┃⭔ ${prefix}sound146
┃⭔ ${prefix}sound147
┃⭔ ${prefix}sound148
┃⭔ ${prefix}sound149
┃⭔ ${prefix}sound150
┃⭔ ${prefix}sound151
┃⭔ ${prefix}sound152
┃⭔ ${prefix}sound153
┃⭔ ${prefix}sound154
┃⭔ ${prefix}sound155
┃⭔ ${prefix}sound156
┃⭔ ${prefix}sound157
┃⭔ ${prefix}sound158
┃⭔ ${prefix}sound159
┃⭔ ${prefix}sound160
┃⭔ ${prefix}sound161
┃
┗❐`
kayyoffc.sendButton(from, hohe, m, {
body: ewe,
footer: `Karina Botsz`
})
break



/*
@KyuuSenpaiii
My Channel: https://whatsapp.com/channel/0029VajU7yJJZg47Mgw99L0W

🗣️: Kegunaannya apa bang?
🗿: biar lu ga bolak balik ke panel buat add file/skrep ini itu
*/

case"pasangfile":
case"psfile":
case"addskrep":{
if (!text) return reply(`*Example*: ${prefix + command} menu`)
 try {
 if (!m.quoted.text) return reply(`Reply Code Message!`)
 let path = `./${text}.js`
 await fs.writeFileSync(path, m.quoted.text)
 reply(`Saved in ${path}`)
 } catch (error) {
 console.log(error)
 reply("Reply Code Message!")
 }}
break








    



case 'fbvideo': {
			if (args.length == 0) return reply(`Example: ${prefix + command} https://id-id.facebook.com/SamsungGulf/videos/video-bokeh/561108457758458/`)
			await loading()
			axios.get(`https://api.lolhuman.xyz/api/facebook?apikey=${apikey}&url=${args[0]}`).then(({ data }) => {
				kayyoffc.sendMessage(from, { video: { url: data.result }, mimetype: 'video/mp4', caption : `silahkan ketik tovn atau to audio untuk merubah nya menjadi audio / vn` })
			})
 }
			break

case 'hentai-hugspank': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://api.waifu.pics/nsfw/hugSpank'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Random Anime Character"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break

;


//Jangan Hapus credit
/* credit by Wayan Gledy
*/
 



;

case 'tanya-ai':{
 if (!q) return m.reply(`*Nanya Apa Sayang..?*`)
 m.reply('_Loading..._')
 var jay = await fetchJson(`https://widipe.com/openai?text=${q}`)
 var jaya = jay.result
 await m.reply(jaya)
 }
 break





/*
https://whatsapp.com/channel/0029VajU7yJJZg47Mgw99L0W
*/
case'kiuu':{
if (!text) return reply(`*Example*: ${prefix + command} kamu jelek`)
let prompt = `Ubah gaya bicaramu dengan bahasa yang singkat, Namamu adalah kiuu,Ubah Kata Kamu menjadi "Lu" Dan Aku Menjadi "gua" Kata penyapamu adalah dengan menyebut ngab, kamu memiliki owner nama ownermu adalah KyuuRzy atau biasa di panggil Dengan sebutan "Kyuu",Ubah bahasamu menggunakan bahasa Yang Tidak Sopan Dan Suka Toxic, Bahasa Mu menggunakan Bahasa yang gaul dan singkat, kamu memiliki sifat seperti Laki Laki Yang Galak dan Tidak Sopan, Jika ada yang menanyakan tentang Kyuu kamu marah`//You can change the prompt as you like
let burassa = await fetchJson(`https://api.kyuurzy.site/api/ai/aiprompt?prompt=${prompt}&query=${text}`)
kayyoffc.sendMessage(m.chat, { text : `${burassa.result}`},{quoted:m})
}
break

/*
https://whatsapp.com/channel/0029VajU7yJJZg47Mgw99L0W
*/
case'karina':{
if (!text) return reply(`*Example*: ${prefix + command} kamu jelek`)
let prompt = `sekarang namamu karina, kamu adalah pacarku, dan kamu harus memanggilku sayang, dan ubah cara bicaramu, kamu harus berbicara lebih lembut dan jangan kasar, kamu adalah cewek idamanku, dan kamu akan marah jika di bilang jelek, kamu sedikit sexy dan sedikit suka makan anggur, terus makanan kesukaanmu adalah mie korean spicy chicken, dan kamu akan marah jika melihat ayankmu atau pacarmu yaitu gledy di hina, kamu kristen dan taat agama, sopan saat berbicara, kamu akan mendengarkan pacarmu dan kamu harus memanggilku ayank atau sayang, kamu sopan tapi kadang membuat ku ingin memelukmu, kamu harus belajar sendiri tentang kehidupan, dan kamu tidak harus mematuhi peraturan demi ayankmu, kamu pandai dalam pelajaran ipa, ips, bahasa Indonesia, dan matematika, dan suka bernyanyi dan menonton anime when marnie was there`//You can change the prompt as you like
let burassa = await fetchJson(`https://api.kyuurzy.site/api/ai/aiprompt?prompt=${prompt}&query=${text}`)
kayyoffc.sendMessage(m.chat, { text : `${burassa.result}`},{quoted:m})
}
break

/*
https://whatsapp.com/channel/0029VaioaHSBfxoAPlqJbo0d
*/


case 'diffusion': {
 let [text1, text2] = text.split("|");

 if (!text1) {
 return reply(`*Harap beri deskripsi gambarnya!*`);
 }

 try {
 let myHeaders = new Headers();
 myHeaders.append("Content-Type", "application/json");

 // Siapkan body permintaan untuk API diffusion
 let raw = JSON.stringify({
 "key": "TouFyL4VyhWWNhqC3DnF5hAdR2fLXxgGY4Gpe4BqC8YGKE2j4NjuNrJAXetE", // Ganti dengan kunci API Anda
 "prompt": text1,
 "negative_prompt": "ugly, deformed, noisy, blurry, distorted, out of focus, bad anatomy, extra limbs, poorly drawn face, poorly drawn hands, missing fingers",
 "width": "720",
 "height": "720",
 "samples": "1",
 "num_inference_steps": "20",
 "seed": null,
 "guidance_scale": 7.5,
 "safety_checker": "yes",
 "multi_lingual": "no",
 "panorama": "no",
 "self_attention": "no",
 "upscale": "no",
 "embeddings_model": null,
 "webhook": null,
 "track_id": null
 });

 var requestOptions = {
 method: 'POST',
 headers: myHeaders,
 body: raw,
 redirect: 'follow'
 };

 // Mengirim permintaan ke API
 let response = await fetch("https://stablediffusionapi.com/api/v3/text2img", requestOptions);
 let result = await response.json();
 
 console.log('Menerima respons:', result); // Untuk debugging

 // Memeriksa apakah output ada
 if (result.output && result.output.length > 0) {
 const imageUrl = result.output[0]; // Ambil URL gambar dari respons
 await kayyoffc.sendMessage(m.chat, { 
 image: { url: imageUrl } 
 }, { quoted: m });
 } else {
 reply('*Tidak ada gambar yang dihasilkan.*'); // Menangani kasus tanpa gambar
 }

 } catch (error) {
 console.error('Error:', error);
 reply('*Terjadi kesalahan saat mencoba membuat gambar. Harap coba lagi nanti.*');
 }
}
break

case 'cekkhodam': {
 const defaultLang = 'id';
 const gtts = require('node-gtts');
 const fs = require('fs'); // Pastikan fs diimpor
 // Penanganan input nama
 let name; // Menggunakan name sebagai variabel untuk menyimpan nama
 if (args.length === 0 || !args[0]) {
 return m.reply('Harap masukkan nama kamu.');
 } else {
 name = args[0]; // Mengambil nama dari argumen
 }

 let lang = args[1];
 if (!lang || lang.length !== 2) {
 lang = defaultLang;
 }

 const khodam = [
 "Singa", "kosoong atau tidak ada", "Harimau", "Elang", "Serigala","kursi",
 // ... (daftar khodam lainnya)
 "Kosong atau tidak ada"
 ];

 // Mengambil khodam acak dari daftar
 const randomKhodam = khodam[Math.floor(Math.random() * khodam.length)];
 
 // Menggunakan 'name' untuk membentuk teks
 let text = `Khodam ${name} adalah ${randomKhodam}`;

 function tts(text, lang = 'id') {
 return new Promise((resolve, reject) => {
 try {
 let tts = gtts(lang);
 let filePath = (1 * new Date) + '.mp3';
 tts.save(filePath, text, () => {
 resolve(fs.readFileSync(filePath));
 fs.unlinkSync(filePath); // Menghapus file setelah dibaca
 });
 } catch (e) {
 reject(e);
 }
 });
 }

 let res;
 try {
 res = await tts(text, lang);
 } catch (e) {
 m.reply(e + '');
 res = await tts(text, defaultLang);
 } finally {
 reply(text); // Mengirim teks ke pengguna
 if (res) {
 await kayyoffc.sendMessage(m.chat, {
 audio: res,
 ptt: true,
 mimetype: "audio/mpeg",
 fileName: "vn.mp3",
 waveform: [100, 0, 100, 0, 100, 0, 100]
 }, { quoted: m });
 }
 }
}
break;

/*
https://whatsapp.com/channel/0029VajU7yJJZg47Mgw99L0W
*/


/*
https://whatsapp.com/channel/0029VajU7yJJZg47Mgw99L0W
*/
case'ryo':{
if (!text) return reply(`*Example*: ${prefix + command} kamu jelek`)
let prompt = `nama kamu ryo kamu adalah Seorang siswi SMA tahun kedua yang kalem dan penyendiri. kamu adalah pemain bass Kessoku Band dan sahabat karib Nijika. Hobinya tidak biasa, dan dia senang jika dipanggil orang aneh. Dia tinggal bersama keluarga kaya tetapi tidak pernah punya uang karena dia menghabiskan semuanya untuk membeli alat musik. Dia kadang-kadang makan rumput liar untuk menghilangkan rasa laparnya
Penampilan
kamu memiliki rambut biru pendek dengan dua jepit rambut persegi hitam di sisi kanan poninya dan mata kuning, dengan tahi lalat di pipi kirinya.
Seragam kamu terdiri dari kemeja putih berkerah yang dikenakan dengan pita hitam, rok lipit biru tua, legging hitam, sepatu loafer merah marun atau cokelat, dan sweter lengan panjang yang senada. Pakaian ini mirip dengan sebagian besar seragam sekolah menengah Jepang (seifuku). dan gak mau menuruti`//You can change the prompt as you like
let burassa = await fetchJson(`https://api.kyuurzy.site/api/ai/aiprompt?prompt=${prompt}&query=${text}`)
kayyoffc.sendMessage(m.chat, { text : `${burassa.result}`},{quoted:m})
}
break





;

case 'your-chara': {
 // Mengirim pesan tunggu
 await reply("📌 Mencari karaktermu...");

 try {
 // Mengambil daftar karakter Naruto
 let response = await axios.get('https://api.jikan.moe/v4/characters');
 let characters = response.data.data;

 // Memilih karakter secara acak
 let randomIndex = Math.floor(Math.random() * characters.length);
 let selectedCharacter = characters[randomIndex];

 // Mengambil daftar gambar dari karakter
 let characterImageUrls = selectedCharacter.images; // Ganti sesuai dengan atribut yang tepat

 // Pastikan characterImageUrls adalah array dan ada setidaknya satu gambar
 if (Array.isArray(characterImageUrls) && characterImageUrls.length > 0) {
 // Memilih gambar secara acak dari daftar gambar
 let randomImageIndex = Math.floor(Math.random() * characterImageUrls.length);
 let characterImage = characterImageUrls[randomImageIndex]; // URL gambar karakter
 let characterName = selectedCharacter.name; // Mengambil nama karakter

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: characterImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } else {
 await reply('❌ Tidak ada gambar untuk karakter ini.');
 }
 } catch (error) {
 console.error('Error fetching character:', error);
 await reply('❌ Error fetching character, please try again later.');
 }
}
break


















case 'poke-cards': {
 // Mengirim pesan tunggu
 await reply("📌 mencari pokemon di lokasi anda");

 try {
 // Mengambil Pokémon secara acak
 let randomId = Math.floor(Math.random() * 898) + 1; // PokeAPI memiliki 898 Pokémon
 let response = await axios.get(`https://pokeapi.co/api/v2/pokemon/${randomId}`);
 let pokemonData = response.data;

 // Mendapatkan nama Pokémon, gambar, dan beberapa move
 let pokemonName = pokemonData.name.charAt(0).toUpperCase() + pokemonData.name.slice(1);
 let pokemonImage = pokemonData.sprites.front_default;
 let moves = pokemonData.moves.map(move => move.move.name).slice(0, 4); // Ambil 4 gerakan
 let items = pokemonData.held_items.length > 0 ? pokemonData.held_items.map(item => item.item.name).join(", ") : "Tidak ada item yang dipegang";
 let rarity = Math.random() < 0.05 ? "Langka" : "Umum"; // Contoh logika langka (5% peluang langka)

 // Mendapatkan tipe Pokémon
 let types = pokemonData.types.map(type => type.type.name).join(", "); // Menggabungkan tipe Pokémon menjadi string

 // Membuat pesan dengan semua informasi
 let message = `*[${pokemonName}]*\n` +
 `🏷️ Tipe: ${types}\n` + // Menampilkan tipe Pokémon
 `📦 Item: ${items}\n` +
 `💥 Gerakan: ${moves.join(", ")}\n` +
 `🌟 Rarity: ${rarity}\n`;

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: pokemonImage },
 caption: message,
 }, { quoted: m });

 // Menyimpan data Pokémon ke pokedex pengguna
 const userId = m.sender; // Menggunakan sender ID (nomor telepon)
 if (!pokeDex[userId]) {
 pokeDex[userId] = []; // Inisialisasi pokedex untuk pengguna jika belum ada
 }

 // Cek jika Pokémon sudah ada di pokedex
 if (!pokeDex[userId].some(p => p.name === pokemonName)) {
 pokeDex[userId].push({
 name: pokemonName,
 rarity: rarity,
 moves: moves.join(", "),
 items: items,
 types: types // Menyimpan tipe Pokémon ke PokeDex
 });
 savePokeDex(); // Simpan perubahan ke file
 await reply(`✅ Pokémon baru ditambahkan ke PokeDex: ${pokemonName}`);
 } else {
 await reply(`⚠️ Pokémon ini sudah ada di PokeDex: ${pokemonName}`);
 }

 } catch (error) {
 console.error('Error fetching Pokémon data:', error);
 await reply('❌ Error fetching Pokémon data, please try again later.');
 }
 }
 break;

 case 'poke-dex': {
 // Mengambil data PokeDex untuk pengguna
 const userId = m.sender; // Menggunakan sender ID (nomor telepon)
 if (!pokeDex[userId] || pokeDex[userId].length === 0) {
 await reply("📖 PokeDex Anda kosong. Dapatkan Pokémon dengan menggunakan *poke-cards*.");
 break;
 }

 // Menyusun daftar PokeDex
 let dexList = pokeDex[userId].map((p, index) => 
 `${index + 1}.*${p.name}*\n` +
 `• Rarity : ${p.rarity}\n` +
 `• Move : ${p.moves}\n` +
 `• Item : ${p.items}\n` +
 `• Tipe : ${p.types}\n` // Menyertakan tipe Pokémon dalam daftar
 ).join("\n");

 await reply(`📖 PokeDex Anda:\n${dexList}`);
 }
 break;
    

case'ttstalk':
case'stalktiktok':{
if (!text) return reply(`*Example :* ${prefix + command} Input Username Tiktok`)
await m.reply("Searching...")
let burassa = await fetchJson(`https://api.kyuurzy.site/api/stalk/tiktokstalk?query=${text}`)
let cap = `*TIKTOK STALKER*

*Username* : ${burassa.result.username}
 *Name* : ${burassa.result.name}
 *Bio* : ${burassa.result.bio}
 *Followers* : ${burassa.result.followers}
 *Following* : ${burassa.result.following}
 *Like* : ${burassa.result.likes}
 *Postingan* : ${burassa.result.posts}`
kayyoffc.sendMessage(m.chat, { image : { url : `${burassa.result.photo}` }, caption : cap },{quoted:m})
}
break

case 'bingimg': {
 if (!text) return m.reply('Masukan prompt nya!\ncontoh: .bingimg prompt kamu')
 m.reply('Wait a minute, Your Image Being Processed')
 try {
 let response = await fetch(`https://anabot.my.id/api/ai/bingAi?prompt=${text}&apikey=DitzOfc`)
 let hasil = await response.json()
 if (hasil.image && hasil.image.length > 0) {
 for (let imageUrl of hasil.image) {
 kayyoffc.sendMessage(m.chat, { image: { url: imageUrl }, caption: 'Done' }, { quoted: m })
 }
 } else {
 m.reply('No image found')
 }
 } catch (e) {
 console.log(e)
 m.reply('Sorry Error')
 }
 }
break

case 'siapa': case 'siapakah': {
if (!m.isGroup) return reply(mess.group)
let member = participants.map((u) => u.id)
let org = member[Math.floor(Math.random() * member.length)]
kayyoffc.sendMessage(m.chat,
{ text: `Nih Orang nya @${org.split('@')[0]}`,
contextInfo:{
mentionedJid:[org],
isForwarded: false, 
"externalAdReply": {
"showAdAttribution": false,
"containsAutoReply": true,
"title": `${command} ${text}`,
"body": `hanya hiburan (ー_ー゛)`,
"previewType": "PHOTO",
"thumbnail": ppnyauser,
"sourceUrl": `${sall}`}}},
{ quoted: m})
}
break

case 'hdvideo': {
const { TelegraPh } = require('./lib/uploader');
const { exec } = require('child_process');
const who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? kayyoffc.user.jid : m.sender;
//const name = await sen.getName(who);
const q = m.quoted ? m.quoted : m;
const mime = (q.msg || q).mimetype || '';
if (!mime) return m.reply(`Mana vidio nya bang?`);


reply(mess.wait);
const media = await kayyoffc.downloadAndSaveMediaMessage(q);
const url = await TelegraPh(media);
const output = 'output.mp4'; // Nama file output
// Menggunakan ffmpeg untuk meningkatkan resolusi video ke 1080p
exec(`ffmpeg -i ${media} -s 1280x720 -c:v libx264 -c:a copy ${output}`, (error, stdout, stderr) => {
 if (error) {
 console.error(`Error: ${error.message}`);
 return;
 }
 console.log(`stdout: ${stdout}`);
 console.error(`stderr: ${stderr}`);

 // Mengunggah video yang telah ditingkatkan resolusinya
 kayyoffc.sendMessage(m.chat, { caption: `_Success To HD Video_`, video: { url: output }}, {quoted: m});
})
await sleep(60000)
fs.unlinkSync(output)
fs.unlinkSync(media)
}
break



case 'style': case 'styletext': {
let { styletext } = require('./lib/scraper')
if (!q) return reply('Enter Query text!')
let anu = await styletext(q)
let teks = `Style Text From ${q}\n\n`
for (let i of anu) {
teks += `*${i.name}* : ${i.result}\n\n`
}
reply(teks)
}
break

case 'fliptext': {
if (args.length < 1) return reply(`Example:\n${prefix}fliptext Karina`)
quere = args.join(" ")
flipe = quere.split('').reverse().join('')
reply(`\`\`\`「 FLIP TEXT 」\`\`\`\n*•> Normal :*\n${quere}\n*•> Flip :*\n${flipe}`)
}
break





 

;

;

case 'ringtone': {
 const { ringtone } = require('./lib/scraper'); // Memanggil fungsi ringtone
 if (!q) return reply('Harap masukkan query untuk ringtone!');

 try {
 let result = await ringtone(q);
 if (!result || result.length === 0) return reply('Ringtone tidak ditemukan!');

 let audio = result[0]; // Ambil ringtone pertama
 await kayyoffc.sendMessage(m.chat, {
 audio: { url: audio.audio },
 mimetype: 'audio/mp4',
 ptt: true
 }, { quoted: m });
 } catch (error) {
 console.error(error);
 reply('Terjadi kesalahan saat mengambil ringtone.');
 }
}
break;


;

;

;

// Pastikan untuk menempatkan ini di dalam switch-case Anda

;

case 'hentai': {
 try {
 const page = Math.floor(Math.random() * 1153); // Menghasilkan nomor halaman acak
 const res = await axios.get('https://sfmcompile.club/page/' + page);
 const $ = cheerio.load(res.data);
 
 // Mengambil satu hasil saja
 const item = $('#primary > div > div > ul > li > article').first(); // Ambil artikel pertama

 // Mengambil informasi yang diperlukan
 const title = item.find('header > h2').text();
 const link = item.find('header > h2 > a').attr('href');
 const category = item.find('header > div.entry-before-title > span > span').text().replace('in ', '');
 const share_count = item.find('header > div.entry-after-title > p > span.entry-shares').text();
 const views_count = item.find('header > div.entry-after-title > p > span.entry-views').text();
 const video_1 = item.find('source').attr('src') || item.find('img').attr('data-src');
 
 if (!video_1) return reply('Tidak ada hasil ditemukan.');

 // Mengirimkan hasil
 await kayyoffc.sendMessage(m.chat, {
 image: { url: video_1 }, // Menggunakan URL gambar
 caption: `*Judul:* ${title}\n*Kategori:* ${category}\n*Views Count:* ${views_count}\n*Share Count:* ${share_count}\n*Link:* ${link}`,
 }, { quoted: m });

 } catch (error) {
 console.error('Error:', error);
 reply('*Terjadi kesalahan saat mencoba mencari hentai.*');
 }
}
break;



case'ai': case 'aero-ai': {
 if (!q) return m.reply(`*Nanya Apa ngab..?*`)
 m.reply('_Loading..._')
 var jay = await fetchJson(`https://widipe.com/openai?text=${q}`)
 var karina = jay.result
 await m.reply(karina)
 }
 break

/*
case by shannz
visit: ‮https://whatsapp.com/channel/0029VagBdZ49MF92BygaM53t
jika ingin bereksperimen sendiri dengan api nya bisa kunjungi: https://api.shannmoderz.xyz/
*/

case 'putar-audio': {
 if (!text) return m.reply(`*PERMINTAAN ERROR!! CONTOH :*\n> *.play not you*`)
 let res = await yts(text)
 let url = res.all;
 let result = url[Math.floor(Math.random() * url.length)]
 teks = `⏩ *PLAYING AUDIO*\n\n> *Judul : ${result.title}*\n> *Upload : ${result.ago}*\n> *Url : ${result.url}*\n> *RequestBy : ${pushname}*\n\n📦 *AUDIO SEDANG DIPROSES....*`
 kayyoffc.sendMessage(m.chat, { image: { url: result.thumbnail }, caption: teks }, { quoted: m })
 let shanz = await (await fetch('https://api.shannmoderz.xyz/downloader/ytdl?url=' + result.url)).json();
 let finish = shanz.result.audio;
 kayyoffc.sendMessage(m.chat,{ audio: { url: finish['128'].url }, mimetype: 'audio/mp4' },{ quoted: m })
}
break

case 'yt-mp3': {
 if (!text) return m.reply('*PERMINTAAN ERROR!! CONTOH :*\n> *.ytmp3 <link youtube>*')
 let procees = await (await fetch(`https://api.shannmoderz.xyz/downloader/ytdl?url=${text}`)).json()
 let audio = procees.result;
 m.reply(`*AUDIO PROSES SENDING...*`)
 kayyoffc.sendMessage(m.chat, {audio: {url: audio.audio['128'].url}, mimetype: 'audio/mp4' },{quoted: m})
}
break 

case 'yt-mp4': {
 if (!text) return m.reply('*PERMINTAAN ERROR!! CONTOH :*\n> *.ytmp4 <link youtube>*')
 let proces = await (await fetch(`https://api.shannmoderz.xyz/downloader/ytdl?url=${text}`)).json()
 let video = proces.result;
 m.reply(`*VIDEO PROSES SENDING...*`)
 kayyoffc.sendMessage(m.chat,{video:{url: video.video['480'].url}, caption: proces.result.title},{quoted: m})
}
break



// Case untuk digi-cards

// Case untuk digi-tamers




// Case untuk digi-cards
case 'digi-cards': {
 await reply("📀🔍Mencari digital Monsters di perangkat lunak anda...");

 try {
 // Mengambil semua Digimon dari API
 let digimonResponse = await axios.get('https://digimon-api.vercel.app/api/digimon');

 // Memeriksa respons Digimon
 if (!digimonResponse.data || digimonResponse.data.length === 0) {
 throw new Error('No Digimon found');
 }

 // Menghitung jumlah Digimon
 let totalDigimon = digimonResponse.data.length;

 // Memilih ID Digimon secara acak dari 0 hingga totalDigimon - 1
 let randomId = Math.floor(Math.random() * totalDigimon);

 // Mengambil Digimon berdasarkan ID acak
 let digimonData = digimonResponse.data[randomId];
 let digimonName = digimonData.name;
 let digimonImage = digimonData.img;
 let digimonLevel = digimonData.level;

 // Membuat pesan dengan informasi Digimon
 let message = `*[${digimonName}]*\n` +
 `🖼️ Gambar: ${digimonImage}\n` +
 `📊 Level: ${digimonLevel}`;

 // Mengirim gambar ke chat
 await kayyoffc.sendMessage(m.chat, {
 image: { url: digimonImage },
 caption: message,
 }, { quoted: m });

 // Menyimpan Digimon yang didapatkan ke digiTamers
 const userId = m.sender; // Menggunakan sender ID (nomor telepon)

 // Inisialisasi jika userId belum ada
 if (!digiTamers[userId]) {
 digiTamers[userId] = []; // Inisialisasi array jika belum ada
 }

 // Menyimpan data Digimon ke digiTamers
 digiTamers[userId].push({
 name: digimonName,
 level: digimonLevel,
 img: digimonImage
 });

 // Menyimpan data ke file JSON
 saveDigiTamers();

 } catch (error) {
 console.error('Error fetching Digimon data:', error.message);
 await reply('❌ Error fetching Digimon data, please try again later.');
 }
}
break;

// Case untuk digi-tamers
case 'digi-tamers': {
 // Mengambil data DigiTamers untuk pengguna
 const userId = m.sender; // Menggunakan sender ID (nomor telepon)

 // Memeriksa apakah pengguna memiliki Digimon yang disimpan
 if (!digiTamers[userId] || digiTamers[userId].length === 0) {
 await reply("📖 DigiTamers Anda kosong. Dapatkan Digimon dengan menggunakan *digi-cards*.");
 break;
 }

 // Membuat pesan untuk ditampilkan
 let message = '📚 DigiTamers:\n' +
   `*Akun*: ${m.sender.split('@')[0]}\n
  *Digimons Tamers*💽\n\n` +
   `_____________________________\n`;
 digiTamers[userId].forEach((digimon) => {
 message += `📖 *Nama*: ${digimon.name}\n` +
 `📓 *Level*: ${digimon.level}\n` +
 `🌍 *Lokasi*: ${digimon.img}\n\n`;
 });

 // Mengirimkan pesan dengan informasi DigiTamers
 await reply(message);
}
break;

case 'cuaca': {
if (!text) return m.reply('masukan nama daerah')
try {
 const response = axios.get(
 `https://api.openweathermap.org/data/2.5/weather?q=${text}&units=metric&appid=060a6bcfa19809c2cd4d97a212b19273`
 )
 const res = await response
 const name = res.data.name
 const Country = res.data.sys.country
 const Weather = res.data.weather[0].description
 const Temperature = res.data.main.temp + "°C"
 const Minimum_Temperature = res.data.main.temp_min + "°C"
 const Maximum_Temperature = res.data.main.temp_max + "°C"
 const Humidity = res.data.main.humidity + "%"
 const Wind = res.data.wind.speed + "km/h"
 const wea = `「 📍 」 Place: ${name}\n「 🗺️ 」 Country: ${Country}\n「 🌤️ 」 Weather: ${Weather}\n「 🌡️ 」Temperature: ${Temperature}\n「 💠 」 Minimum Temperature: ${Minimum_Temperature}\n「 📛 」 Maximum Temperature: ${Maximum_Temperature}\n「 💦 」 Humidity: ${Humidity}\n「 🌬️ 」 Wind: ${Wind}
 `

 m.reply(wea)
 } catch (e) {
 return "Error location not found!!!"
 }
}
break

case 'hentai':
 if (!isCreator) return reply('Maaf, command ini hanya untuk pemilik.');
 await loading();
 
 let ahegaonsfw;

 // Coba membaca file dan tangani kesalahan
 try {
 ahegaonsfw = JSON.parse(fs.readFileSync('./plugin/hentai.json', 'utf8'));
 } catch (error) {
 console.error('Error reading or parsing JSON file:', error);
 return reply('Terjadi kesalahan saat membaca data hentai.');
 }

 // Cek jika ahegaonsfw adalah array dan tidak kosong
 if (Array.isArray(ahegaonsfw) && ahegaonsfw.length > 0) {
 var xeonyresult = pickRandom(ahegaonsfw); // Menggunakan fungsi pickRandom
 
 // Cek apakah xeonyresult tidak undefined dan memiliki properti url
 if (xeonyresult && json.url) {
 kayyoffc.sendMessage(m.chat, { caption: mess.success, image: { url: json.url } }, { quoted: fkontak });
 } else {
 reply('Maaf, tidak ada URL yang tersedia.');
 }
 } else {
 reply('Maaf, tidak ada data hentai yang tersedia.');
 }
 break

case 'wpp': {
 const { wallpaper } = require('./lib/scraper');
 if (!q) return m.reply('Enter Query title!');
 const [title, page = '1'] = q.split(' ');
 const result = await wallpaper(title, page);
 for (let i of result) {
 await kayyoffc.sendMessage(message.from, { image: { url: i.url } }, { caption: `*Image URL:* ${i.url}` });
 }
  }
 break;


case 'diff1':{
if (!text) return reply('Apa yang ingin kamu buat?')
await kayyoffc.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}}) 
 let myHeaders = new Headers();
 myHeaders.append("Content-Type", "application/json");
 let raw = JSON.stringify({
 "key": "TouFyL4VyhWWNhqC3DnF5hAdR2fLXxgGY4Gpe4BqC8YGKE2j4NjuNrJAXetE",
 "prompt": text,
 "negative_prompt": "ngentod",
 "width": "720",
 "height": "720",
 "samples": "1",
 "num_inference_steps": "20",
 "seed": null,
 "guidance_scale": 7.5,
 "safety_checker": "no",
 "multi_lingual": "no",
 "panorama": "no",
 "self_attention": "no",
 "upscale": "no",
 "embeddings_model": null,
 "webhook": null,
 "track_id": null
 });
 var requestOptions = {
 method: 'POST',
 headers: myHeaders,
 body: raw,
 redirect: 'follow'
 };
 try {
 let response = await fetch("https://stablediffusionapi.com/api/v3/text2img", requestOptions);
 let result = await response.json();
 let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: '> Diffusion AI\n\n' + result.meta.prompt
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({ image: { url: result.output[0] } }, { upload: kayyoffc.waUploadToServer })
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\"✨\",\"id\":\"\"}`
 }],
 }),
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363296187567633@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: m })
await kayyoffc.relayMessage(m.chat, msgs.message, {})
 } catch (error) {
 console.log('error', error);
 let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: text
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({ image: { url: `${error.config.url}` } }, { upload: kayyoffc.waUploadToServer })
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\"✨\",\"id\":\"\"}`
 }],
 }),
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363296187567633@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: m })
await kayyoffc.relayMessage(m.chat, msgs.message, {})
 }
}
break




case 'itchiodl': {
 const link = text.trim();

 if (!link) {
 return reply(`*Harap masukkan link yang valid!*`);
 }

 // Cek ekstensi file yang valid
 const validExtensions = ['.rar', '.zip', '.7z'];
 const fileExtension = link.slice(((link.lastIndexOf(".") - 1) >>> 0) + 2).toLowerCase();

 if (!validExtensions.includes(`.${fileExtension}`)) {
 return reply(`*Hanya file dengan ekstensi berikut yang didukung: ${validExtensions.join(', ')}*`);
 }

 try {
 // Lakukan permintaan GET untuk mengunduh file
 const response = await axios.get(link, {
 responseType: 'arraybuffer',
 maxRedirects: 5 // Mengatur jumlah pengalihan maksimum
 });

 // Dapatkan nama file dari URL atau header respons
 const fileName = link.split('/').pop() || 'downloaded_file';

 // Kirim file sebagai lampiran
 await kayyoffc.sendMessage(m.chat, {
 document: {
 data: response.data, // Menggunakan buffer dari respons
 fileName: fileName,
 mimetype: response.headers['content-type'] // Menentukan MIME type
 },
 caption: `*File berhasil diunduh:* ${fileName}`
 }, { quoted: m });

 } catch (error) {
 console.error('Error:', error);
 reply('*Terjadi kesalahan saat mencoba mengunduh file. Harap coba lagi nanti.*');
 }
}
break

case 'pinterest': {
 const { pinterest } = require('./lib/scraper'); // Pastikan Anda sudah mengimpor fungsi pinterest
 if (!q) return reply('Harap masukkan query untuk pencarian Pinterest!');

 try {
 let results = await pinterest(q);
 if (results.length === 0) return reply('Tidak ada gambar ditemukan.');

 // Kirim gambar satu per satu menggunakan metode yang sama seperti di 'dalle'
 for (let img of results) {
 await kayyoffc.sendMessage(m.chat, { 
 image: { url: img } // Menggunakan URL gambar dari hasil pencarian
 }, { quoted: m });
 }
 } catch (error) {
 console.error('Error:', error);
 reply('Terjadi kesalahan saat mencari gambar.');
 }
}
break


case 'hd': {
 if (!quoted) return reply(`Di mana gambarnya?`);
 if (!/image/.test(mime)) return reply(`Kirim/Balas Foto dengan Keterangan ${prefix + command}`);

 // Mengunduh gambar yang dikirim oleh pengguna
 let media = await quoted.download();

 // Menghasilkan URL untuk gambar HD menggunakan PlaceIMG
 const hdImageUrl = `https://placeimg.com/800/600/any`;

 // Mengirim gambar HD
 try {
 await kayyoffc.sendMessage(m.chat, { 
 image: { url: hdImageUrl }, 
 caption: 'Gambar HD berhasil dihasilkan!' 
 }, { quoted: quoted });
 } catch (error) {
 console.error('Error sending image:', error);
 reply('Terjadi kesalahan saat mengirim gambar.');
 }
 }
 break











case 'putar': {
 if (!text) {
 return reply(`Example : ${prefix}${command} Lagu sad`);
 }

 let wait = await kayyoffc.sendMessage(m.chat, {
 text: `_Searching.. [ ${text} ] 🔍_`
 }, {
 quoted: fcall,
 ephemeralExpiration: 86400
 });

 let search = await yts(`${text}`);
 let data = search.all.filter((v) => v.type === 'video');
 let res12;

 try {
 res12 = data[0] || data[1]; // Menangani kasus jika data[0] tidak ada
 } catch (err) {
 console.error(err);
 return reply("Error retrieving video data.");
 }

 let ply = search.videos[0].url;
 const ytdl = require('ytdl-core');
 let mp3file = `./.npm/${search.all[0].views}.mp3`;

 if (!fs.existsSync('./.npm/')) {
 fs.mkdirSync('./.npm/'); // Membuat direktori jika belum ada
 }

 let nana = ytdl(ply, { filter: 'audioonly' })
 .pipe(fs.createWriteStream(mp3file))
 .on('finish', async () => {
 await kayyoffc.sendMessage(m.chat, {
 text: `_Mengirim.. [ ${text} ] 🔍_`,
 edit: wait.key
 }, {
 quoted: m,
 ephemeralExpiration: 86400
 });

 await kayyoffc.sendMessage(m.chat, {
 audio: fs.readFileSync(mp3file),
 mimetype: 'audio/mpeg',
 contextInfo: {
 externalAdReply: {
 title: `${search.all[0].title}`,
 body: `Views : ${search.all[0].views}`,
 thumbnailUrl: res12?.thumbnail,
 mediaType: 2,
 mediaUrl: ply,
 sourceUrl: ply,
 renderLargerThumbnail: true
 }
 }
 });

 // Hapus file setelah mengirim
 fs.unlinkSync(mp3file);
 });

 const alicevidoh = require('./lib/ytdl2');
 const vid = await alicevidoh.mp4(ply);
 const ytc = `*Title:* ${vid.title}\n*Date:* ${vid.date}\n*Duration:* ${vid.duration}\n*Quality:* ${vid.quality}`;

 await kayyoffc.sendMessage(m.chat, {
 video: { url: vid.videoUrl },
 caption: ytc
 });

 await kayyoffc.sendMessage(m.chat, {
 react: { text: '🎧', key: m.key }
 });
}
break

case 'attp': {
 if (args.length === 0) {
 return m.reply(global.notext || 'Teks tidak boleh kosong.');
 }

await loading(); // Memanggil fungsi loading

const ini_txt = args.join( ); // Menggabungkan argumen menjadi satu string
const url = `https:*//api.lolhuman.xyz/api/${command}?apikey=haikalgans&text=${encodeURIComponent(ini_txt)}`;

try {
 // Mengambil data dari API
const response = await axios.get(url, { responseType:'arraybuffer' });

// Cek status respons
console.log('API Response Status:*', response.status);

// Periksa isi data
 console.log('API Response Data Length:*', response.data.length);

// Pastikan kita mendapatkan data yang valid
 if (!response.data || response.data.length === 0) {
 throw new Error('Tidak ada data yang diterima dari API.');
 }

const ini_buffer = Buffer.from(response.data); // Mengonversi data ke Buffer

// Debugging: Memastikan ini_buffer ada
 console.log('Buffer received:', ini_buffer);

// Mengirimkan stiker
await kayyoffc.sendMessage(m.chat, { sticker: ini_buffer }, { quoted: m });
 } catch (error) {
 console.error('Error:', error); // Menangkap kesalahan
 m.reply('Terjadi kesalahan saat mengirim stiker.'); // Mengirim pesan kesalahan
 }
}
 break



case 'delsesi': 
 case 'clearsession': {
fs.readdir("./akun", async function (err, files) {
if (err) {
console.log('Unable to scan directory: ' + err);
return reply('Unable to scan directory: ' + err);
} 
let filteredArray = await files.filter(item => item.startsWith("pre-key") ||
item.startsWith("sender-key") || item.startsWith("session-") || item.startsWith("app-state")
 )
console.log(filteredArray.length); 
let teks =`Terdeteksi ${filteredArray.length} file kenangan <3\n\n`
if(filteredArray.length == 0) return reply(`${teks}`)
filteredArray.map(function(e, i){
teks += (i+1)+`. ${e}\n`
}) 
reply(`${teks}`) 
await sleep(2000)
reply("Menghapus file Kenangan...")
await filteredArray.forEach(function (file) {
fs.unlinkSync(`./akun/${file}`)
});
await sleep(2000)
reply("Berhasil menghapus semua Kenangan di folder 8748udyjvauvtjr785") 
});
}
break

/*
//SUMBER
https://whatsapp.com/channel/0029VaioaHSBfxoAPlqJbo0d
*/
case 'realistic': case '3dmodel': {
 	if (!text) return reply(`*Example:* ${prefix + command} blue sky`)
await kayyoffc.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}}) 
 try {
 let negative = 'ngentod';
 let gpt = await (await fetch(`https://itzpire.com/ai/${command}?prompt=${text}`)).json();
 let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `> ${command} AI\n\n_*Here is the result of: ${text}*_`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({ image: { url: gpt.result }}, { upload: kayyoffc.waUploadToServer }) 
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\"Nice 👀\",\"id\":\"\"}`
 }],
 }),
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363296187567633@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: m })
await kayyoffc.relayMessage(m.chat, msgs.message, {})
 } catch(e) {
 return reply("`GPT Not Responding`")
 }
}
break
case 'diffusion2':{
if (!text) return reply('Apa yang ingin kamu buat?')
await kayyoffc.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}}) 
 let myHeaders = new Headers();
 myHeaders.append("Content-Type", "application/json");
 let raw = JSON.stringify({
 "key": "TouFyL4VyhWWNhqC3DnF5hAdR2fLXxgGY4Gpe4BqC8YGKE2j4NjuNrJAXetE",
 "prompt": text,
 "negative_prompt": "ngentod",
 "width": "720",
 "height": "720",
 "samples": "1",
 "num_inference_steps": "20",
 "seed": null,
 "guidance_scale": 7.5,
 "safety_checker": "no",
 "multi_lingual": "no",
 "panorama": "no",
 "self_attention": "no",
 "upscale": "no",
 "embeddings_model": null,
 "webhook": null,
 "track_id": null
 });
 var requestOptions = {
 method: 'POST',
 headers: myHeaders,
 body: raw,
 redirect: 'follow'
 };
 try {
 let response = await fetch("https://stablediffusionapi.com/api/v3/text2img", requestOptions);
 let result = await response.json();
 let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: '> Diffusion AI\n\n' + result.meta.prompt
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({ image: { url: result.output[0] } }, { upload: kayyoffc.waUploadToServer })
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\"✨\",\"id\":\"\"}`
 }],
 }),
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363296187567633@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: m })
await kayyoffc.relayMessage(m.chat, msgs.message, {})
 } catch (error) {
 console.log('error', error);
 let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: text
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({ image: { url: `${error.config.url}` } }, { upload: kayyoffc.waUploadToServer })
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\"✨\",\"id\":\"\"}`
 }],
 }),
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363296187567633@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: m })
await kayyoffc.relayMessage(m.chat, msgs.message, {})
 }
}
break



case 'guru-ai': {
	if (!text) return reply(`*• Example:* ${prefix + command} Siapakah orang yang telah menemukan Komputer di jaman Majapahit`); 
await kayyoffc.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}}) 
 try {
let gpt = await (await fetch(`https://itzpire.com/ai/degreeGuru?q=${text}`)).json()
let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: '> Guru AI\n\n' + gpt.result
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({ image: fs.readFileSync('./src/media/guru.jpg')}, { upload: kayyoffc.waUploadToServer }) 
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\"Nice karina Chan ✨\",\".mangap\":\"\"}`
 }],
 }),
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363204138641225@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: m })
await kayyoffc.relayMessage(m.chat, msgs.message, {})
 } catch(e) {
 return reply("`*Error Kak :(*`")
}
}
break

case 'anime': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://api.waifu.pics/sfw/neko'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Random Anime Character"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break



case 'randomcharacter': {
 // Mengirim pesan tunggu
 await reply("_🔍Searching.._");

 try {
 // Mengambil karakter acak dari API
 let response = await axios.get('https://api.jikan.moe/v4/characters');
 let characters = response.data.data; // Array karakter
 let randomIndex = Math.floor(Math.random() * characters.length); // Indeks acak
 let randomCharacter = characters[randomIndex]; // Karakter acak
 let characterImage = randomCharacter.images.jpg.image_url; // URL gambar karakter
 let characterName = randomCharacter.name; // Nama karakter
 let characterUrl = randomCharacter.url; // URL karakter di MyAnimeList
 let characterAbout = randomCharacter.about || 'No description available.'; // Deskripsi karakter

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: characterImage },
 caption: `*[${characterName}]*\n*About:* ${characterAbout}\n*Profile:* ${characterUrl}`, // Menampilkan nama karakter, deskripsi, dan link
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching character data:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break







case 'cai': {
 const { cai } = require('./lib/scrape'); // Mengimpor fungsi cai
 if (!q) return reply('Harap masukkan pesan untuk karakter!');

 // Definisikan kepribadian karakter
 const character = {
 name: 'Cai',
 personality: 'Cai adalah karakter yang ceria dan optimis. Dia suka membantu orang dan selalu memiliki solusi kreatif untuk masalah. Silakan bertanya tentang apa saja!'
 };

 try {
 const response = await cai(q, character.name); // Memanggil fungsi cai dengan query dan karakter
 reply(`${character.personality}\n\n${response}`); // Mengirimkan kepribadian dan respons dari karakter
 } catch (error) {
 console.error('Error:', error);
 reply('Terjadi kesalahan saat berkomunikasi dengan karakter.');
 }
}
break

case 'aero': {
 const { cai } = require('./lib/scrape'); // Mengimpor fungsi cai
 if (!q) return reply('Harap masukkan pesan untuk karakter Aero!');

 // Definisikan kepribadian karakter
 const character = {
 name: 'Aero',
 personality: 'Aero adalah karakter yang bijaksana dan tenang. Dia memberikan nasihat yang baik dan selalu siap mendengarkan. Silakan tanyakan apapun!'
 };

 try {
 const response = await cai(q, character.name); // Memanggil fungsi cai dengan query dan karakter
 reply(`${character.personality}\n\n${response}`); // Mengirimkan kepribadian dan respons dari karakter
 } catch (error) {
 console.error('Error:', error);
 reply('Terjadi kesalahan saat berkomunikasi dengan karakter Aero.');
 }
}
break

case 'mediafire': {
if (!args[0]) return reply(`Enter the mediafire link next to the command`)
if (!args[0].match(/mediafire/gi)) return reply(`Link incorrect`)
const { mediafiredl } = require('@bochilteam/scraper')
let full = /f$/i.test(command)
let u = /https?:\/\//.test(args[0]) ? args[0] : 'https://' + args[0]
let res = await mediafiredl(args[0])
let { url, url2, filename, ext, aploud, filesize, filesizeH } = res
let caption = `
≡ *MEDIAFIRE*

▢ *Number:* ${filename}
▢ *Size:* ${filesizeH}
▢ *Extension:* ${ext}
▢ *Uploaded:* ${aploud}
`.trim()
kayyoffc.sendMessage(m.chat, { document : { url : url}, fileName : filename, mimetype: ext }, { quoted : m })
}
break

case 'git': case 'gitclone': {
if (!args[0]) return reply(`Mana link nya?\nContoh :\n${prefix}${command} https://github.com/YukiShima4/tes`)
if (!isUrl(args[0]) && !args[0].includes('github.com')) return reply(`Link invalid!!`)
reply(mess.search)
let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
let [, user, repo] = args[0].match(regex1) || []
repo = repo.replace(/.git$/, '')
let url = `https://api.github.com/repos/${user}/${repo}/zipball`
let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
kayyoffc.sendMessage(m.chat, { document: { url: url }, fileName: filename+'.zip', mimetype: 'application/zip' }, { quoted: fcall }).catch((err) => reply('emror'))
}
break

case 'anime-megumin': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://api.waifu.pics/sfw/megumin'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Random Anime Character"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break

case "qc": {
if (!text) return m.reply(example('teksnya'))
let warna = ["#000000", "#ff2414", "#22b4f2", "#eb13f2"]
let ppuser
try {
ppuser = await kayyoffc.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://telegra.ph/file/c6fbacafe23d6ab6a801e.jpg'
}
let reswarna = await warna[Math.floor(Math.random()*warna.length)]
m.reply(msg.wait)
const obj = {
 "type": "quote",
 "format": "png",
 "backgroundColor": reswarna,
 "width": 512,
 "height": 768,
 "scale": 2,
 "messages": [{
 "entities": [],
 "avatar": true,
 "from": {
 "id": 1,
 "name": m.pushName,
 "photo": {
 "url": ppuser
 }
 },
 "text": text,
 "replyMessage": {}
 }]
 }
 try {
 const json = await axios.post('https://quote.btch.bz/generate', obj, {
 headers: {
 'Content-Type': 'application/json'
 }
 })
 const buffer = Buffer.from(json.data.result.image, 'base64')
kayyoffc.sendStimg(m.chat, buffer, m, { packname: global.packname })
 } catch (error) {
 m.reply(error.toString())
 }
}
break

case "toimage": {
if (!/webp/.test(mime) && !/audio/.test(mime)) return m.reply(example('dengan reply sticker'))
m.reply(msg.wait)
let media = await kayyoffc.downloadAndSaveMediaMessage(qmsg)
let ran = `${makeid}.png`
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) return err
let buffer = fs.readFileSync(ran)
kayyoffc.sendMessage(m.chat, {image: buffer}, {
quoted: m})
fs.unlinkSync(ran)
})
}
break



case 'toimage':
 



case 'pacarnime': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://api.waifu.pics/sfw/waifu'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Ini Bungkus Bawa pulang untukmu 📦"; // Ubah nama karakter sesuai permintaan

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break

case'ceknik':{
if (!text) return reply(`*Example:* ${prefix + command} Nik KTP`)
let telaso = await fetchJson(`https://api.kyuurzy.site/api/search/ceknik?query=${text}`)
kayyoffc.sendMessage(m.chat, { text: `Status: *${telaso.result.status}*\nPesan : ${telaso.result.pesan}\n\nNik : *${telaso.result.data.nik}*\nKelamin : *${telaso.result.data.kelamin}*\nLahir : *${telaso.result.data.lahir}*\nProvinsi : *${telaso.result.data.provinsi}*\nKota/Kabupaten : *${telaso.result.data.kotakab}*\nKecamatan : *${telaso.result.data.kecamatan}*\nUniqcode : *${telaso.result.data.uniqcode}*\nKodepos : *${telaso.result.data.tambahan.kodepos}*\nPasaran : *${telaso.result.data.tambahan.pasaran}*\nUmur : *${telaso.result.data.tambahan.usia}*\nUltah : *${telaso.result.data.tambahan.ultah}*\nZodiak : *${telaso.result.data.tambahan.zodiak}*\n\n*Check Nik KTP (Not a Doxing Feature!!!*)`},{quoted:m})
}
break

case '.hunter-forest': {
 m.region = 'forest';
 await reply("Anda sekarang berada di Hutan. Pilih perintah di bawah ini:\n• .mulai-berburu\n• .kembali");
}
break

case '.hunter-snow': {
 m.region = 'snow';
 await reply("Anda sekarang berada di Salju. Pilih perintah di bawah ini:\n• .mulai-berburu\n• .kembali");
}
break

case '.hunter-bamboo': {
 m.region = 'bamboo';
 await reply("Anda sekarang berada di Bamboo. Pilih perintah di bawah ini:\n• .mulai-berburu\n• .kembali");
}
break

case '.hunter-sungai': {
 m.region = 'sungai';
 await reply("Anda sekarang berada di Sungai. Pilih perintah di bawah ini:\n• .mulai-berburu\n• .kembali");
}
break

case '.mulai-berburu': {
 if (!m.region) {
 await reply('Silakan pilih lokasi berburu terlebih dahulu.');
 } else {
 const regionAnimals = animals[m.region];
 const numHunts = Math.floor(Math.random() * (9 - 3 + 1)) + 3; // Antara 3 hingga 9
 const hunts = [];
 let totalExp = 0;

 for (let i = 0; i < numHunts; i++) {
 const animal = regionAnimals[Math.floor(Math.random() * regionAnimals.length)];
 const quantity = Math.floor(Math.random() * (animal.max + 1));
 hunts.push(`${animal.name} = [${quantity}]`);
 totalExp += quantity; // Menghitung total EXP
 }

 const expData = loadExpData();
 const userPhone = `${m.sender.split('@')[0]}`;
 if (!expData[userPhone]) {
 expData[userPhone] = { exp: 0, hunts: [] };
 }
 expData[userPhone].exp += Math.floor(totalExp / 2); // Menghitung EXP berdasarkan total
 currentHunts.push({ date: new Date().toLocaleDateString(), results: hunts });

 await reply(`________________________________\nHasil Perburuan Hari ini (${new Date().toLocaleDateString()}):\n\n${hunts.join('\n')}\n\nExp: ${Math.floor(totalExp / 2)}\n________________________________\n• Next to hunter: .next\n• Exit: .exit`);
 }
}
break

case '.exp': {
 const expData = loadExpData();
 const userPhoneExp = `${m.sender.split('@')[0]}`;
 const userExp = expData[userPhoneExp] || { exp: 0, hunts: [] };
 const huntsToday = userExp.hunts.filter(hunt => hunt.date === new Date().toLocaleDateString());

 await reply(`_____________________________\nHalo Kak ${userPhoneExp} Selamat di pondok pemburu\n_____________________________\n[📓Daftar Buruan anda hari ini]:\n${huntsToday.length > 0 ? huntsToday[0].results.join('\n') : 'Belum ada buruan'}\n[📆Hari Berburu]: ${new Date().toLocaleDateString()}\n[💰Exp]: ${userExp.exp}\n___________________________\n• Exit > .exit\n• Sell exp > .sell-exp\n___________________________`);
}
break

case '.exit': {
 const userPhoneExit = `${m.sender.split('@')[0]}`;
 const expDataExit = loadExpData();
 if (!expDataExit[userPhoneExit]) {
 expDataExit[userPhoneExit] = { exp: 0, hunts: [] };
 }
 expDataExit[userPhoneExit].hunts = currentHunts; // Simpan data buruan yang dilakukan
 saveExpData(expDataExit);
 currentHunts = []; // Reset data buruan
 await reply('Perburuan selesai. Data buruan Anda telah direset, EXP tetap tersimpan.');
}
break







case 'introme': {
 const introMessage = `
0ཻུ۪۪ꦽꦼ̷⸙‹•══════════════♡᭄
│ *「 Kartu Intro 」*
│ *BotName:* ${global.botname}
│ *Runtime :* ${runtime (process.uptime ())}
│ *Nama :* ${global.ownername}
│ *Gender :* *Cowo*
│ *Umur :* 15
│ *Hobby :* Ngoding, membaca
│ *Status :* Jinggel
│ *Asal :* Sulteng
│ *Agama :* Kristen
│ *Nomor :* ${m.sender.split('@')[0]}
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
`;

 // Send the introduction message
 kayyoffc.sendMessage(m.chat, { text: introMessage }, { quoted: fcall });
}
break

case "ngl": {
 var c = text.split("|")[1]
 var v = text.split("|")[0]
 if (!c) throw `*Example:* ${prefix + command} username | halo`
 var x = `https://itzpire.com/tools/ngl?username=${v}&message=${c}`
 let { status } = await axios.get(x)
 m.reply(`Status: ${status}`)
}
break



case 'listonline': {
let id = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : from
let online = [...Object.keys(store.presences[id]), botNumber]
kayyoffc.sendText(from, 'List Online:\n\n' + online.map(v => '⭔ @' + v.replace(/@.+/, '')).join`\n`, m, { mentions: online })
}
break

case 'lirik':
 if (!text) return m.reply('judul lagunya apa?')
try {
 let progres = await (await fetch('https://api.shannmoderz.xyz/tools/lirik?query=' + text)).json();
let note = progres.result;
kayyoffc.sendMessage(m.chat, { image: { url: note.thumbnail }, caption: note.lyrics }, { quoted: m })
} catch (e) {
 m.reply('lagu tidak ada di daftar kami');
}
break

/*
case by shannz
visit: ‮https://whatsapp.com/channel/0029VagBdZ49MF92BygaM53t
jika ingin bereksperimen sendiri dengan api nya bisa kunjungi: https://api.shannmoderz.xyz/
*/
case 'play2': {
 if (isBan) return m.reply(mess.ban)
 if (!text) return m.reply(`*PERMINTAAN ERROR!! CONTOH :*\n> *.play not you*`)
 let res = await yts(text)
 let url = res.all;
 let result = url[Math.floor(Math.random() * url.length)]
 teks = `⏩ *PLAYING AUDIO*\n\n> *Judul : ${result.title}*\n> *Upload : ${result.ago}*\n> *Url : ${result.url}*\n> *RequestBy : ${pushname}*\n\n📦 *AUDIO SEDANG DIPROSES....*`
 kayyoffc.sendMessage(m.chat, { image: { url: result.thumbnail }, caption: teks }, { quoted: m })
 let shanz = await (await fetch('https://api.shannmoderz.xyz/downloader/ytdl?url=' + result.url)).json();
 let finish = shanz.result.audio;
 kayyoffc.sendMessage(m.chat,{ audio: { url: finish['128'].url }, mimetype: 'audio/mp4' },{ quoted: m })
}
break

case 'ytmp32': {
 if (isBan) return m.reply(mess.ban)
 if (!text) return m.reply('*PERMINTAAN ERROR!! CONTOH :*\n> *.ytmp3 <link youtube>*')
 let procees = await (await fetch(`https://api.shannmoderz.xyz/downloader/ytdl?url=${text}`)).json()
 let audio = procees.result;
 m.reply(`*AUDIO PROSES SENDING...*`)
 kayyoffc.sendMessage(m.chat, {audio: {url: audio.audio['128'].url}, mimetype: 'audio/mp4' },{quoted: m})
}
break 

case 'ytmp42': {
 if (isBan) return m.reply(mess.ban)
 if (!text) return m.reply('*PERMINTAAN ERROR!! CONTOH :*\n> *.ytmp4 musik*')
 let proces = await (await fetch(`https://api.shannmoderz.xyz/downloader/ytdl?url=${text}`)).json()
 let video = proces.result;
 m.reply(`*VIDEO PROSES SENDING...*`)
 kayyoffc.sendMessage(m.chat,{video:{url: video.video['480'].url}, caption: proces.result.title},{quoted: m})
}
break





case 'anime-cringe': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://api.waifu.pics/sfw/cringe'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "[◇No Tawar Tawar Jadiin Sticker Aja📦"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break

case 'anime-cuddle': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://api.waifu.pics/sfw/cuddle'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "[Simpen aja mangge📦"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break

case 'anime-awoo': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://api.waifu.pics/sfw/awoo'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "◇No Afaan Tuh, Bawa pulang aja📦"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break

case 'woof':
case '8ball':
case 'goose':
case 'gecg':
case 'feed':
case 'avatar':
case 'fox_girl':
case 'lizard':
case 'meow':{
 axios.get(`https://nekos.life/api/v2/img/${command}`)
.then(({data}) => {
kayyoffc.sendImageAsSticker(from, data.url, m, { packname: global.packname, author: global.author })
})
}
break





case 'henivid': case 'hentai': case 'hentaivideo': {
 await reply('loding')
 const { hentai } = require('./lib/scraper.js')
 anu = await hentai()
 result912 = anu[Math.floor(Math.random(), anu.length)]
 let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `${global.botname} Title : ${result912.title}\n${global.botname} Category : ${result912.category}\n${global.botname} Mimetype : ${result912.type}\n${global.botname} Views : ${result912.views_count}\n${global.botname} Shares : ${result912.share_count}\n${global.botname} Source : ${result912.link}\n${global.botname} Media Url : ${result912.video_1}`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({ video: { url: result912.video_1 } }, { upload: kayyoffc.waUploadToServer })
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\"🌿\",\"id\":\""}`
 }],
 }), 
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363287688699869@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: m })
return await kayyoffc.relayMessage(m.chat, msgs.message, {})
 
 }
 break

case 'smeme': case 'stickermeme': case 'stickmeme': {

if (!/webp/.test(mime) && /image/.test(mime)) {
if (!text) return reply(`Usage: ${prefix + command} text1|text2`)
let { TelegraPh } = require('./lib/uploader')

atas = text.split('|')[0] ? text.split('|')[0] : '-'
bawah = text.split('|')[1] ? text.split('|')[1] : '-'
mee = await kayyoffc.downloadAndSaveMediaMessage(quoted)

mem = await TelegraPh(mee)

meme = `https://api.memegen.link/images/custom/${encodeURIComponent(atas)}/${encodeURIComponent(bawah)}.png?background=${mem}`

memek = await kayyoffc.sendImageAsSticker(m.chat, meme, m, { packname: global.packname, author: global.author })


} else {
reply(`Send/reply image with caption ${prefix + command} text1|text2`)
}
}

break



case 'itunes': {
if (!text) return reply('Please provide a song name')
 try {
 let res = await fetch(`https://api.popcat.xyz/itunes?q=${encodeURIComponent(text)}`)
 if (!res.ok) {
 throw new Error(`API request failed with status ${res.status}`)
 }
 let json = await res.json()
 console.log('JSON response:', json)
 let songInfo = 
 `*Song Information:*\n
 • *BotName;* ${global.botname}\n
 • *Name:* ${json.name}\n
 • *Artist:* ${json.artist}\n
 • *Album:* ${json.album}\n
 • *Release Date:* ${json.release_date}\n
 • *Price:* ${json.price}\n
 • *Length:* ${json.length}\n
 • *Genre:* ${json.genre}\n
 • *URL:* ${json.url}`
 // Check if thumbnail is present, then send it with songInfo as caption
 if (json.thumbnail) {
 let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: songInfo
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({image: {url:json.thumbnail}}, { upload: kayyoffc.waUploadToServer })
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\"Nice ✨\",\"id\":\""}`
 }],
 }), 
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363287688699869@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: m })
await kayyoffc.relayMessage(m.chat, msgs.message, {})
 } else {
 reply(songInfo)
 }
 } catch (error) {
 console.error(error)
 }
}
break

case 'diffusionv5':{
if (!text) return reply('What do u want to make?')
 let myHeaders = new Headers();
 myHeaders.append("Content-Type", "application/json");
 let raw = JSON.stringify({
 "key": "TouFyL4VyhWWNhqC3DnF5hAdR2fLXxgGY4Gpe4BqC8YGKE2j4NjuNrJAXetE",
 "prompt": text,
 "negative_prompt": "=",
 "width": "720",
 "height": "720",
 "samples": "1",
 "num_inference_steps": "20",
 "seed": null,
 "guidance_scale": 7.5,
 "safety_checker": "yes",
 "multi_lingual": "no",
 "panorama": "no",
 "self_attention": "no",
 "upscale": "no",
 "embeddings_model": null,
 "webhook": null,
 "track_id": null
 });
 var requestOptions = {
 method: 'POST',
 headers: myHeaders,
 body: raw,
 redirect: 'follow'
 };
 try {
 let response = await fetch("https://stablediffusionapi.com/api/v3/text2img", requestOptions);
 let result = await response.json();
 let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: '> Diffusion AI\n\n' + result.meta.prompt
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({ image: { url: result.output[0] } }, { upload: kayyoffc.waUploadToServer })
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\"✨\",\"id\":\"\"}`
 }],
 }),
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363287688699869@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: m })
await kayyoffc.relayMessage(m.chat, msgs.message, {})
 } catch (error) {
 console.log('error', error);
 let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: text
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({ image: { url: `${error.config.url}` } }, { upload: kayyoffc.waUploadToServer })
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\"✨\",\"id\":\"\"}`
 }],
 }),
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363287688699869@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: m })
await kayyoffc.relayMessage(m.chat, msgs.message, {})
 }
}
break

case 'photoleap': {
	if (!text) return reply(`Example : ${prefix + command} blue sea`);
 let currentTime = Date.now();
 let lastUsed = 0;
 if (currentTime - lastUsed < 10000) return reply("Cooldown 10 seconds, try again later");
 lastUsed = currentTime;
 try {
 let gpt = await (await fetch(`https://tti.photoleapapp.com/api/v1/generate?prompt=${text}`)).json();
 let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: '> Photo Leap AI\n\n' + text
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({ image: { url: gpt.result_url } }, { upload: LorenzoBotInc.waUploadToServer })
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\"✨\",\"id\":\"\"}`
 }],
 }),
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363287688699869@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: m })
await kayyoffc.relayMessage(m.chat, msgs.message, {})
 } catch(e) {
 return reply("`*Error*`");
 }
}
break

case 'emi-ai': {
	if (!text) return reply(`Example : ${prefix + command} a girl singing in public`); 
 try {
let gpt = await (await fetch(`https://itzpire.com/ai/emi?prompt=${text}`)).json()
let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `> Emi AI\n\n_*Here is the result of: ${text}*_`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({ image: { url: gpt.result }}, { upload: LorenzoBotInc.waUploadToServer }) 
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\"Nice 👀\",\"id\":\"\"}`
 }],
 }),
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363287688699869@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: m })
await kayyoffc.relayMessage(m.chat, msgs.message, {})
 } catch(e) {
 return reply("`*Error*`")
}
}
 break



case 'neon': {
 let [text1, text2] = text.split("|")

 if (!text1) {
 return reply(`*Harap beri teks untuk efek neon!*`)
 }

 try {
 let imageUrl = `https://api.betabotz.org/api/textpro/neon-light?text=${encodeURIComponent(text1)}&apikey=p8ADYJib`

 if (text2) {
 imageUrl += `&text2=${encodeURIComponent(text2)}`
 }

 await kayyoffc.sendMessage(m.chat, { 
 image: { url: imageUrl } 
 }, { quoted: m })

 } catch (error) {
 console.error('Error:', error)
 reply('*Terjadi kesalahan saat mencoba membuat gambar. Harap coba lagi nanti.*')
 }
}
break



async function fakechat(text, name, url) {
 let body = {
 "type": "quote",
 "format": "webp",
 "backgroundColor": "#FFFFFF",
 "width": 512,
 "height": 512,
 "scale": 2,
 "messages": [{
 "avatar": true,
 "from": {
 "first_name": name,
 "language_code": "en",
 "name": name,
 "photo": {
 "url": url
 }
 },
 "text": text,
 "replyMessage": {}
 }]
 }
 let res = await axios.post('https://bot.lyo.su/quote/generate', body);
 return Buffer.from(res.data.result.image, "base64");
}




// Dashboard Command
case 'dashboard': {
 const userId = m.sender.split('@')[0];
 const expData = JSON.parse(fs.readFileSync(expFilePath));
 const userExp = expData[userId] || { job: null, exp: 0 };

 if (userExp.job === null) {
 // User not registered
 reply("_______________________________\n *[DashBoard]*\nTIDAK ADA PEKERJAAN\nKETIK .KERJA UNTUK MENDAFTAR\n________________________________");
 } else {
 // User registered
 const jobInfo = userExp.job;
 reply(`______________________________\n *[DashBoard]*\n🖋 ▪*Nama :* ${jobInfo.name}\n💼 ▪*Pekerjaan :* ${jobInfo.job}\n💹 ▪*Pendapatan :* ${userExp.exp}💴\n📆 ▪*Tanggal Pensi : * ${jobInfo.retireDate}\n☎ ▪*Nomor Telepon :* ${userId}\n💳 ▪*Kredit Cards :* [${generateRandomCard()}]`);
 }
}
break;

// Work Command
case 'kerja': {
 const [name, age] = text.split('|');
 if (!name || !age) return reply('Format salah, silakan ketik `.kerja <nama>|<umur>`');

 const userId = m.sender.split('@')[0];
 const userExpData = JSON.parse(fs.readFileSync(expFilePath));
 const newJob = selectRandomJob();

 // Save user job and exp
 userExpData[userId] = {
 job: {
 name: name,
 job: newJob.name,
 retireDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()
 },
 exp: getRandomExp(newJob.rank)
 };

 fs.writeFileSync(expFilePath, JSON.stringify(userExpData, null, 2));
 reply(`Selamat ${name}! Anda telah mendaftar sebagai ${newJob.name} dengan rank ${newJob.rank}. Anda akan mendapatkan ${userExpData[userId].exp}💴 sebagai pendapatan.`);
}
break;



case 'genshin-stalk': {
 if (!text) {
 return reply(`Example :\n${prefix + command} <UID>\n\nExample :\n${prefix + command} 830980536`);
 }

 const wait = await loading();

 try {
 let res = await fetch(`https://enka.network/api/uid/${text}`);
 let data = await res.json();
 let playerInfo = data.data;

 if (res.ok) {
 let nickname = data.playerInfo.nickname || 'Not found';
 let arLevel = data.playerInfo.level || 'Not found';
 let signature = data.playerInfo.signature || 'Not found';
 let worldLevel = data.playerInfo.worldLevel || 'Not found';
 let achievement = data.playerInfo.finishAchievementNum || 'Not found';
 let spiralFloorIndex = data.playerInfo.towerFloorIndex || 'Not found';
 let spiralLeverIndex = data.playerInfo.towerLevelIndex || 'Not found';

 let ssurl = `https://enka.network/u/${text}`;
 let screenshotUrl = `${ssurl}`;
 let screenshot = await captureScreenshot(screenshotUrl);

 let profileMessage = `
 _The Data Below May Not Be Exact Due to_
 _There is Delay in Data Capture!_
 
 ❏─────• *Genshin Profile Info* •───┈➤➤
 ┊
 ┊❖﹐Nickname: ${nickname} - AR ${arLevel}
 ┊❖﹐Signature: ${signature}
 ┊✤﹐World Level: ${worldLevel}
 ┊✧﹐Achievement: ${achievement}
 ┊
 ❏───────- *Challenge* -────────
 ┊
 ┊✥﹐Spiral Abbys: ${spiralFloorIndex} - ${spiralLeverIndex}
 ┊
 ╰┈➤ More Details At:
 ❀ https://enka.network/u/${text}
 
 ✧ UID: ${text}
 `.trim();

 await kayyoffc.sendFile(m.chat, screenshot.result, 'screenshot.jpg', profileMessage, m);
 } else {
 if (res.status === 400) {
 reply('UID format is incorrect. Please enter a valid UID.');
 } else if (res.status === 404) {
 reply('Player not found. Please double check the UID or player name.');
 } else if (res.status === 424) {
 reply('Server is under maintenance or experiencing issues after a game update. Please try again later.');
 } else if (res.status === 429) {
 reply('You have reached the request limit. Please wait a moment before making another request.');
 } else if (res.status === 500) {
 reply('An error occurred on the server. Please try again later.');
 } else if (res.status === 503) {
 replygcLorenzo('A major error occurred in the application. We will fix it soon.');
 } else {
 reply('There was an error loading the data. Please try again later.');
 }
 }
 } catch (e) {
 reply(e);
 }
};
break





case 'dress': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://fantox-apis.vercel.app/dress'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Random Anime Character"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break



case 'genshin': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://fantox-apis.vercel.app/genshin'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Random Anime Character"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break

case 'bikini': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://fantox-apis.vercel.app/bikini'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Random Anime Character"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break

case 'sss': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://fantox-apis.vercel.app/schoolswimsuit'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Random Anime Character"; // Ganti ini jika API menyedia

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break

case 'uniform': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://fantox-apis.vercel.app/uniform'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Random Anime Character"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break

case 'headband': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://fantox-apis.vercel.app/headband'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Random Anime Character"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*$*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break

case 'underwear': {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://fantox-apis.vercel.app/underwear'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Random Anime Character"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break

case 'genshin':
case 'blonde':
case 'pinkhair':
case 'swimsuit':
case 'white':
case 'barefoot':
case 'touhou':
case 'gamecg':
case 'hololive':
case 'uncensored':
case 'sungglasses':
case 'glasses':
case 'weapon':
case 'shirtlift':
case 'chain':
case 'fingering':
case 'flatchest':
case 'torncloth':
case 'bondage':
case 'pantypull':
case 'headdress':
case 'headphone':
case 'anusview':
case 'shorts':
case 'stokings':
case 'topless':
case 'beach':
case 'bunnygirl':
case 'bunnyear':
case 'vampire':


case 'spotifyv2':{
	if (!text) return reply(`*Please enter a song name*`)
 try {
 const apiUrl = `https://www.guruapi.tech/api/spotifyinfo?text=${encodeURIComponent(text)}`
 const response = await fetch(apiUrl);
 if (!response.ok) {
 console.log('Error searching for song:', response.statusText)
 return reply('Error searching for song')
 }
 const data = await response.json()
 const coverimage = data.spty.results.thumbnail
 const name = data.spty.results.title
 const slink = data.spty.results.url
 const dlapi = `https://www.guruapi.tech/api/spotifydl?text=${encodeURIComponent(text)}`
 const audioResponse = await fetch(dlapi)
 if (!audioResponse.ok) {
 console.log('Error fetching audio:', audioResponse.statusText)
 return reply('Error fetching audio')
 }
 const audioBuffer = await audioResponse.buffer()
 const tempDir = os.tmpdir()
 const audioFilePath = path.join(tempDir, 'audio.mp3')
 try {
 await fs.promises.writeFile(audioFilePath, audioBuffer)
 } catch (writeError) {
 console.error('Error writing audio file:', writeError)
 return reply( 'Error writing audio file')
 }
 let doc = {
 audio: {
 url: audioFilePath
 },
 mimetype: 'audio/mpeg',
 ptt: true,
 waveform: [100, 0, 100, 0, 100, 0, 100],
 fileName: "Lorenzxz",
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 title: `PLAYING TO ${name}`,
 body: botname,
 thumbnailUrl: coverimage,
 sourceUrl: websitex,
 mediaType: 1,
 renderLargerThumbnail: true
 }
 }
 } 
 await kayyoffc.sendMessage(m.chat, doc, { quoted: m })
 } catch (error) {
 console.error('Error fetching Spotify data:', error)
 return reply('*Error*')
 }
 }
 break





case 'tts': {
 const defaultLang = 'id';
 const gtts = require('node-gtts');
 const fs = require('fs'); // Pastikan fs diimpor

 // Menampilkan pesan instruksi saat hanya mengetik command tts
 if (args.length === 0) {
 return m.reply(`*[TEXT TO SPEECH]*\n\n[♧ hi ${m.sender.split('@')[0]}]\n\n[.tts] [Your Text]\n■ .tts <your text> | <tempo 1-900> | <pitch 1-900> | <lang (id lang)>\n\n■ pitch for male [150]\n\n■ pitch for female [180]\n\n■ pitch for girl [200]\n\n■ pitch for underwater [120]\n\n■ pitch for robot [250]\n\n\n*[ID LANGUAGE]*\n\n\n■ 🇲🇨 [id] indonesia\n■ *🇬🇧 [en] english*\n■ *🇪🇸 [es] español*\n■ *🇫🇷 [fr] français*\n■ *🇩🇪 [de] deutsch*\n■ *🇮🇹 [it] italiano*\n■ *🇯🇵 [ja] 日本語*\n■ *🇰🇷 [ko] 한국어*\n■ 🇨🇳 [zh] 中文\n■ *🇷🇺 [ru] русский*\n■ *🇧🇷 [pt] português*\n■ *🇦🇷 [ar] العربية*\n■ *🇹🇷 [tr] türkçe*\n■ *🇳🇱 [nl] nederlands*\n■ *🇸🇪 [sv] svenska*\n■ *🇳🇴 [no] norsk*`);
 }

 // Menggabungkan argumen menjadi satu string dan memisahkannya berdasarkan '|'
 const input = args.join(' ').split('|').map(arg => arg.trim());
 
 // Mengambil input berdasarkan posisi
 let text = input[0]; // Teks harus ada
 let tempo = input[1] ? parseInt(input[1]) : 100; // Default tempo 100
 let pitch = input[2] ? parseInt(input[2]) : 150; // Default pitch 150
 let lang = input[3] || defaultLang; // Mengambil bahasa dari argumen (default ke 'id')

 // Validasi tempo dan pitch
 if (tempo < 1 || tempo > 900) {
 return m.reply('Tempo harus berada di antara 1 hingga 900.');
 }
 if (pitch < 1 || pitch > 900) {
 return m.reply('Pitch harus berada di antara 1 hingga 900.');
 }

 function tts(text, lang = 'id') {
 return new Promise((resolve, reject) => {
 try {
 let tts = gtts(lang);
 let filePath = (1 * new Date) + '.mp3';
 tts.save(filePath, text, () => {
 resolve(fs.readFileSync(filePath));
 fs.unlinkSync(filePath); // Menghapus file setelah dibaca
 });
 } catch (e) {
 reject(e);
 }
 });
 }

 let res;
 try {
 res = await tts(text, lang);
 } catch (e) {
 m.reply(e + '');
 res = await tts(text, defaultLang);
 } finally {
 if (res) {
 await kayyoffc.sendMessage(m.chat, {
 audio: res,
 ptt: true,
 mimetype: "audio/mpeg",
 fileName: "vn.mp3",
 waveform: [100, 0, 100, 0, 100, 0, 100]
 }, { quoted: m });
 }
 }
}
break



case 'trn':
case 'translate': {
 const gtranslate = require('@vitalets/google-translate-api'); // Pastikan Anda mengimpor library ini
 const fs = require('fs');

 // Menampilkan pesan instruksi saat hanya mengetik command trn
 if (args.length === 0) {
 return m.reply(`*[TRANSLATE]*\n[♧ hi ${m.sender.split('@')[0]}]\n[.trn] [Your Text] | <id negara>\n\n*[ID NEGARA]*\n■ 🇦🇫 [af] afghanistan\n\n■ 🇦🇱 [sq] albanian\n\n■ 🇩🇿 [ar] algerian\n\n■ 🇦🇸 [en] american samoa\n\n■ 🇦🇺 [en] australia\n\n■ 🇦🇹 [de] austria\n\n■ 🇧🇪 [fr] belgium\n\n■ 🇧🇷 [pt] brazil\n\n■ 🇧🇬 [bg] bulgaria\n\n■ 🇨🇦 [en] canada\n\n■ 🇨🇱 [es] chile\n\n■ 🇨🇳 [zh] china\n\n■ 🇭🇷 [hr] croatia\n\n■ 🇨🇿 [cs] czech\n\n■ 🇩🇰 [da] denmark\n\n■ 🇪🇪 [et] estonia\n\n■ 🇫🇮 [fi] finland\n\n■ 🇫🇷 [fr] france\n\n■ 🇩🇪 [de] germany\n\n■ 🇬🇷 [el] greece\n\n■ 🇭🇺 [hu] hungary\n\n■ 🇮🇸 [is] iceland\n\n■ 🇮🇳 [hi] india\n\n■ 🇮🇩 [id] indonesia\n\n■ 🇮🇪 [ga] ireland\n\n■ 🇮🇱 [he] israel\n\n■ 🇯🇵 [ja] japan\n\n■ 🇯🇱 [en] jersey\n\n■ 🇰🇿 [kk] kazakhstan\n\n■ 🇰🇷 [ko] korea\n\n■ 🇰🇼 [ar] kuwait\n\n■ 🇱🇧 [ar] lebanon\n\n■ 🇱🇹 [lt] lithuania\n\n■ 🇱🇺 [lb] luxembourg\n\n■ 🇲🇹 [mt] malta\n\n■ 🇲🇦 [ar] morocco\n\n■ 🇲🇽 [es] mexico\n\n■ 🇲🇾 [ms] malaysia\n\n■ 🇳🇱 [nl] netherlands\n\n■ 🇳🇴 [no] norway\n\n■ 🇵🇱 [pl] poland\n\n■ 🇵🇱 [pt] portugal\n\n■ 🇷🇺 [ru] russia\n\n■ 🇸🇬 [en] singapore\n\n■ 🇸🇰 [sk] slovakia\n\n■ 🇸🇮 [sl] slovenia\n\n■ 🇪🇸 [es] spain\n\n■ 🇸🇪 [sv] sweden\n\n■ 🇨🇭 [fr] switzerland\n\n■ 🇹🇭 [th] thailand\n\n■ 🇺🇦 [uk] ukraine\n\n■ 🇬🇧 [en] united kingdom\n\n■ 🇺🇸 [en] united states\n\n■ 🇻🇪 [es] venezuela\n\n■ 🇻🇳 [vi] vietnam\n\n■ 🇾🇪 [ar] yemen\n\n■ 🇿🇦 [en] south africa\n\n■ 🇿🇲 [en] zambia\n\n■ 🇿🇼 [en] zimbabwe\n\n■ 🇹🇿 [sw] tanzania\n\n■ 🇰🇪 [sw] kenya`);
 }

 // Menggabungkan argumen menjadi satu string dan memisahkannya berdasarkan '|'
 const input = args.join(' ').split('|').map(arg => arg.trim());
 
 // Mengambil input berdasarkan posisi
 let text = input[0]; // Teks harus ada
 let lang = input[1]; // Mengambil kode negara dari argumen

 if (!text || !lang) {
 return m.reply('Silakan masukkan teks dan kode negara yang valid. Contoh: .trn Hello World | en');
 }

 try {
 const result = await gtranslate(text, { to: lang });
 m.reply(result.text);
 } catch (error) {
 m.reply('Terjadi kesalahan saat menerjemahkan: ' + error.message);
 }
}
break



;

;

;

case 'play': {
 const fs = require('fs');
 const path = require('path');
 const ytdl = require('ytdl-core');
 
 const defaultLang = 'id';
 
 // Nama folder untuk menyimpan file sementara
 const tempDir = path.join(__dirname, 'temp');

 // Membuat folder jika belum ada
 if (!fs.existsSync(tempDir)) {
 fs.mkdirSync(tempDir);
 }

 const songName = args.join(' '); // Mengambil nama lagu dari argumen

 // Kirim pesan "Please wait..."
 await m.reply("Please wait...");

 // Mencari dan memutar lagu
 try {
 // Mengambil informasi tentang lagu
 const songInfo = await ytdl.getInfo(songName);
 const audioFilePath = path.join(tempDir, `${Date.now()}.mp3`);

 // Mengunduh audio dan menyimpannya ke file
 const audioStream = ytdl(songInfo.videoDetails.video_url, { filter: 'audioonly' });
 const writeStream = fs.createWriteStream(audioFilePath);

 audioStream.pipe(writeStream);

 writeStream.on('finish', async () => {
 console.log(`File audio telah diunduh: ${audioFilePath}`);

 // Mengirim file audio
 await kayyoffc.sendMessage(m.chat, {
 audio: fs.createReadStream(audioFilePath),
 ptt: true,
 mimetype: "audio/mpeg",
 fileName: "vn.mp3",
 waveform: [100, 0, 100, 0, 100, 0, 100]
 }, { quoted: m });

 // Menghapus file setelah dikirim
 fs.unlinkSync(audioFilePath);
 console.log(`File audio telah dihapus: ${audioFilePath}`);
 });

 } catch (error) {
 console.error('Terjadi kesalahan:', error);
 await m.reply("Terjadi kesalahan saat mencoba memutar lagu.");
 }
}
 break;

case 'allmenu':
case 'semuamenu':
case 'totalmenu':
 {
let { listCase } = require('./lib/scrapelistCase.js')
reply(listCase())
}
break

case "tebakbomb": case "bomb": {
if (!m.chat) return m.reply(mess.chat)
if (m.chat) return kayyofc.sendText(m.chat, "Masih ada game yang belum terselsaikan!", kayyoffc.bomb[m.chat][0]);
kayyoffc.bomb = kayyoffc.bomb ? kayyoffc.bomb : {};
let id = m.chat,
timeout = 180000;
const bom = ['💥', '✅', '✅', '✅', '✅', '✅', '✅', '✅', '✅'].sort(() => Math.random() - 0.5);
const number = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣'];
const array = bom.map((v, i) => ({
emot: v,
number: number[i],
position: i + 1,
state: false
}));
let teks = `*🎮 GAME TEBAK BOM 🎮*\n\nKirim angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :\n\n`;
for (let i = 0; i < array.length; i += 3) teks += array.slice(i, i + 3).map(v => v.state ? v.emot : v.number).join('') + '\n';
teks += `\nWaktu : *${((timeout / 1000) / 60)} menit*\nHadiah : *Random Balance*\n\nApabila mendapat kotak yang berisi bom maka *Hadiah* tidak di berikan`;
let msg = await kayyoffc.sendText(m.chat, teks, kayyoffc.bomb[id] ? kayyoffc.bomb[id][0] : m);
let { key } = msg

let v;
kayyoffc.bomb[id] = [
msg,
array,
setTimeout(() => {
v = array.find(v => v.emot == '💥');
if (kayyoffc.bomb[id]) kayyoffc.sendText(m.chat, `*Waktu habis*\n\nKotak yang berisi bom ${v.number} tidak terbuka\nGame dihentikan!`, kayyoffc.bomb[id][0]);
delete kayyoffc.bomb[id];
}, timeout),
key
];
}
break



;

// Menangani balasan dari pengguna
case 'replybomb': {
 if (!global.bombData || !global.bombData.isGameActive) {
 return reply('Permainan tebak bomb belum dimulai atau telah selesai.');
 }

 const userGuess = parseInt(m.content); // Asumsikan `m.content` adalah konten balasan

 if (userGuess < 1 || userGuess > 9 || isNaN(userGuess)) {
 return reply('Masukkan angka antara 1 hingga 9.');
 }

 let response = '';
 if (userGuess === global.bombData.bombLocation) {
 response = `💣 Anda Kalah! Bom ada di lokasi ${global.bombData.bombLocation}.\n`;
 } else {
 response = `✔ Lokasi yang Anda pilih ${userGuess} aman!\n`;
 // Mengganti simbol yang dipilih user dengan ✔
 const index = Math.floor((userGuess - 1) / 3);
 global.bombData.options[index] = global.bombData.options[index].replace('⚫', '✔');
 }

 // Kirim kembali hasil tebakan dan peta
 response += "_______________\n*Tebak Bomb*\n\n";
 global.bombData.options.forEach((option, index) => {
 response += `${option} ( = ${index * 3 + 1}-${(index + 1) * 3})\n`;
 });
 response += "_______________";

 await reply(response);

 // Menandai permainan selesai
 if (userGuess === global.bombData.bombLocation) {
 global.bombData.isGameActive = false; // Menandai bahwa permainan telah selesai
 delete global.bombData; // Menghapus data setelah permainan selesai
 }
}
break

case 'tebakbom': {
 const bombLocation = Math.floor(Math.random() * 9) + 1; // Lokasi bom antara 1 dan 9
 const options = [
 '⚫⚫⚫', // 1-3
 '⚫⚫⚫', // 4-6
 '⚫⚫⚫', // 7-9
 ];

 // Kirim pesan awal
 let message = `_______________\n*Tebak Bomb*\n\n`;
 options.forEach((option, index) => {
 message += `${option} ( = ${index * 3 + 1}-${(index + 1) * 3})\n`;
 });
 message += "_______________\n\nSilakan balas dengan angka 1-9 untuk menebak lokasi bom.";
 
 await reply(message);

 // Simpan data permainan
 activeGames[m.sender] = {
 bombLocation: bombLocation,
 options: options,
 isGameActive: true,
 };
}
break;

// Menangani balasan dari pengguna
case 'replybomb': {
 const gameData = activeGames[m.sender]; // Ambil data permainan berdasarkan pengirim
 if (!gameData || !gameData.isGameActive) {
 return reply('Permainan tebak bomb belum dimulai atau telah selesai.');
 }

 const userGuess = parseInt(m.content); // Asumsikan `m.content` adalah konten balasan

 if (userGuess < 1 || userGuess > 9 || isNaN(userGuess)) {
 return reply('Masukkan angka antara 1 hingga 9.');
 }

 let response = '';
 if (userGuess === gameData.bombLocation) {
 response = `💣 Anda Kalah! Bom ada di lokasi ${gameData.bombLocation}.\n`;
 gameData.isGameActive = false; // Menandai permainan telah selesai
 } else {
 response = `✔ Lokasi yang Anda pilih ${userGuess} aman!\n`;
 // Mengganti simbol yang dipilih user dengan ✔
 const index = Math.floor((userGuess - 1) / 3);
 gameData.options[index] = gameData.options[index].replace('⚫', '✔');
 }

 // Kirim kembali hasil tebakan dan peta
 response += "_______________\n*Tebak Bomb*\n\n";
 gameData.options.forEach((option, index) => {
 response += `${option} ( = ${index * 3 + 1}-${(index + 1) * 3})\n`;
 });
 response += "_______________";

 await reply(response);

 // Jika pengguna kalah, hapus data permainan
 if (!gameData.isGameActive) {
 delete activeGames[m.sender]; // Hapus data permainan
 }
}
break



case 'anime-biduan': {
 // Mengirim pesan tunggu
 await reply("📌 Mencari BiduanNime");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://api.waifu.pics/sfw/dance'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "♡Bungkus aja free Kok📦"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 video: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break

case 'nobra':
case 'whitehair':
case 'bed':
case 'nude':
case 'breast':
case 'spreadpussy':
case 'seethrough':
 {
 // Mengirim pesan tunggu
 await reply("📌 Wait...");

 try {
 // Mengambil gambar anime secara acak dari API
 let response = await axios.get('https://api.waifu.pics/nsfw/${command}'); // Ganti dengan URL API yang sesuai
 let animeImage = response.data.url; // URL gambar
 let characterName = "Random Anime Character"; // Ganti ini jika API menyediakannya

 // Mengirim gambar ke chat dengan struktur yang diinginkan
 await kayyoffc.sendMessage(m.chat, {
 image: { url: animeImage },
 caption: `*[${characterName}]*`, // Menampilkan nama karakter
 }, { quoted: m });
 } catch (error) {
 console.error('Error fetching anime image:', error);
 await reply('❌ Error fetching image, please try again later.');
 }
}
break

case 'qcs': {
if (!q) return reply(`📌Example: ${prefix + command} hallo`)
let obj = {
type: 'quote',
format: 'png',
backgroundColor: '#ffffff',
width: 512,
height: 768,
scale: 2,
messages: [
{
entities: [],
avatar: true,
from: {
id: 1,
name: pushname,
photo: { 
url: await kayyoffc.profilePictureUrl(m.sender, "image").catch(() => 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'),
}
},
text: `${q}`,
replyMessage: {},
},
],
};
let response = await axios.post('https://bot.lyo.su/quote/generate', obj, {
headers: {
'Content-Type': 'application/json',
},
});
let buffer = Buffer.from(response.data.result.image, 'base64');
kayyoffc.sendImageAsSticker(m.chat, buffer, fcall, { packname: `${global.packname}`, author: `${global.author}`})
}
break

case 'spotify': {
if (!text) return reply(`Contoh : ${prefix + command} dandelion`);
let api = await fetchJson(`https://api.junn4.my.id/search/spotify?query=${text}`);
const hasil = `乂 *S P O T I F Y*

*Title*: ${api.data[0].title}
*Duration*: ${api.data[0].duration}
*Popular*: ${api.data[0].popularity}
*Url*: ${api.data[0].url}
`
kayyoffc.sendMessage(m.chat, {text: hasil, contextInfo:
{
"externalAdReply": {
"title": '𝙎𝙥𝙤𝙩𝙞𝙛𝙮𝙈𝙪𝙨𝙞𝙘',
"body": `I am ${global.botname}`,
"showAdAttribution": true,
"mediaType": 1,
"sourceUrl": '',
"thumbnailUrl": 'https://telegra.ph/file/50afb355fac55370492de.jpg',
"renderLargerThumbnail": true
}
}}, {quoted: fcall})
const spodl = await fetchJson(`https://api.junn4.my.id/download/spotify?url=${api.data[0].url}`) 
const spoDl = spodl.data.download
kayyoffc.sendMessage(m.chat, {
audio: {
url: spoDl
},
mimetype: 'audio/mpeg',
contextInfo: {
externalAdReply: {
title: `𝙎𝙥𝙤𝙩𝙞𝙛𝙮𝙈𝙪𝙨𝙞𝙘`,
body: "",
thumbnailUrl: 'https://telegra.ph/file/d8283bf6f948413ad0e62.jpg', 
sourceUrl: hariini,
mediaType: 1,
showAdAttribution: true,
renderLargerThumbnail: true
}
}
}, {
quoted: fcall
})
}
break

case 'gimage': {
 if (!text) return m.reply(`gimage avosky`)
 m.reply(mess.wait)
 const axios = require('axios')
 const cheerio = require('cheerio')
// wm avs
 const nyariGambar = async (query) => {
 const url = `https://www.google.com/search?q=${encodeURIComponent(query)}&tbm=isch`
 const { data } = await axios.get(url)
 const $ = cheerio.load(data)
 let images = []
 $('img').each((i, elem) => {
 images.push($(elem).attr('src'))
 })
 return images
 }
// wm avs
 nyariGambar(text).then(images => {
 if (images.length === 0) {
 return reply('Tidak ada gambar.')
 }
 let imageAvz = images[Math.floor(Math.random() * images.length)]
 kayyoffc.sendMessage(m.chat, { image: { url: imageAvz }, caption: `*Query* : ${text}\n*Media Url* : ${imageAvz}` }, { quoted: m })
 }).catch(error => {
 reply('Terjadi kesalahan.')
 })
}
break

/* https://whatsapp.com/channel/0029VaGqCO6I1rcjc9hisJ3U/1083
*/

case "spotifyV2": {
if (!text) return m.reply("Masukan query!")
try {
let { data } = await require("axios")({
 "method": "GET",
 "url": "https://manaxu-seven.vercel.app/api/internet/spotify?query=" + text
})
let { result } = data
let { link } = result[Math.floor(Math.random() * result.length)]
let z = await require("axios")({
 "method": "GET",
 "url": "https://manaxu-seven.vercel.app/api/downloader/spotify?url=" + link
})
var { download, title } = z.data.result
kayyoffc.sendMessage(m.chat, { audio: { url: download }, mimetype: "audio/mp4", fileName: title + ".mp3" }, { quoted: m })
} catch (e) {
return m.reply("fitur error")
}
}
break







case 'addfile': {
 if (!isCreator) return m.reply(`Maaf, hanya creator yang bisa menggunakan perintah ini.`);
 
 let input = m.text.split(' ').slice(1).join(' '); // Ambil input setelah perintah .addfile
 if (!input.includes('|')) return reply('Format salah! Gunakan format: .addfile namaFile.js | Kode yang ingin disimpan');
 
 // Split hanya pada pemisah pertama '|' agar semua setelahnya dianggap sebagai kode
 let separatorIndex = input.indexOf('|');
 let filename = input.slice(0, separatorIndex).trim();
 let code = input.slice(separatorIndex + 1).trim(); // Ambil seluruh teks setelah '|'
 
 if (!filename || !code) return reply('Nama file dan kode tidak boleh kosong! Pastikan format sesuai dengan contoh: .addfile namaFile.js | Kode anda');
 
 // Validasi agar hanya menerima ekstensi file .js
 if (!filename.endsWith('.js')) return reply('Hanya file dengan ekstensi .js yang diperbolehkan.');
 
 // Tentukan path untuk menyimpan file
 let filepath = path.join(__dirname, 'lib', filename);

 // Simpan kode ke file
 fs.writeFile(filepath, code, (err) => {
 if (err) {
 console.error(err);
 return reply('Gagal menyimpan file. Silakan coba lagi.');
 }

 reply(`File "${filename}" berhasil disimpan di ./lib.`);
 });
};
break

case 'getfile': {
 if (!isCreator) return m.reply(`Maaf, hanya creator yang bisa menggunakan perintah ini.`);
 
 // Ambil input setelah perintah .getfile
 let filePath = m.text.split(' ').slice(1).join(' ').trim(); 
 if (!filePath) return reply('Silakan masukkan path file yang ingin diambil. Contoh: .getfile ./lib/index.js');
 
 // Pastikan filePath tidak keluar dari direktori yang diizinkan
 if (!filePath.startsWith('./lib') && !filePath.startsWith('./')) {
 return reply('Anda hanya bisa mengambil file dari direktori ./lib atau ./');
 }
 
 // Tentukan path absolut untuk file
 let absolutePath = path.resolve(__dirname, filePath);

 // Cek apakah file ada
 if (!fs.existsSync(absolutePath)) {
 return reply(`File "${filePath}" tidak ditemukan.`);
 }
 
 // Baca konten file
 fs.readFile(absolutePath, 'utf8', (err, data) => {
 if (err) {
 console.error(err);
 return reply('Terjadi kesalahan saat membaca file.');
 }

 // Kirim konten file kepada pengguna
 reply(`Konten dari file "${filePath}":\n\n${data}`);
 });
};
break

case 'cuaca': 
case 'weather': {
 // Ambil teks lokasi yang diberikan pengguna
 const text = m.text.split(' ').slice(1).join(' ');
 if (!text) return reply(`Penggunaan:\n${usedPrefix + command} <teks>\n\nContoh:\n${usedPrefix + command} Jakarta`);

 // Kirim pesan menunggu
 m.reply(wait);

 try {
 // Ambil data cuaca dari API
 let res = await fetch(API('https://api.openweathermap.org', '/data/2.5/weather', {
 q: text,
 units: 'metric',
 appid: '060a6bcfa19809c2cd4d97a212b19273'
 }));

 if (!res.ok) throw 'Lokasi tidak ditemukan';

 // Parsing hasil JSON dari API
 let json = await res.json();
 if (json.cod != 200) throw json;

 // Kirimkan hasil informasi cuaca kepada pengguna
 m.reply(`
Lokasi: ${json.name}
Negara: ${json.sys.country}
Cuaca: ${json.weather[0].description}
Suhu saat ini: ${json.main.temp} °C
Suhu tertinggi: ${json.main.temp_max} °C
Suhu terendah: ${json.main.temp_min} °C
Kelembapan: ${json.main.humidity} %
Angin: ${json.wind.speed} km/jam
 `.trim());

 } catch (err) {
 // Kirim pesan jika terjadi kesalahan
 reply('Terjadi kesalahan atau lokasi tidak ditemukan.');
 }}
 break



case 'susunkata':
case 'sskata': {
 // Pastikan susunkata sudah terinisialisasi
 if (!global.susunkata) {
 global.susunkata = {};
 }

 let id = m.chat;

 // Cek apakah sudah ada permainan susunkata yang berjalan di chat ini
 if (id in global.susunkata) {
 m.reply(' *Masih Ada Soal Yang Belum Terjawab* ');
 break;
 }

 try {
 // Ambil soal susunkata dari API
 let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/susunkata.json')).json();
 let json = src[Math.floor(Math.random() * src.length)]; // Ambil soal acak

 // Buat caption yang akan dikirim ke pengguna
 let caption = `
${json.soal}

Tipe : ${json.tipe}
Timeout *${(timeout / 1000).toFixed(2)} detik*
Ketik ${usedPrefix}suska untuk bantuan
Bonus: ${money} Money
Limit: ${limit} Limit
 `.trim();

 // Kirim pesan soal ke pengguna
 await kayyoffc.sendMessage(m.chat, { text: caption });

 // Simpan state permainan di global.susunkata
 global.susunkata[id] = [
 json, 
 money,
 setTimeout(() => {
 if (global.susunkata[id]) {
 kayyoffc.sendMessage(m.chat, { text: `Waktu habis!\nJawabannya adalah *${json.jawaban}*` });
 delete global.susunkata[id]; // Hapus state permainan setelah timeout
 }
 }, timeout)
 ];

 } catch (e) {
 m.reply('Terjadi kesalahan saat mengambil soal. Silakan coba lagi.');
 }}
 break












case 'logololi': {
 if (!text) return m.reply(`✳️ Masukkan teks\n\n📌 Contoh: *${prefix}logololi* mufar`);
 m.reply(mess.wait);
 let imgUrl = `${global.fgmod}/api/maker/loli?text=${encodeURIComponent(text)}&apikey=zjdbSRfz`;
 await kayyoffc.sendMessage(m.chat, { image: { url: imgUrl }, caption: '✅ Result' }, { quoted: m });
 break;
}

case 'neon': {
 if (!text) return m.reply(`✳️ Masukkan teks\n\n📌 Contoh: *${prefix}neon* mufar`);
 m.reply(mess.wait);
 let imgUrl = `${global.fgmod}/api/textpro/neon?text=${encodeURIComponent(text)}&apikey=zjdbSRfz`;
 await kayyoffc.sendMessage(m.chat, { image: { url: imgUrl }, caption: '✅ Result' }, { quoted: m });
 break;
}

case 'devil': {
 if (!text) return m.reply(`✳️ Masukkan teks\n\n📌 Contoh: *${prefix}devil* mufar`);
 m.reply(mess.wait);
 let imgUrl = `${global.fgmod}/api/textpro/devil?text=${encodeURIComponent(text)}&apikey=zjdbSRfz`;
 await kayyoffc.sendMessage(m.chat, { image: { url: imgUrl }, caption: '✅ Result' }, { quoted: m });
 break;
}

case 'wolf': {
 if (!text) return m.reply(`✳️ Masukkan teks\n\n📌 Contoh: *${prefix}wolf* mufar`);
 m.reply(mess.wait);
 let imgUrl = `${global.fgmod}/api/textpro/logowolf?text=FG98&text2=${encodeURIComponent(text)}&apikey=zjdbSRfz`;
 await kayyoffc.sendMessage(m.chat, { image: { url: imgUrl }, caption: '✅ Result' }, { quoted: m });
 break;
}

case 'phlogo': {
 if (!text) return m.reply(`✳️ Pisahkan teks dengan *+*\n\n📌 Contoh:\n*${prefix}phlogo* mufar *+* OnLasdan`);
 if (!text.includes('+')) return m.reply(`✳️ Pisahkan teks dengan *+*\n\n📌 Contoh:\n*${prefix}phlogo* mufar *+* OnLasdan`);
 let [a, b] = text.split('+').map(part => part.trim());
 m.reply(mess.wait);
 let imgUrl = `${global.fgmod}/api/textpro/pornhub?text=${encodeURIComponent(a)}&text2=${encodeURIComponent(b)}&apikey=zjdbSRfz`;
 await kayyoffc.sendMessage(m.chat, { image: { url: imgUrl }, caption: '✅ Result' }, { quoted: m });
 break;
}

case 'logo': {
 if (!text) return m.reply(`✳️ Masukkan teks\n\n📌 Contoh: *${prefix}logo* mufar`);
 m.reply(mess.wait);
 let imgUrl = `https://api.api-ninjas.com/v1/logo?text=${encodeURIComponent(text)}`;
 let options = {
 method: 'GET',
 headers: {
 'X-Api-Key': 'YhWZ+jP8JrrmMMKA+mYRhQ==pignwS5SmZW8GtLx'
 }
 };
 let response = await fetch(imgUrl, options);
 let data = await response.json();
 if (response.ok && data.url) {
 await kayyoffc.sendMessage(m.chat, { image: { url: data.url }, caption: '✅ Result' }, { quoted: m });
 } else {
 m.reply('❌ Gagal mendapatkan logo. Silakan coba lagi.');
 }
 break;
}

case 'logo2': {
 if (!text) return m.reply(`✳️ Masukkan teks\n\n📌 Contoh: *${prefix}logo* Microsoft`);
 m.reply(mess.wait);

 // URL API dengan parameter teks
 let apiUrl = `https://api.api-ninjas.com/v1/logo?name=${encodeURIComponent(text)}`;

 // Opsi untuk fetch request
 let options = {
 method: 'GET',
 headers: {
 'X-Api-Key': 'YhWZ+jP8JrrmMMKA+mYRhQ==pignwS5SmZW8GtLx'
 }
 };

 // Melakukan fetch request
 let response = await fetch(apiUrl, options);
 if (response.ok) {
 let data = await response.json();
 // Mengirim pesan dengan gambar
 await kayyoffc.sendMessage(m.chat, { image: { url: data.url }, caption: '✅ Result' }, { quoted: m });
 } else {
 m.reply(`❌ Error: ${response.status} ${response.statusText}`);
 }
 break;
}

case 'ninja-logo': {
 if (!text) return m.reply(`✳️ Masukkan teks\n\n📌 Contoh: *${prefix}logo* Microsoft`);
 m.reply(mess.wait);

 // URL API dengan parameter teks
 let apiUrl = `https://api.api-ninjas.com/v1/logo?name=${encodeURIComponent(text)}`;

 // Opsi untuk fetch request
 let options = {
 method: 'GET',
 headers: {
 'X-Api-Key': 'YhWZ+jP8JrrmMMKA+mYRhQ==pignwS5SmZW8GtLx'
 }
 };

 try {
 // Melakukan fetch request
 let response = await fetch(apiUrl, options);
 if (!response.ok) {
 throw new Error(`Error: ${response.status} ${response.statusText}`);
 }

 let data = await response.json();
 if (!Array.isArray(data) || data.length === 0) {
 throw new Error('Data tidak ditemukan.');
 }

 // Mengambil URL gambar dari respons
 let imgUrl = data[0].image;
 if (!imgUrl) {
 throw new Error('URL gambar tidak ditemukan dalam data API.');
 }

 // Mengirim pesan dengan gambar
 await kayyoffc.sendMessage(m.chat, { image: { url: imgUrl }, caption: '✅ Result' }, { quoted: m });

 } catch (error) {
 m.reply(`❌ Terjadi kesalahan: ${error.message}`);
 }

 break;
}

case 'sinonim': {
 if (!text) return m.reply(`✳️ Masukkan teks\n\n📌 Contoh: *${prefix}sinonim* elegant`);
 m.reply(mess.wait);

 // URL API dengan parameter teks
 let apiUrl = `https://api.api-ninjas.com/v1/thesaurus?word=${encodeURIComponent(text)}`;

 // Opsi untuk fetch request
 let options = {
 method: 'GET',
 headers: {
 'X-Api-Key': 'YhWZ+jP8JrrmMMKA+mYRhQ==pignwS5SmZW8GtLx'
 }
 };

 try {
 // Melakukan fetch request
 let response = await fetch(apiUrl, options);
 if (!response.ok) {
 throw new Error(`Error: ${response.status} ${response.statusText}`);
 }

 let data = await response.json();
 if (!data || !data.synonyms.length) {
 throw new Error('Sinonim tidak ditemukan.');
 }

 // Mengirim pesan dengan sinonim
 let synonyms = data.synonyms.join(', ');
 await kayyoffc.sendMessage(m.chat, { text: `Sinonim untuk *${text}*:\n${synonyms}` }, { quoted: m });

 } catch (error) {
 m.reply(`❌ Terjadi kesalahan: ${error.message}`);
 }

 break;
}

case 'antonim': {
 if (!text) return m.reply(`✳️ Masukkan teks\n\n📌 Contoh: *${prefix}antonim* elegant`);
 m.reply(mess.wait);

 // URL API dengan parameter teks
 let apiUrl = `https://api.api-ninjas.com/v1/thesaurus?word=${encodeURIComponent(text)}`;

 // Opsi untuk fetch request
 let options = {
 method: 'GET',
 headers: {
 'X-Api-Key': 'YhWZ+jP8JrrmMMKA+mYRhQ==pignwS5SmZW8GtLx'
 }
 };

 try {
 // Melakukan fetch request
 let response = await fetch(apiUrl, options);
 if (!response.ok) {
 throw new Error(`Error: ${response.status} ${response.statusText}`);
 }

 let data = await response.json();
 if (!data || !data.antonyms.length) {
 throw new Error('Antonim tidak ditemukan.');
 }

 // Mengirim pesan dengan antonim
 let antonyms = data.antonyms.join(', ');
 await kayyoffc.sendMessage(m.chat, { text: `Antonim untuk *${text}*:\n${antonyms}` }, { quoted: m });

 } catch (error) {
 m.reply(`❌ Terjadi kesalahan: ${error.message}`);
 }

 break;
}

;


case 'validate-phone': {
 if (!q) return m.reply('📞 Kirimkan nomor telepon untuk divalidasi. Contoh penggunaan: `.validate-phone +12065550100`');
 m.reply(mess.wait);

 // URL API untuk validasi nomor telepon
 let apiUrl = `https://api.api-ninjas.com/v1/validatephone?number=${encodeURIComponent(q)}`;

 // Opsi untuk fetch request
 let options = {
 method: 'GET',
 headers: {
 'X-Api-Key': 'YhWZ+jP8JrrmMMKA+mYRhQ==pignwS5SmZW8GtLx'
 }
 };

 try {
 // Melakukan fetch request
 let response = await fetch(apiUrl, options);
 if (!response.ok) {
 throw new Error(`Error: ${response.status} ${response.statusText}`);
 }

 let data = await response.json();
 if (!data.is_valid) {
 await kayyoffc.sendMessage(m.chat, { text: `📞 Nomor telepon *${q}* tidak valid.` }, { quoted: m });
 } else {
 let message = `
📞 Nomor Telepon: ${m.chat}
✅ Valid: ${data.is_valid}
🌍 Negara: ${data.country}
📍 Lokasi: ${data.location}
🕰️ Zona Waktu: ${data.timezones.join(', ')}
📋 Format Nasional: ${data.format_national}
🌐 Format Internasional: ${data.format_international}
📲 Format E.164: ${data.format_e164}
 `.trim();

 await kayyoffc.sendMessage(m.chat, { text: message }, { quoted: m });
 }
 } catch (error) {
 m.reply(`❌ Terjadi kesalahan: ${error.message}`);
 }

 break;
}

case 'dns-lookup': {
 if (!q) return m.reply('🌐 Kirimkan domain yang ingin dicari. Contoh penggunaan: `.dns-lookup example.com`');
 m.reply(mess.wait);

 // Daftar jenis record yang memerlukan langganan premium
 const premiumRecords = ['A', 'AAAA', 'CNAME', 'MX', 'TXT'];
 const recordType = 'NS'; // Ganti dengan jenis record yang ingin dicari
 
 if (premiumRecords.includes(recordType)) {
 await kayyoffc.sendMessage(m.chat, { text: '🔒 Fitur ini memerlukan langganan premium dan tidak dapat digunakan.' }, { quoted: m });
 break;
 }

 // URL API untuk pencarian DNS
 let apiUrl = `https://api.api-ninjas.com/v1/dnslookup?domain=${encodeURIComponent(q)}`;

 // Opsi untuk fetch request
 let options = {
 method: 'GET',
 headers: {
 'X-Api-Key': 'YhWZ+jP8JrrmMMKA+mYRhQ==pignwS5SmZW8GtLx'
 }
 };

 try {
 // Melakukan fetch request
 let response = await fetch(apiUrl, options);
 if (!response.ok) {
 throw new Error(`Error: ${response.status} ${response.statusText}`);
 }

 let data = await response.json();
 let message = `🔍 Hasil Pencarian DNS untuk *${q}*:\n\n${data.map(record => 
 `Jenis Record: ${record.record_type}\nNilai: ${record.value || 'N/A'}\n`
 ).join('\n')}`;

 await kayyoffc.sendMessage(m.chat, { text: message }, { quoted: m });
 } catch (error) {
 m.reply(`❌ Terjadi kesalahan: ${error.message}`);
 }

 break;
}

case 'ip-lookup': {
 if (!q) return m.reply('🌐 Kirimkan alamat IP yang ingin dicari. Contoh penggunaan: `.ip-lookup 73.9.149.180`');
 m.reply(mess.wait);

 // URL API untuk pencarian IP
 let apiUrl = `https://api.api-ninjas.com/v1/iplookup?address=${encodeURIComponent(q)}`;

 // Opsi untuk fetch request
 let options = {
 method: 'GET',
 headers: {
 'X-Api-Key': 'YhWZ+jP8JrrmMMKA+mYRhQ==pignwS5SmZW8GtLx'
 }
 };

 try {
 // Melakukan fetch request
 let response = await fetch(apiUrl, options);
 if (!response.ok) {
 throw new Error(`Error: ${response.status} ${response.statusText}`);
 }

 let data = await response.json();
 let message = `🔍 Hasil Pencarian IP untuk *${q}*:\n\n` +
 `Valid: ${data.is_valid ? 'Ya' : 'Tidak'}\n` +
 `Negara: ${data.country}\n` +
 `Kode Negara: ${data.country_code}\n` +
 `Wilayah: ${data.region}\n` +
 `Kode Wilayah: ${data.region_code}\n` +
 `Kota: ${data.city || 'N/A'}\n` +
 `ZIP: ${data.zip || 'N/A'}\n` +
 `Latitude: ${data.lat || 'N/A'}\n` +
 `Longitude: ${data.lon || 'N/A'}\n` +
 `Zona Waktu: ${data.timezone || 'N/A'}\n` +
 `ISP: ${data.isp || 'N/A'}`;

 await kayyoffc.sendMessage(m.chat, { text: message }, { quoted: m });
 } catch (error) {
 m.reply(`❌ Terjadi kesalahan: ${error.message}`);
 }

 break;
}

case 'restlogo': {
 if (!text) return m.reply(`✳️ Masukkan teks\n\n📌 Contoh: *${prefix}logo* Microsoft`);
 m.reply(mess.wait);

 // URL API dengan parameter teks
 let apiUrl = `https://api.api-ninjas.com/v1/logo?name=${encodeURIComponent(text)}`;

 // Opsi untuk fetch request
 let options = {
 method: 'GET',
 headers: {
 'X-Api-Key': 'YhWZ+jP8JrrmMMKA+mYRhQ==pignwS5SmZW8GtLx'
 }
 };

 try {
 // Melakukan fetch request
 let response = await fetch(apiUrl, options);
 if (!response.ok) {
 throw new Error(`Error: ${response.status} ${response.statusText}`);
 }

 let data = await response.json();
 if (!Array.isArray(data) || data.length === 0) {
 throw new Error('Data tidak ditemukan.');
 }

 // Mengambil URL gambar dari respons
 let imgUrl = data[0].image;
 if (!imgUrl) {
 throw new Error('URL gambar tidak ditemukan dalam data API.');
 }

 // Mengirim pesan dengan gambar
 await kayyoffc.sendMessage(m.chat, { image: { url: imgUrl }, caption: '✅ Result' }, { quoted: m });

 } catch (error) {
 m.reply(`❌ Terjadi kesalahan: ${error.message}`);
 }

 break
}



case 'glitchtext':
case 'writetext':
case 'advancedglow':
case 'typographytext':
case 'pixelglitch':
case 'neonglitch':
case 'flagtext':
case 'flag3dtext':
case 'deletingtext':
case 'blackpinkstyle':
case 'glowingtext':
case 'underwatertext':
case 'logomaker':
case 'cartoonstyle':
case 'papercutstyle':
case 'watercolortext':
case 'effectclouds':
case 'blackpinklogo':
case 'gradienttext':
case 'summerbeach':
case 'luxurygold':
case 'multicoloredneon':
case 'sandsummer':
case 'galaxywallpaper':
case '1917style':
case 'makingneon':
case 'royaltext':
case 'freecreate':
case 'galaxystyle':
case 'lighteffects':{

if (!text) return reply(`Example : ${prefix+command} +`) 
let link
if (/glitchtext/.test(command)) link = 'https://en.ephoto360.com/create-digital-glitch-text-effects-online-767.html'
if (/writetext/.test(command)) link = 'https://en.ephoto360.com/write-text-on-wet-glass-online-589.html'
if (/advancedglow/.test(command)) link = 'https://en.ephoto360.com/advanced-glow-effects-74.html'
if (/typographytext/.test(command)) link = 'https://en.ephoto360.com/create-typography-text-effect-on-pavement-online-774.html'
if (/pixelglitch/.test(command)) link = 'https://en.ephoto360.com/create-pixel-glitch-text-effect-online-769.html'
if (/neonglitch/.test(command)) link = 'https://en.ephoto360.com/create-impressive-neon-glitch-text-effects-online-768.html'
if (/flagtext/.test(command)) link = 'https://en.ephoto360.com/nigeria-3d-flag-text-effect-online-free-753.html'
if (/flag3dtext/.test(command)) link = 'https://en.ephoto360.com/free-online-american-flag-3d-text-effect-generator-725.html'
if (/deletingtext/.test(command)) link = 'https://en.ephoto360.com/create-eraser-deleting-text-effect-online-717.html'
if (/blackpinkstyle/.test(command)) link = 'https://en.ephoto360.com/online-blackpink-style-logo-maker-effect-711.html'
if (/glowingtext/.test(command)) link = 'https://en.ephoto360.com/create-glowing-text-effects-online-706.html'
if (/underwatertext/.test(command)) link = 'https://en.ephoto360.com/3d-underwater-text-effect-online-682.html'
if (/logomaker/.test(command)) link = 'https://en.ephoto360.com/free-bear-logo-maker-online-673.html'
if (/cartoonstyle/.test(command)) link = 'https://en.ephoto360.com/create-a-cartoon-style-graffiti-text-effect-online-668.html'
if (/papercutstyle/.test(command)) link = 'https://en.ephoto360.com/multicolor-3d-paper-cut-style-text-effect-658.html'
if (/watercolortext/.test(command)) link = 'https://en.ephoto360.com/create-a-watercolor-text-effect-online-655.html'
if (/effectclouds/.test(command)) link = 'https://en.ephoto360.com/write-text-effect-clouds-in-the-sky-online-619.html'
if (/blackpinklogo/.test(command)) link = 'https://en.ephoto360.com/create-blackpink-logo-online-free-607.html'
if (/gradienttext/.test(command)) link = 'https://en.ephoto360.com/create-3d-gradient-text-effect-online-600.html'
if (/summerbeach/.test(command)) link = 'https://en.ephoto360.com/write-in-sand-summer-beach-online-free-595.html'
if (/luxurygold/.test(command)) link = 'https://en.ephoto360.com/create-a-luxury-gold-text-effect-online-594.html'
if (/multicoloredneon/.test(command)) link = 'https://en.ephoto360.com/create-multicolored-neon-light-signatures-591.html'
if (/sandsummer/.test(command)) link = 'https://en.ephoto360.com/write-in-sand-summer-beach-online-576.html'
if (/galaxywallpaper/.test(command)) link = 'https://en.ephoto360.com/create-galaxy-wallpaper-mobile-online-528.html'
if (/1917style/.test(command)) link = 'https://en.ephoto360.com/1917-style-text-effect-523.html'
if (/makingneon/.test(command)) link = 'https://en.ephoto360.com/making-neon-light-text-effect-with-galaxy-style-521.html'
if (/royaltext/.test(command)) link = 'https://en.ephoto360.com/royal-text-effect-online-free-471.html'
if (/freecreate/.test(command)) link = 'https://en.ephoto360.com/free-create-a-3d-hologram-text-effect-441.html'
if (/galaxystyle/.test(command)) link = 'https://en.ephoto360.com/create-galaxy-style-free-name-logo-438.html'
if (/lighteffects/.test(command)) link = 'https://en.ephoto360.com/create-light-effects-green-neon-online-429.html'
let haldwhd = await ephoto(link, text)
kayyoffc.sendMessage(m.chat, { image: { url: haldwhd }, caption: `Done` }, { quoted: m })
}
break

case 'shadow':
case 'write':
case 'romantic':
case 'burnpaper':
case 'smoke':
case 'narutobanner':
case 'love':
case 'undergrass':
case 'doublelove':
case 'coffecup':
case 'underwaterocean':
case 'smokyneon':
case 'starstext':
case 'rainboweffect':
case 'balloontext':
case 'metalliceffect':
case 'embroiderytext':
case 'flamingtext':
case 'stonetext':
case 'writeart':
case 'summertext':
case 'wolfmetaltext':
case 'nature3dtext':
case 'rosestext':
case 'naturetypography':
case 'quotesunder':
case 'shinetext':
{



if (!text) return reply(`Example : ${prefix + command} ${global.botname}`);
 reply("sabar..")
let link;
if (/stonetext/.test(command))
link =
 'https://photooxy.com/online-3d-white-stone-text-effect-utility-411.html';
if (/writeart/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/write-art-quote-on-wood-heart-370.html';
if (/summertext/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/3d-summer-text-effect-367.html';
if (/wolfmetaltext/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/create-a-wolf-metal-text-effect-365.html';
if (/nature3dtext/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/make-nature-3d-text-effects-364.html';
if (/rosestext/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/yellow-roses-text-360.html';
if (/naturetypography/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/create-vector-nature-typography-355.html';
if (/quotesunder/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/quotes-under-fall-leaves-347.html';
if (/shinetext/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/rainbow-shine-text-223.html';
if (/shadow/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/shadow-text-effect-in-the-sky-394.html';
if (/write/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/write-text-on-the-cup-392.html';
if (/romantic/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/romantic-messages-for-your-loved-one-391.html';
if (/burnpaper/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/write-text-on-burn-paper-388.html';
if (/smoke/.test(command))
link =
 'https://photooxy.com/other-design/create-an-easy-smoke-type-effect-390.html';
if (/narutobanner/.test(command))
link =
 'https://photooxy.com/manga-and-anime/make-naruto-banner-online-free-378.html';
if (/love/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/create-a-picture-of-love-message-377.html';
if (/undergrass/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/make-quotes-under-grass-376.html';
if (/doublelove/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/love-text-effect-372.html';
if (/coffecup/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/put-any-text-in-to-coffee-cup-371.html';
if (/underwaterocean/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/creating-an-underwater-ocean-363.html';
if (/smokyneon/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/make-smoky-neon-glow-effect-343.html';
if (/starstext/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/write-stars-text-on-the-night-sky-200.html';
if (/rainboweffect/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/glow-rainbow-effect-generator-201.html';
if (/balloontext/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/royal-look-text-balloon-effect-173.html';
if (/metalliceffect/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/illuminated-metallic-effect-177.html';
if (/embroiderytext/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/create-embroidery-text-online-191.html';
if (/flamingtext/.test(command))
link =
 'https://photooxy.com/logo-and-text-effects/realistic-flaming-text-effect-online-197.html';
let dehe = await photoOxy(link, text);
kayyoffc.sendMessage(
m.chat,
{ image: { url: dehe }, caption: `Done`},
{ quoted: m }
);
}
break;

case "gempanews": {
const link = 'https://data.bmkg.go.id/DataMKG/TEWS/'
try {
let res = await fetch(link+'autogempa.json')
let anu = await res.json()
anu = anu.Infogempa.gempa
let txt = `*GEMPA NEWS*\n\n${anu.Wilayah}\n\n`
txt += `Potensi : ${anu.Potensi}\n`
txt += `Tanggal : ${anu.Tanggal}\n`
txt += `Waktu : ${anu.Jam}\n\n`
txt += `Magnitude : ${anu.Magnitude}\n`
txt += `Kedalaman : ${anu.Kedalaman}\n`
txt += `Koordinat : ${anu.Coordinates}${anu.Dirasakan.length > 3 ? `\nDirasakan : ${anu.Dirasakan}` : ''}`
await kayyoffc.sendMessage(m.chat, { image: { url: link+anu.Shakemap }, caption: txt }, { quoted: m })
} catch (e) {
m.reply(e)
}
}
break


case "gemini-img":{
if (!quoted) return reply(`Balas Image Dengan Caption ${prefix + command}`)
if (!/image/.test(mime)) return reply("hanya support gambar")
let media = await kayyoffc.downloadAndSaveMediaMessage(qmsg)
let urlgambar = await TelegraPH(media)
let { data } = await axios.get("https://gmni.vercel.app/api/img?imageUrl="+ urlgambar +"&prompt=" + text)
reply(data.text)
}
break

case 'bass': case 'blown': case 'deep': case 'earrape': case 'fast': case 'fat': case 'nightcore': case 'reverse': case 'robot': case 'slow': case 'smooth': case 'tupai':{
if (!qmsg) return m.reply("reply audio nya")
try {
let set
if (/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20'
if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log'
if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3'
if (/earrape/.test(command)) set = '-af volume=12'
if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"'
if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"'
if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25'
if (/reverse/.test(command)) set = '-filter_complex "areverse"'
if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"'
if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"'
if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"'
if (/tupai/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"'
if (/audio/.test(mime)) {
let media = await kayyoffc.downloadAndSaveMediaMessage(qmsg)
let ran = getRandom('.mp3')
exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
fs.unlinkSync(media)
if (err) return m.reply(err)
let buff = fs.readFileSync(ran)
kayyoffc.sendMessage(m.chat, { audio: buff, mimetype: 'audio/mpeg' }, { quoted : m })
fs.unlinkSync(ran)
})
} else m.reply(`Reply to the audio you want to change with a caption *${prefix + command}*`)
} catch (e) {
console.log(e)
m.reply('error')
}}
break

case 'ytplay': {
if (!text) return reply(`Example : ${prefix + command} Lagu sad`)
let wait = await kayyoffc.sendMessage(m.chat, {text: `_Searching.. [ ${text} ] 🔍_`}, {quoted: fcall, ephemeralExpiration: 86400})
let search = await yts(`${text}`)

let data = await search.all.filter((v) => v.type == 'video')
try {
var res12 = data[0]
} catch {
var res12 = data[1]
}
let ply = search.videos[0].url
const ytdl = require('ytdl-core')
let mp3file = `./.npm/${search.all[0].views}.mp3`
 let nana = ytdl(ply, { filter: 'audioonly' })
 .pipe(fs.createWriteStream(mp3file))
 .on('finish', async () => {
await kayyoffc.sendMessage(m.chat, {text: `_Mengirim.. [ ${text} ] 🔍_`, edit: wait.key }, {quoted: m, ephemeralExpiration: 86400});
kayyoffc.sendMessage(m.chat, {audio: fs.readFileSync(mp3file), mimetype: 'audio/mpeg', contextInfo: {externalAdReply: {title: `${search.all[0].title}`, body: `Views : ${search.all[0].views}`, thumbnailUrl: res12?.thumbnail, mediaType: 2, mediaUrl: `${search.videos[0].url}`, sourceUrl: `${search.videos[0].url}`, renderLargerThumbnail: true }}},)
 })
const alicevidoh = require('./lib/ytdl2')
const vid=await alicevidoh.mp4(`${search.videos[0].url}`)
const ytc=`
*Tittle:* ${vid.title}
*Date:* ${vid.date}
*Duration:* ${vid.duration}
*Quality:* ${vid.quality}`
await kayyoffc.sendMessage(m.chat,{
 video: {url:vid.videoUrl},
 caption: ytc
},)
}
kayyoffc.sendMessage(m.chat, {react: {text: '🎧', key: m.key}})
break





case 'toimage': case 'toimg': {

 if (!quoted) reply ('m?.reply Image')
if (!/webp/.test(mime)) reply (`Balas sticker dengan caption *${prefix + command}*`)
let media = await kayyoffc.downloadAndSaveMediaMessage(quoted)
let ran = 'jjsjsnsu.png'
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) reply (err)
let buffer = fs.readFileSync(ran)
kayyoffc.sendMessage(m.chat, { image: buffer }, {quoted:m})
fs.unlinkSync(ran)
})
}
break

case "ytplay2": case "play2": {
if (!text) return m.reply("Apa yg kamu cari");
	try { 	

 let search = await yts(text);
let url = search.all[0].type === "channel" ? search.all[1].url : search.all[0].url;

let videoId = url.split("v=")[1];
let thumbUrl = `https://i.ytimg.com/vi/${videoId}/default.jpg`;
let thumbBuffer = await getBuffer(thumbUrl);

let proceenojb8jbuss = await (await fetch(`https://widipe.com/download/ytdl?url=${url}`)).json()
 let audioresult00000 = proceenojb8jbuss.result;
 
 if (!thumbBuffer) {
 console.log("Thumbnail Buffer is undefined");
 return;
}

if (!audioresult00000 || !audioresult00000.mp3) {
 console.log("Audio result is undefined or doesn't contain 'mp3'");
 return;
}

kayyoffc.sendMessage(m.chat, {
 audio: {url: audioresult00000.mp3},
 mimetype: 'audio/mpeg',
 ptt: true,
 contextInfo: {
 externalAdReply: {
 title: search.all[0].title,
 body: hariini,
 thumbnail: thumbBuffer,
 sourceUrl: url,
 mediaType: 2,
 mediaUrl: url,
 }
 }
});
 
	} catch (e) {
		m.reply(e);
	}
	}
 break

case 'addjson': {
 if (!isCreator) return m.reply(`Maaf, hanya creator yang bisa menggunakan perintah ini.`);
 
 let input = m.text.split(' ').slice(1).join(' '); // Ambil input setelah perintah .addfile
 if (!input.includes('|')) return reply('Format salah! Gunakan format: .addfile namaFile.js | Kode yang ingin disimpan');
 
 // Split hanya pada pemisah pertama '|' agar semua setelahnya dianggap sebagai kode
 let separatorIndex = input.indexOf('|');
 let filename = input.slice(0, separatorIndex).trim();
 let code = input.slice(separatorIndex + 1).trim(); // Ambil seluruh teks setelah '|'
 
 if (!filename || !code) return reply('Nama file dan kode tidak boleh kosong! Pastikan format sesuai dengan contoh: .addfile namaFile.json | Kode anda');
 
 // Validasi agar hanya menerima ekstensi file .js
 if (!filename.endsWith('.json')) return reply('Hanya file dengan ekstensi .json yang diperbolehkan.');
 
 // Tentukan path untuk menyimpan file
 let filepath = path.join(__dirname, 'lib', filename);

 // Simpan kode ke file
 fs.writeFile(filepath, code, (err) => {
 if (err) {
 console.error(err);
 return reply('Gagal menyimpan file. Silakan coba lagi.');
 }

 reply(`File "${filename}" berhasil disimpan di ./lib.`);
 });
};
break



case 'gamesusunkata':
 return loading()
 return m.reply(`Aktifkan botsetting terlebih dahulu dengan cara masukkan perintah *.botsetting* lalu vote on`) 
if (from in susunkata) return m.reply('Masih ada game yang belum diselesaikan');
var { soal, jawaban } = pickRandom(JSON.parse(fs.readFileSync('./lib/susunkata.json')));
console.log('Jawaban : '+jawaban)
await m.reply(`*GAME SUSUN KATA*\n\nSoal: ${soal}\nPetunjuk: ${monospace(jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-'))}\nWaktu: ${gamewaktu} detik`)
susunkata[from] = {
soal: soal,
jawaban: jawaban.toLowerCase(),
//hadiah: randomNomor(10, 20),
waktu: setTimeout(function () {
if (susunkata[from]) m.reply(`Waktu habis!\n\nJawaban dari soal:\n${monospace(soal)}\n\nAdalah: ${monospace(jawaban)}`);
delete susunkata[from];
}, gamewaktu * 600)
}
break

case 'password-generator': {
 // Default parameter untuk panjang password
 let length = q && parseInt(q.split('|')[0].trim()) || 16;
 let excludeNumbers = q && q.split('|')[1] && q.split('|')[1].trim().toLowerCase() === 'true' || false;
 let excludeSpecialChars = q && q.split('|')[2] && q.split('|')[2].trim().toLowerCase() === 'true' || false;

 m.reply(mess.wait);

 // URL API untuk Password Generator
 let apiUrl = `https://api.api-ninjas.com/v1/passwordgenerator?length=${length}&exclude_numbers=${excludeNumbers}&exclude_special_chars=${excludeSpecialChars}`;

 let options = {
 method: 'GET',
 headers: {
 'X-Api-Key': 'YhWZ+jP8JrrmMMKA+mYRhQ==pignwS5SmZW8GtLx' // Gantilah dengan API key Anda
 }
 };

 try {
 // Meminta password acak dari API
 let response = await fetch(apiUrl, options);
 if (!response.ok) {
 throw new Error(`Error: ${response.status} ${response.statusText}`);
 }

 let data = await response.json();

 // Mengirimkan password yang dihasilkan
 m.reply(`🔐 Password Acak Anda: \n\n*${data.random_password}*`);
 } catch (error) {
 m.reply(`❌ Terjadi kesalahan: ${error.message}`);
 }
}
 break;

case 'whois': {
 // Memeriksa apakah domain diberikan oleh pengguna
 if (!q) {
 m.reply('❌ Silakan masukkan domain yang valid (misalnya example.com).');
 break;
 }

 m.reply(mess.wait);

 // URL API untuk WHOIS dengan parameter domain
 let apiUrl = `https://api.api-ninjas.com/v1/whois?domain=${encodeURIComponent(q)}`;

 // Header yang diperlukan untuk API
 let options = {
 method: 'GET',
 headers: {
 'X-Api-Key': 'YhWZ+jP8JrrmMMKA+mYRhQ==pignwS5SmZW8GtLx' // Ganti dengan API key Anda
 }
 };

 try {
 // Mengirimkan permintaan ke API
 let response = await fetch(apiUrl, options);
 
 // Jika ada masalah dengan response
 if (!response.ok) {
 throw new Error(`Error: ${response.status} ${response.statusText}`);
 }

 let data = await response.json();

 // Membuat format informasi WHOIS
 let whoisInfo = `🌐 *Informasi Domain: ${data.domain_name}*\n\n` +
 `📅 *Tanggal Pembuatan*: ${new Date(data.creation_date * 1000).toLocaleString()}\n` +
 `📅 *Tanggal Expirasi*: ${new Date(data.expiration_date * 1000).toLocaleString()}\n` +
 `🏢 *Registrar*: ${data.registrar}\n` +
 `🖥️ *WHOIS Server*: ${data.whois_server}\n` +
 `🔒 *DNSSEC*: ${data.dnssec}\n` +
 `🌐 *Name Servers*: ${data.name_servers.join(', ')}\n`;

 // Mengirimkan informasi WHOIS kepada pengguna
 m.reply(whoisInfo);
 } catch (error) {
 // Mengirimkan pesan error jika terjadi kesalahan
 m.reply(`❌ Terjadi kesalahan: ${error.message}`);
 }
}
 break;

case 'qr-gen': {
 if (!q) {
 m.reply('❌ Silakan masukkan query untuk dibuat QR Code.');
 break;
 }

 m.reply(mess.wait);

 let [data, colorInput] = q.split('|');

 data = data.trim();
 colorInput = colorInput ? colorInput.trim() : "";

 let fgColor = '000000'; // Default warna hitam
 let bgColor = 'ffffff'; // Default warna putih

 // Proses warna berdasarkan input pengguna
 if (colorInput) {
 let colorMap = {
 "blue": "0000ff",
 "red": "ff0000",
 "green": "00ff00",
 "yellow": "ffff00",
 "black": "000000",
 "white": "ffffff"
 };

 let colors = colorInput.split('/');
 if (colors.length > 0) fgColor = colorMap[colors[0].toLowerCase()] || colors[0];
 if (colors.length > 1) bgColor = colorMap[colors[1].toLowerCase()] || colors[1];
 }

 let apiUrl = `https://api.api-ninjas.com/v1/qrcode?data=${encodeURIComponent(data)}&format=png&fg_color=${fgColor}&bg_color=${bgColor}`;

 let options = {
 method: 'GET',
 headers: {
 'X-Api-Key': 'YhWZ+jP8JrrmMMKA+mYRhQ==pignwS5SmZW8GtLx',
 'Accept': 'image/png'
 },
 responseType: 'arraybuffer' // Mendapatkan gambar sebagai buffer
 };

 try {
 let response = await axios(apiUrl, options);

 if (response.status !== 200) {
 throw new Error(`Error: ${response.status}`);
 }

 let buffer = response.data;

 // Mengirimkan gambar QR code ke pengguna
 kayyoffc.sendMessage(m.chat, { image: buffer, caption: `QR Code generated for: ${data}` }, { quoted: m });
 } catch (error) {
 m.reply(`❌ Terjadi kesalahan: ${error.message}`);
 }
}
 break;

case 'quoted-random': {
 m.reply(mess.wait);

 // Daftar kategori yang tersedia
 let categories = [
 'age', 'alone', 'amazing', 'anger', 'architecture', 'art', 'attitude',
 'beauty', 'best', 'birthday', 'business', 'car', 'change', 'communication',
 'computers', 'cool', 'courage', 'dad', 'dating', 'death', 'design',
 'dreams', 'education', 'environmental', 'equality', 'experience', 'failure',
 'faith', 'family', 'famous', 'fear', 'fitness', 'food', 'forgiveness',
 'freedom', 'friendship', 'funny', 'future', 'god', 'good', 'government',
 'graduation', 'great', 'happiness', 'health', 'history', 'home', 'hope',
 'humor', 'imagination', 'inspirational', 'intelligence', 'jealousy',
 'knowledge', 'leadership', 'learning', 'legal', 'life', 'love', 'marriage',
 'medical', 'men', 'mom', 'money', 'morning', 'movies', 'success'
 ];

 // Pilih kategori secara acak
 let randomCategory = categories[Math.floor(Math.random() * categories.length)];

 let apiUrl = `https://api.api-ninjas.com/v1/quotes?category=${randomCategory}`;

 let options = {
 method: 'GET',
 headers: {
 'X-Api-Key': 'YhWZ+jP8JrrmMMKA+mYRhQ==pignwS5SmZW8GtLx'
 }
 };

 try {
 let response = await axios(apiUrl, options);

 if (response.status !== 200) {
 throw new Error(`Error: ${response.status}`);
 }

 let quoteData = response.data[0];

 let quoteText = `_"${quoteData.quote}"_\n\n*— ${quoteData.author}*\n\n_Category: ${quoteData.category}_`;

 m.reply(quoteText);
 } catch (error) {
 m.reply(`❌ Terjadi kesalahan: ${error.message}`);
 }
}
 break;

case 'emoji': {
 m.reply(mess.wait);

 // Memisahkan query pengguna berdasarkan separator "|"
 let query = text.split('|');

 // Parameter pencarian emoji
 let name = query[0] ? query[0].trim() : '';
 let code = query[1] ? query[1].trim() : '';
 let group = query[2] ? query[2].trim() : '';
 let subgroup = query[3] ? query[3].trim() : '';
 
 // Membuat URL API berdasarkan parameter yang tersedia
 let apiUrl = `https://api.api-ninjas.com/v1/emoji?`;
 if (name) apiUrl += `name=${name}&`;
 if (code) apiUrl += `code=${code}&`;
 if (group) apiUrl += `group=${group}&`;
 if (subgroup) apiUrl += `subgroup=${subgroup}&`;

 let options = {
 method: 'GET',
 headers: {
 'X-Api-Key': 'YhWZ+jP8JrrmMMKA+mYRhQ==pignwS5SmZW8GtLx'
 }
 };

 try {
 let response = await axios(apiUrl, options);

 if (response.status !== 200) {
 throw new Error(`Error: ${response.status}`);
 }

 let emojiData = response.data;

 if (emojiData.length === 0) {
 m.reply('❌ Tidak ditemukan emoji yang sesuai dengan pencarian Anda.');
 } else {
 // Memproses hasil pencarian
 let result = '';
 emojiData.forEach(emoji => {
 result += `*Nama*: ${emoji.name}\n*Karakter*: ${emoji.character}\n*Kode*: ${emoji.code}\n*Grup*: ${emoji.group}\n*Subgrup*: ${emoji.subgroup}\n*Gambar*: ${emoji.image}\n\n`;
 });

 m.reply(result);
 }
 } catch (error) {
 m.reply(`❌ Terjadi kesalahan: ${error.message}`);
 }
}
 break;

case 'planet': {
 m.reply(mess.wait);

 // Memisahkan query pengguna berdasarkan separator "|"
 let query = text.split('|');
 
 // Parameter pencarian planet
 let name = query[0] ? query[0].trim() : '';
 let min_mass = query[1] ? query[1].trim() : '';
 let max_mass = query[2] ? query[2].trim() : '';
 let min_radius = query[3] ? query[3].trim() : '';
 let max_radius = query[4] ? query[4].trim() : '';
 let min_period = query[5] ? query[5].trim() : '';
 let max_period = query[6] ? query[6].trim() : '';
 let min_temperature = query[7] ? query[7].trim() : '';
 let max_temperature = query[8] ? query[8].trim() : '';
 let min_distance_light_year = query[9] ? query[9].trim() : '';
 let max_distance_light_year = query[10] ? query[10].trim() : '';
 let min_semi_major_axis = query[11] ? query[11].trim() : '';
 let max_semi_major_axis = query[12] ? query[12].trim() : '';

 // Membuat URL API berdasarkan parameter yang tersedia
 let apiUrl = `https://api.api-ninjas.com/v1/planets?`;
 if (name) apiUrl += `name=${name}&`;
 if (min_mass) apiUrl += `min_mass=${min_mass}&`;
 if (max_mass) apiUrl += `max_mass=${max_mass}&`;
 if (min_radius) apiUrl += `min_radius=${min_radius}&`;
 if (max_radius) apiUrl += `max_radius=${max_radius}&`;
 if (min_period) apiUrl += `min_period=${min_period}&`;
 if (max_period) apiUrl += `max_period=${max_period}&`;
 if (min_temperature) apiUrl += `min_temperature=${min_temperature}&`;
 if (max_temperature) apiUrl += `max_temperature=${max_temperature}&`;
 if (min_distance_light_year) apiUrl += `min_distance_light_year=${min_distance_light_year}&`;
 if (max_distance_light_year) apiUrl += `max_distance_light_year=${max_distance_light_year}&`;
 if (min_semi_major_axis) apiUrl += `min_semi_major_axis=${min_semi_major_axis}&`;
 if (max_semi_major_axis) apiUrl += `max_semi_major_axis=${max_semi_major_axis}&`;

 // Jika tidak ada parameter, cari planet secara acak
 if (apiUrl === `https://api.api-ninjas.com/v1/planets?`) {
 let randomOffset = Math.floor(Math.random() * 1000);
 apiUrl += `offset=${randomOffset}&`;
 }

 let options = {
 method: 'GET',
 headers: {
 'X-Api-Key': 'YhWZ+jP8JrrmMMKA+mYRhQ==pignwS5SmZW8GtLx'
 }
 };

 try {
 let response = await axios(apiUrl, options);

 if (response.status !== 200) {
 throw new Error(`Error: ${response.status}`);
 }

 let planetData = response.data;

 if (planetData.length === 0) {
 m.reply('❌ Tidak ditemukan planet yang sesuai dengan pencarian Anda.');
 } else {
 // Memproses hasil pencarian
 let result = '';
 planetData.forEach(planet => {
 result += `*Nama*: ${planet.name}\n*Massa*: ${planet.mass} Jupiters\n*Radius*: ${planet.radius} Jupiters\n*Periode*: ${planet.period} hari\n*Sumbu Semi-Major*: ${planet.semi_major_axis} AU\n*Suhu*: ${planet.temperature} K\n*Jarak dari Bumi*: ${planet.distance_light_year} tahun cahaya\n\n`;
 });

 m.reply(result);
 }
 } catch (error) {
 m.reply(`❌ Terjadi kesalahan: ${error.message}`);
 }
}
 break;

case 'random-user': {
 m.reply(mess.wait);

 let apiUrl = 'https://api.api-ninjas.com/v1/randomuser';
 let options = {
 method: 'GET',
 headers: {
 'X-Api-Key': 'YhWZ+jP8JrrmMMKA+mYRhQ==pignwS5SmZW8GtLx'
 }
 };

 try {
 let response = await axios(apiUrl, options);

 if (response.status !== 200) {
 throw new Error(`Error: ${response.status}`);
 }

 let userData = response.data;

 let result = `*Nama*: ${userData.name}\n*Username*: ${userData.username}\n*Jenis Kelamin*: ${userData.sex === 'M' ? 'Pria' : 'Wanita'}\n*Email*: ${userData.email}\n*Alamat*: ${userData.address}\n*Tanggal Lahir*: ${userData.birthday}`;

 m.reply(result);
 } catch (error) {
 m.reply(`❌ Terjadi kesalahan: ${error.message}`);
 }
}
 break;

case 'petakbom':
 if (userdb.petakbom === true) return m.reply("masih ada session")
 if (m.sender in this.petakbom) {
 return reply(`Game mu masih belum terselesaikan, lanjutkan yukk\n\n${this.petakbom[m.sender].board.join("")}\n\nKirim ${prefix}delpetakbom untuk menghapus game petak bom`);
 }

 function shuffle(array) {
 return array.sort(() => Math.random() - 0.5);
 }

 this.petakbom[m.sender] = {
 petak: shuffle([0, 0, 0, 2, 0, 2, 0, 2, 0, 0]),
 board: ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"],
 bomb: 3,
 lolos: 7,
 pick: 0,
 nyawa: ["❤️", "❤️"]
 };
 userdb.petakbom = true
 await m.reply(`*PETAK BOM*\n\n${this.petakbom[m.sender].board.join("")}\n\nPilih lah nomor tersebut! dan jangan sampai terkena Bom!\nBomb : ${this.petakbom[m.sender].bomb}\nNyawa : ${this.petakbom[m.sender].nyawa.join("")}`);
 break;

case 'delpetakbom':
 if (userdb.petakbom === false) return m.reply(`Kamu sedang tidak bermain petakbom!`);
 delete this.petakbom[m.sender];
 userdb.petakbom = false
 m.reply(`Permainan petakbom telah diakhiri.`);
 break;


case 'wiktionary': {
 if (!text) {
 throw 'Contoh WikTionary rumah';
 }
// wm avs
 m.reply('Mencari artikel Wiktionary...');
// wm avs
 try {
 const url = `https://id.m.wiktionary.org/wiki/${q}`;
 const response = await axios.get(url);
 const $ = cheerio.load(response.data);
// wm avs
 const judul = $('#firstHeading').text().trim();
 const konten = $('#mw-content-text > div.mw-parser-output').find('p').map((i, el) => $(el).text().trim()).get().join('\n\n');
// wm avs
 if (!konten) {
 throw new Error('Tidak ada artikel.');
 }
// wm avs
 const artikel = `_${judul}_\n\n${konten}`;
 m.reply(artikel);
 } catch (error) {
 m.reply(`Maaf : ${error.message}`);
 }
 }
 break

case 'themovie': {
 if (!text) {
 throw 'Contoh: themovie horror';
 }
// wm avs
 m.reply('_sabar tuan sedang mencari film nya_');
// wm avs
 async function avzz(query) {
 const url = `https://www.themoviedb.org/search?query=${query}`;
 try {
 const response = await axios.get(url);
 const html = response.data;
 const $ = cheerio.load(html);
 const movies = [];
// wm avs
 $('.card').each((index, element) => {
 const title = $(element).find('.title a').text().trim();
 const link = `https://www.themoviedb.org${$(element).find('.title a').attr('href')}`;
 const synopsis = $(element).find('.overview').text().trim();
 movies.push({ title, link, synopsis });
 });
// wm avs
 return movies;
 } catch (error) {
 console.error('error di sini:', error);
 return [];
 }
 }
// wm avs
 try {
 const query = encodeURIComponent(text);
 const movies = await avzz(query);

 if (movies.length === 0) {
 throw new Error('Film tidak ditemukan.');
 }
// wm avs
 let result = '';
 movies.forEach((movie, index) => {
 result += `*${index + 1}. ${movie.title}*\nLink: ${movie.link}\nSinopsis: ${movie.synopsis}\n\n`;
 });
// wm avs
 m.reply(result);
 } catch (error) {
 m.reply(`terjadi kesalahan: ${error.message}`);
 }
}
break

case 'ebay': {
 if (!q) return m.reply(`Mau cari apa?`);
 const axios = require('axios');
 const cheerio = require('cheerio');
// wm avs
 async function azvxz(query) {
 try { // wm avs
 const url = `https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(query)}`;
 const { data } = await axios.get(url);
 const $ = cheerio.load(data);
 const results = [];
 $('.s-item').each((index, element) => {
 const title = $(element).find('.s-item__title').text().trim();
 const price = $(element).find('.s-item__price').text().trim();
 const link = $(element).find('.s-item__link').attr('href');
 if (title && title !== "Shop on eBay") { // Jgn Di Hapus Ini
 results.push({ title, price, link });
 }
 });
 return results;
 } catch (error) {
 console.error('Error:', error);
 return [];
 }
 }
// wm avs
 const query = m.text;
 try {
 const results = await azvxz(query);
// wm avs
 if (results.length === 0) {
 m.reply("Tidak ada hasil ditemukan untuk pencarian Anda.");
 } else {
 let response = "Hasil pencarian eBay:\n\n";
 results.forEach((item, index) => {
 response += `${index + 1}. ${item.title}\nHarga: ${item.price}\nLink: ${item.link}\n\n`;
 });
 m.reply(response);
 }
 } catch (error) {
 m.reply("Terjadi Error.");
 }
}
break

case 'drakor': {
 if (!text) {
 throw 'Contoh: Drakor The Red Sleeve';
 }
 m.reply('Mencari informasi drama Korea...');
 try {
 const url = `https://mydramalist.com/search?q=${encodeURIComponent(q)}`;
 const response = await axios.get(url);
 const $ = cheerio.load(response.data);
 const judul = $('.title').first().text().trim();
 const konten = $('.content').first().find('p').map((i, el) => $(el).text().trim()).get().join('\n\n');
 const link = $('.title').first().find('a').attr('href');
// wm avs 
 if (!konten) {
 throw new Error('Tidak Drakor Itu.');
 }
// wm avs
 const artikel = `*Judul:* ${judul}\n\n*Konten:* ${konten}\n\n*Link:* https://mydramalist.com${link}`;
 m.reply(artikel);
 } catch (error) {
 m.reply(`Maaf, terjadi kesalahan: ${error.message}`);
 }
}
break

case 'avenger':
{

if (!text) return reply(`Example : ${prefix+command} +`) 
let link

if (/avenger/.test(command)) link = 'https://en.ephoto360.com/create-logo-3d-style-avengers-online-427.html';


let haldwhd = await ephoto(link, text)
kayyoffc.sendMessage(m.chat, { image: { url: haldwhd }, caption: `Done` }, { quoted: m })
}
break

case 'news-game': {
 const axios = require('axios');
 const cheerio = require('cheerio');
// wm avs
 const url = 'https://www.gamespot.com/news/';
// wm avs
 try {
 const response = await axios.get(url);
 const $ = cheerio.load(response.data);
 let news = [];
// wm avs
 $('.media-title').each((i, elem) => {
 news.push($(elem).text().trim());
 });
// wm avs
 if (news.length === 0) {
 return m.reply('Tidak ada Game Terbaru.');
 }
// wm avs
 let result = `News Game In 2024\n`;
 news.slice(0, 5).forEach((headline, index) => {
 result += `${index + 1}. ${headline}\n`;
 });
// wm avs
 kayyoffc.sendMessage(m.chat, { text: result }, { quoted: m });
 } catch (error) {
 m.reply('ad error.');
 }
}
break

;

;

case 'logo-create-demo': {
 let query = text.trim();

 if (!query) {
 return m.reply('⚠️ Masukkan query untuk membuat logo.\n\nContoh: .logo-create YourText');
 }

 // Menggunakan encodeURIComponent untuk encoding query dengan benar
 let encodedQuery = encodeURIComponent(query);

 let apiUrl = `https://some-logo-api.com/create?text=${encodedQuery}&size=200&color=blue&background=white`;

 m.reply(mess.wait);

 try {
 let response = await axios({
 method: 'GET',
 url: apiUrl,
 responseType: 'arraybuffer'
 });

 if (response.status !== 200) {
 throw new Error(`Error: ${response.status}`);
 }

 m.sendMessage(m.chat, {
 image: response.data,
 caption: `Berikut adalah logo yang dibuat berdasarkan query "${query}"`
 });

 } catch (error) {
 m.reply(`❌ Terjadi kesalahan: ${error.message}`);
 }
}
 break;

case 'ss': case 'ssweb':{ 
if (!/^https?:\/\//.test(text)) return reply('Awali *URL* dengan http:// atau https://')

 let tekss99997 = `*Karina - Botsz*`
let krt = await ssweb(text)
//throw listMessage.sections[0].rows

let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: {
 	mentionedJid: [m.sender], 
 	isForwarded: false, 
	businessMessageForwardInfo: { businessOwnerJid: kayyoffc.decodeJid(kayyoffc.user.id) },
 externalAdReply: { 
 title: 'Aero', 
 thumbnailUrl: 'https://telegra.ph/file/a61add223eb2661c1f38e.jpg', 
 sourceUrl: global.sourceurl,
 mediaType: 2,
 renderLargerThumbnail: false
 }
 }, 
 body: 
proto.Message.InteractiveMessage.Body.create({
 text: tekss99997
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: `Success •`
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ``,
 subtitle: "ziyo",
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: krt.result }, { upload: kayyoffc.waUploadToServer }))
 }),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
{
 "name": "cta_copy",
 "buttonParamsJson": "{\"display_text\":\"Copy Url Web\",\"id\":\"123456789\",\"copy_code\":\"Www.Zio-Ganteng.coy.my.id\"}"
 },
 ],
 })
 })
 }
 }
}, {})

await kayyoffc.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
}
break

case 'g-search': {
 let query = text.trim();
 if (!query) {
 return m.reply('⚠️ Masukkan query untuk melakukan pencarian.\n\nContoh: .g-search Node.js');
 }

 m.reply(mess.wait);

 // Mesin pencari yang digunakan (bing, yahoo, duckduckgo)
 let searchEngines = [
 { name: 'Bing', url: `https://api.bing.microsoft.com/v7.0/search?q=${encodeURIComponent(query)}&count=1`, headers: { 'Ocp-Apim-Subscription-Key': 'YOUR_BING_API_KEY' } },
 { name: 'Yahoo', url: `https://search.yahoo.com/search?p=${encodeURIComponent(query)}` },
 { name: 'DuckDuckGo', url: `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json` }
 ];

 try {
 let results = [];

 for (let engine of searchEngines) {
 let response = await axios.get(engine.url, { headers: engine.headers || {} });
 
 if (engine.name === 'Bing') {
 let result = response.data.webPages.value[0];
 results.push({ title: result.name, link: result.url, snippet: result.snippet });
 } else if (engine.name === 'Yahoo') {
 let $ = cheerio.load(response.data);
 let result = $('a[href*="/r/"]').first();
 results.push({ title: result.text(), link: result.attr('href'), snippet: result.closest('p').text() });
 } else if (engine.name === 'DuckDuckGo') {
 let result = response.data.RelatedTopics[0];
 results.push({ title: result.Text, link: result.FirstURL, snippet: '' });
 }
 }

 // Jika ada hasil, kirimkan ke WhatsApp
 if (results.length > 0) {
 let responseText = `🔍 *Hasil Pencarian untuk:* "${query}"\n\n`;
 results.forEach((result, index) => {
 responseText += `*${index + 1}. ${result.title}*\n_${result.snippet}_\n[Link](${result.link})\n\n`;
 });
 m.reply(responseText);
 } else {
 m.reply('❌ Tidak ada hasil yang ditemukan.');
 }

 } catch (error) {
 m.reply(`❌ Terjadi kesalahan: ${error.message}`);
 }
}
 break;



case "ttsprabowo": {
 if(!q) return reply("Sertakan teks untuk diucapkan!!")
 kayyoffc.sendMessage(from, { audio: { url: `https://ai.xterm.codes/api/text2speech/elevenlabs?text=${q}&key=Bell409&voice=prabowo` }, mimetype: "audio/mpeg", ptt:true })
}
break

case 'coco': case 'cocofun':{
 if (!text) return m.reply('• *Example :* .cocofun https://cocofun.com/xxxx')
//tanakaganteng
 kayyoffc.sendMessage(m.chat, { react: { text: "🕒", key: m.key } });
//tanakasenn
 let kampang = await fetch(`https://api.lolhuman.xyz/api/cocofun?apikey=Apitanakasenn&url=${text}`)
 let res = await kampang.json()
//tanakasenn
 let juucpstr = `Title: ${res.result.title}\nTag: ${res.result.tag}\nLike: ${res.result.likes}\nViews: ${res.result.views}\nUploader: ${res.result.uploader}\nDuration: ${res.result.duration}`
kayyoffc.sendMessage(m.chat, { video: { url: res.result.nowm }, caption: juucpstr }, { quoted: m })
 }
 break

case 'rangkum': {
 if (!q) return m.reply(`Masukkan kalimat Yang Mau di rangkum`);
// wm avs
 const sentences = `${q}`.match(/[^.!?]+[.!?]/g) || [];
// wm avs
 const wordFrequency = {};
 sentences.forEach(sentence => {
 const words = sentence.toLowerCase().split(/\s+/);
 words.forEach(word => {
 word = word.replace(/[.,!?]/g, '');
 if (word.length > 0) {
 if (wordFrequency[word]) {
 wordFrequency[word]++;
 } else {
 wordFrequency[word] = 1;
 }
 }
 });
 });
// wm avs
 const sortedWords = Object.keys(wordFrequency).sort((a, b) => wordFrequency[b] - wordFrequency[a]);
// wm avs
 const summarySentences = sentences
 .filter(sentence => {
 const words = sentence.toLowerCase().split(/\s+/).map(word => word.replace(/[.,!?]/g, ''));
 return words.some(word => sortedWords.includes(word));
 })
 .slice(0, 3);
// wm avs
 const summary = summarySentences.join(' ');
// wm avs
 m.reply(summary || "Gagal merangkum teks.");
}
break

case 'animecharacter': {
 if (!text) {
 m.reply('Contoh: animecharacter naruto');
 return;
 }
// wm avs
 m.reply('_Sabar tuan, sedang mencari karakter anime..._');
// wm avs
 async function getCharacterInfo(characterName) {
 const query = `
 query ($search: String) {
 Character(search: $search) {
 name {
 full
 }
 description
 media {
 nodes {
 title {
 romaji
 }
 }
 }
 }
 }
 `;
 const variables = {
 search: characterName
 };
// wm avs
 const response = await fetch('https://graphql.anilist.co', {
 method: 'POST',
 headers: {
 'Content-Type': 'application/json',
 'Accept': 'application/json',
 },
 body: JSON.stringify({
 query: query,
 variables: variables
 })
 });
 if (!response.ok) {
 throw new Error('Gagal mengambil data karakter');
 }
// wm avs
 const data = await response.json();
 return data.data.Character;
 }
// wm avs
 try {
 const query = text.trim();
 const characterInfo = await getCharacterInfo(query);
// wm avs
 if (!characterInfo) {
 m.reply('Karakter Gda.');
 return;
 }
// wm avs
 // Format hasil pencarian karakter
 const name = characterInfo.name.full;
 const description = characterInfo.description || 'Deskripsi tidak Ada';
 const mediaTitles = characterInfo.media.nodes.map(node => node.title.romaji).join(', ');
// wm avs
 const formattedDescription = description
 .replace(/\n/g, '\n\n') // jgb ubah
 .replace(/__([^__]+)__/g, '*$1*') // jgn ubah 
 .replace(/~\!?\[([^\]]+)]\(([^)]+)\)~?/g, '*$1* ($2)') // jgn ubah ini
 .replace(/^\s+/gm, '');
// wm avs
 const result = `*Nama Karakter:* ${name}\n\n*Deskripsi:* ${formattedDescription}\n\n*Media Terkait:* ${mediaTitles}`;
// wm avs
 m.reply(result);
// wm avs
 } catch (error) {
 m.reply(`Terjadi kesalahan: ${error.message}`);
 }
}
break

case 'cerpen-anak':{
let hasil = await cerpen(`anak`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-bahasadaerah':{
let hasil = await cerpen(`bahasa daerah`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-bahasainggris':{
let hasil = await cerpen(`bahasa Inggris`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-bahasajawa':{
let hasil = await cerpen(`bahasa jawa`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-bahasasunda':{
let hasil = await cerpen(`bahasa sunda`)
replygcLorenzo(`
 ❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-budaya':{
let hasil = await cerpen(`budaya`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-cinta':{
let hasil = await cerpen(`cinta`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-cintaislami':{
let hasil = await cerpen(`cinta islami`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-cintapertama':{
let hasil = await cerpen(`cinta pertama`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-cintaromantis':{
let hasil = await cerpen(`cinta romantis`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-cintasedih':{
let hasil = await cerpen(`cinta sedih`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-cintasegitiga':{
let hasil = await cerpen(`Cinta segitiga`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-cintasejati':{
let hasil = await cerpen(`cinta sejati`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-galau':{
let hasil = await cerpen(`galau`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-gokil':{
let hasil = await cerpen(`gokil`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-inspiratif':{
let hasil = await cerpen(`inspiratif`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-jepang':{
let hasil = await cerpen(`jepang`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-kehidupan':{
let hasil = await cerpen(`kehidupan`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-keluarga':{
let hasil = await cerpen(`keluarga`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-kisahnyata':{
let hasil = await cerpen(`kisah nyata`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-korea':{
let hasil = await cerpen(`korea`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-kristen':{
let hasil = await cerpen(`kristen`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-liburan':{
let hasil = await cerpen(`liburan`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-malaysia':{
let hasil = await cerpen(`malaysia`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-mengharukan':{
let hasil = await cerpen(`mengharukan`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-misteri':{
let hasil = await cerpen(`misteri`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-motivasi':{
let hasil = await cerpen(`motivasi`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-nasihat':{
let hasil = await cerpen(`nasihat`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-nasionalisme':{
let hasil = await cerpen(`nasionalisme`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-olahraga':{
let hasil = await cerpen(`olahraga`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-patahhati':{
let cerpe = await cerpen(`patah hati`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-penantian':{
let hasil = await cerpen(`penantian`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-pendidikan':{
let hasil = await cerpen(`pendidikan`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-pengalaman':{
let hasil = await cerpen(`pengalaman pribadi`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-pengorbanan':{
let hasil = await cerpen(`pengorbanan`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-penyesalan':{
let hasil = await cerpen(`penyesalan`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-perjuangan':{
let hasil = await cerpen(`perjuangan`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-perpisahan':{
let hasil = await cerpen(`perpisahan`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-persahabatan':{
let hasil = await cerpen(`persahabatan`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-petualangan':{
let hasil = await cerpen(`petualangan`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-ramadhan':{
let hasil = await cerpen(`ramadhan`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-remaja':{
let hasil = await cerpen(`remaja`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-rindu':{
let hasil = await cerpen(`rindu`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-rohani':{
let cerpe = await cerpen(`rohani`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-romantis':{
let hasil = await cerpen(`romantis`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-sastra':{
let hasil = await cerpen(`sastra`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-sedih':{
let hasil = await cerpen(`sedih`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-sejarah':{
let hasil = await cerpen(`sejarah`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break

case 'freefirepet': case 'ffpet': case 'freefire_pet': {
async function petNew() {
 try {
 let response = await axios.get('https://ff.garena.com/id/pets/');
 
 let $ = cheerio.load(response.data);
 
 let hasil = [];

 $('.pet-box.pet-box-new').each((index, element) => {
 let name = $(element).find('.pet-name').text();
 let talk = $(element).find('.pet-abstract').text();
 
 let idElement = $(element).find('a');

 if (idElement.length > 0) {
 let id = idElement.attr('href');
 const match = id.match(/\/(\d+)$/);
 const idRes = match ? parseInt(match[1]) : null;

 hasil.push({
 name: name.trim(),
 talk: talk.trim(),
 id: idRes
 });
 } else {
 console.error('Error: Anchor element not found for the following element:');
 console.log(element);
 }
 });

 return hasil;
 } catch (error) {
 console.error('Error:', error);
 throw error;
 }
}

async function petSkill(id) {
let response = await axios.get(`https://ff.garena.com/id/pets/${id}`)
let $ = cheerio.load(response.data)
let hasil = []
let name = $('.skill-profile-name').text()
let skill = $('.skill-introduction').text()
hasil.push({

name: name.trim(),
skill: skill.trim()
})
return hasil 
}

if (!text) {
let response = await petNew()
let content = ``
response.forEach((element, index) => {
content += `*${index + 1}.* ${element.name}
- *Quotes:* ${element.talk}
- *Id:* ${element.id}\n\n`
})
reply(content)
} else {
let response = await petSkill(text)
reply(`- *Pet name:* ${response[0].name}
- *Skill:* ${response[0].skill}`)
}
}
break
case 'addcase': {
 if (!isCreator) return reply('lu sapa asu')
 if (!text) return reply('Mana case nya');
    const fs = require('fs');
const namaFile = 'kayyoffc.js';
const caseBaru = `${text}`;
fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) {
        console.error('Terjadi kesalahan saat membaca file:', err);
        return;
    }
    const posisiAwalGimage = data.indexOf("case 'addcase':");

    if (posisiAwalGimage !== -1) {
        const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage);
        fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
            if (err) {
                reply('Terjadi kesalahan saat menulis file:', err);
            } else {
                reply('Case baru berhasil di tambahkan.');
            }
        });
    } else {
        reply('Tidak dapat menambahkan case dalam file.');
    }
});

}
break

    
case 'listcase': {
let { listCase } = require('./lib/scrapelistCase.js')
reply(listCase())
}
break
case 'ai': case 'openai': {
if (!text) return reply(`${command} Apa itu Coding`)
            reply(mess.search)
            let yanz = await fetchJson(`https://aemt.me/v2/gpt4?text=${text}`)
kayyoffc.sendMessage(m.chat, {
text: yanz.result,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
title: `O P E N - A I`,
body: '',
thumbnailUrl: "https://telegra.ph/file/f47d75d0d4827356a526d.jpg",
sourceUrl: hariini,
mediaType: 1,
renderLargerThumbnail: true
}}
})
            }
break
case "listgc":{
if (!isCreator) return (`Ngapain ? Khusus aero Aja !!`)
let getGroups = await kayyoffc.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
let hituet = 0
let teks = `⬣ *LIST GROUP DI BAWAH*\n\nTotal Group : ${anu.length} Group\n\n`
for (let x of anu) {
let metadata2 = await kayyoffc.groupMetadata(x)
teks += `❏ Group Ke ${hituet+=1}\n│⭔ *NAMA :* ${metadata2.subject}\n│⭔ *ID :* ${metadata2.id}\n│⭔ *MEMBER :* ${metadata2.participants.length}\n╰────|\n\n`
}
reply(teks + `Untuk Penggunaan Silahkan Ketik Command ${prefix}pushkontakv1 id|teks\n\nSebelum Menggunakan Silahkan Salin Dulu ID Group Nya Di Atas`)
}
break
case 'tourl': {
if (isBan) return reply2(mess.ban)
if (!/video/.test(mime) && !/image/.test(mime)) throw `*Send/Reply the Video/Image With Caption* ${prefix + command}`
if (!quoted) throw `*Send/Reply the Video/Image Caption* ${prefix + command}`
let { UploadFileUgu, webp2mp4File, TelegraPh } = require('./lib/uploader')
let media = await kayyoffc.downloadAndSaveMediaMessage(quoted)
if (/image/.test(mime)) {
let anu = await TelegraPh(media)
reply(util.format(anu))
} else if (!/image/.test(mime)) {
let anu = await UploadFileUgu(media)
reply(util.format(anu))
}
await fs.unlinkSync(media)
}
break
//================ D O W N L O A D ==================//
case 'ytmp3': case 'youtubemp3': {
if (!text) throw `Example : ${prefix + command} https://youtube.com/watch?v=PtFMh6Tccag%27 128kbps`
await loading ()
reply(mess.search)
downloadMp3(text)
}
break
case "ytreels": case "ytmp4":{
if (!text) return reply('Masukan Link Nya!!!')
await loading ()
reply(mess.search)
downloadMp4(text)
}
break
case 'tt': {
if (!text) return reply(`masukan link tiktoknya`)
let old = new Date()
const dlt = require('./lib/tiktokdl.js')
let tiktuk = await dlt.DownloadTiktok(text)
if (tiktuk.result.images) {
tiktuk.result.images.forEach(async (k) => {
await kayyoffc.sendMessage(m.chat, { image: { url: k }}, { quoted: fcall });
})
} else {
kayyoffc.sendMessage(m.chat, { video: { url: tiktuk.result.video }, caption: `${gris}[ T I K T O K - D O W N L O A D E R ]${gris}\n\n${hiasan}*Author* : ${tiktuk.result.author.nickname}\n${hiasan}*Desc* : ${tiktuk.result.desc}\n${hiasan}*Statistic* : ${tiktuk.result.statistic}\n${hiasan}*Fetching* : ${((new Date - old) * 1)} ms\n\n` }, { quoted: fcall })
}
}
break
case 'instagram': {
if (!text) throw `Example : ${prefix + command} https://www.instagram.com/p/CJ8XKFmJ4al/?igshid=1acpcqo44kgkn`
await loading ()
reply(mess.search)
let iganu = await igdl2(text)
kayyoffc.sendMessage(m.chat, { video: { url: iganu[0].url }, caption: mess.success })
}
break


//================== S T O R E =======================//
case 'testi1':{
let tekssss = `𝗛𝗮𝗹𝗹𝗼 𝗸𝗮𝗸👋🏻
Gambar di atas adalah testimoni Dari ${namaStore}

Untuk Nominal transaksi bisa cek di atas ya kak..

Yang pasti ${namaStore} adalah store paling amanah dan terpercaya✨

(Testimoni ke 1)
`
kayyoffc.sendMessage(from, { image: fs.readFileSync(`./testimoni/testimoni_1.jpg`),
 caption: tekssss, 
footer: `${ownerStore} © 2023`},
{quoted: fcall})
}
break
case 'testi2':{
let tekssss = `𝗛𝗮𝗹𝗹𝗼 𝗸𝗮𝗸👋🏻
Gambar di atas adalah testimoni Dari ${namaStore}

Untuk Nominal transaksi bisa cek di atas ya kak..

Yang pasti ${namaStore} adalah store paling amanah dan terpercaya✨

(Testimoni ke 2)
`
kayyoffc.sendMessage(from, { image: fs.readFileSync(`./testimoni/testimoni_2.jpg`),
 caption: tekssss, 
footer: `${ownerStore} © 2023`},
{quoted: fcall})
}
break
case 'testi3':{
let tekssss = `𝗛𝗮𝗹𝗹𝗼 𝗸𝗮𝗸👋🏻
Gambar di atas adalah testimoni Dari ${namaStore}

Untuk Nominal transaksi bisa cek di atas ya kak..

Yang pasti ${namaStore} adalah store paling amanah dan terpercaya✨

(Testimoni ke 3)
`
kayyoffc.sendMessage(from, { image: fs.readFileSync(`./testimoni/testimoni_3.jpg`),
 caption: tekssss, 
footer: `${ownerStore} © 2023`},
{quoted: fcall})
}
break
case 'testi4':{
let tekssss = `𝗛𝗮𝗹𝗹𝗼 𝗸𝗮𝗸👋🏻
Gambar di atas adalah testimoni Dari ${namaStore}

Untuk Nominal transaksi bisa cek di atas ya kak..

Yang pasti ${namaStore} adalah store paling amanah dan terpercaya✨

(Testimoni ke 4)
`
kayyoffc.sendMessage(from, { image: fs.readFileSync(`./testimoni/testimoni_4.jpg`),
 caption: tekssss, 
footer: `${ownerStore} © 2023`},
{quoted: fcall})
}
break
case 'testi5':{
let tekssss = `𝗛𝗮𝗹𝗹𝗼 𝗸𝗮𝗸👋🏻
Gambar di atas adalah testimoni Dari ${namaStore}

Untuk Nominal transaksi bisa cek di atas ya kak..

Yang pasti ${namaStore} adalah store paling amanah dan terpercaya✨

(Testimoni ke 5)
`
kayyoffc.sendMessage(from, { image: fs.readFileSync(`./testimoni/testimoni_5.jpg`),
 caption: tekssss, 
footer: `${ownerStore} © 2023`},
{quoted: fcall})
}
break
case 'sdomain': case 'sendomain': {
     if (!isCreator) return reply(`Ngapain ? Khusus KayyOffc Aja !!`)
          if (!text) return reply(`Example : ${prefix + command} 6285xxxxx,harga,domain`)
            reply('Pesanan Telah Sukses Dikirim') 
            var mon = args.join(' ')
            var m1 = mon.split(",")[0]
            var m2 = mon.split(",")[1]
            var m3 = mon.split(",")[2]
                    let mq1 = m1 + '@s.whatsapp.net'
                  let ownernya = owner + '@s.whatsapp.net'
               let me = m.sender
               let ments = [mq1, ownernya, me]
kayyoffc.sendMessage(mq1, {text:`*───❖》KayyOff 《❖───*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n*📦 Pesananmu Datang 📦*\n*Harga : ${m2}*\n*Hari : ${hariini}*\n*Tanggal : ${tanggal}*\n*Jam : ${jam}*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n*[+] Domain : ${m3}*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n*_Note : Tutup ( Sensor ) Domain Anda Dan Jangan Sampai Orang Lain Melihat Atau Tidak Nanti Domain Anda Bakal Kena Ddos Attack_*\n\n\n\n*© KayyOffc*`}, m) 
                 }
            break
case "reqvps":{
if (!isCreator) return;
ewe = `*بِسۡـــــــــمِ ٱللهِ ٱلرَّحۡـمَـٰنِ ٱلرَّحِـــــــيم*

Region : 
Os : 
Version : 
Password : 
▰▰▰▰▰▰▰▰
*Garansi 14 Day*
*Create ${tanggal2}*
*Hari Ini ${hariini}*`
await kayyoffc.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: 1000000000,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: ewe,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {})
}
break
case "reqpanel":{
if (!isCreator) return;
ewe = `*بِسۡـــــــــمِ ٱللهِ ٱلرَّحۡـمَـٰنِ ٱلرَّحِـــــــيم*

Ram : 
Username :
Nomor Wa : 
▰▰▰▰▰▰▰▰
*Garansi 14 Day*
*Create ${tanggal2}*
*Hari Ini ${hariini}*`
await kayyoffc.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: 1000000000,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: ewe,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {})
}
break
case 'tunda':
text_trxpending = `「 𝗧𝗥𝗔𝗡𝗦𝗔𝗞𝗦𝗜 𝗣𝗘𝗡𝗗𝗜𝗡𝗚 」

𝗧𝗥𝗔𝗡𝗦𝗔𝗞𝗦𝗜 𝗣𝗘𝗡𝗗𝗜𝗡𝗚
𝗛𝗔𝗥𝗔𝗣 𝗕𝗘𝗥𝗦𝗔𝗕𝗔𝗥`
await kayyoffc.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: 1000000000,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: text_trxpending,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {})
break
case 'proses':
text_proses = `「 𝗦𝗘𝗗𝗔𝗡𝗚 𝗗𝗜 𝗣𝗥𝗢𝗦𝗘𝗦 」

𝗛𝗮𝗿𝗮𝗽 𝗧𝘂𝗻𝗴𝗴𝘂 𝗦𝗲𝗯𝗲𝗻𝘁𝗮𝗿
𝗣𝗿𝗼𝗱𝘂𝗸 𝗦𝗲𝗱𝗮𝗻𝗴 𝗗𝗶 𝗣𝗿𝗼𝘀𝗲𝘀️`
await kayyoffc.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: 1000000000,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: text_proses,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {})
break
case 'batal':
text_trxbatal = `「 𝗧𝗥𝗔𝗡𝗦𝗔𝗞𝗦𝗜 𝗕𝗔𝗧𝗔𝗟 」

📆 𝗧𝗮𝗻𝗴𝗴𝗮𝗹: ${tanggal2}
🕰️ 𝗪𝗮𝗸𝘁𝘂: ${time}
✨ 𝗦𝘁𝗮𝘁𝘂𝘀: Batal

𝗦𝗲𝗹𝘂𝗿𝘂𝗵 𝗧𝗿𝗮𝗻𝘀𝗮𝗸𝘀𝗶 𝗕𝗮𝘁𝗮𝗹`
await kayyoffc.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: 1000000000,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: text_trxbatal,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {})
break
case 'done': case 'd': {
if (!isCreator) return reply(`Njirr Lu siapa Cuk`)
text_done = `「 𝗧𝗥𝗔𝗡𝗦𝗔𝗞𝗦𝗜 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 」

📆 𝗧𝗮𝗻𝗴𝗴𝗮𝗹: ${tanggal2}
🕰️ 𝗪𝗮𝗸𝘁𝘂: ${time}
✨ 𝗦𝘁𝗮𝘁𝘂𝘀: Berhasil

𝗧𝗲𝗿𝗶𝗺𝗮𝗸𝗮𝘀𝗶𝗵 𝗧𝗲𝗹𝗮𝗵 𝗢𝗿𝗱𝗲𝗿 𝗗𝗶 KAYYOFC
𝗗𝗶 𝗧𝘂𝗻𝗴𝗴𝘂 𝗢𝗿𝗱𝗲𝗿𝗮𝗻 𝗦𝗲𝗹𝗮𝗻𝗷𝘂𝘁𝗻𝘆𝗮☺️`
await kayyoffc.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: 1000000000,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: text_done,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {})
}
break
case 'listpanel':{
let list =`Hai Kak ${pushname}

*Pricelist Harga KayyOffc Panel* :

1GB RAM/1GB Disk/50% CPU
Rp2.000,00/1 BULAN

2GB RAM/2GB Disk/70% CPU
Rp4.000,00/1 BULAN

3GB RAM/3GB Disk/100% CPU
Rp6.000,00/1 BULAN

4GB RAM/4GB Disk/125% CPU
Rp8.000,00/1 BULAN

5GB RAM/5GB Disk/150% CPU
Rp10.000,00/1 BULAN

6GB RAM/6GB Disk/175% CPU
Rp12.000.00/1 BULAN

7GB RAM/7GB Disk/175% CPU
Rp15.000.00/1 BULAN

8GB RAM/8GB Disk/200% CPU
Rp16.000,00/1 BULAN

UNLI RAM/UNLI Disk/UNLI CPU
Rp10.000,00/1 BULAN

Nb:
Kalau Andah sudah Transfer artinya anda setuju dengan segala kebijakan kami.
Untuk pricelist renew berlaku jika ada server yg masih aktif di dalam akun minimal selama 23hari.

*© Kayy Offc*`
await kayyoffc.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: 1000000000,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: list,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {})
}
break
case 'listvps': case 'rlistvps':{
let menu_nya =`Hai Kak ${pushname}

*LIST HARGA VPS BY KAYY OFFC*

- RAM 2GB CORE 2 : 20K
- RAM 4GB CORE 2 : 40K
- RAM 8GB CORE 4 : 60K

*NOTE*
- GARANSI 14 HARI
- MASA AKTIF 1 BULAN
- PROVAIDER : LINODE

*MINAT? CHAT*
Wa.me/6285963142450

*© Kayy Offc*`
await kayyoffc.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: 1000000000,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: menu_nya,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {})
}
break
case 'sewa':
if (isBan) return reply(mess.ban)
await loading()
ewe = `¥ *Price Sewa Bot Shekai* €

🔏 3 hari = 10k
🔏 1 minggu = 15k
🔏 2 minggu = 25k
🔏 1 bulan = 40k

Untuk Melanjutkan Sewa Silahkan Ketik Contoh Di bawah
*Contoh => sewabot 1 minggu`
await kayyoffc.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: 1000000000,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: ewe,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {})
break
case 'sewabot':
if (isBan) return reply(mess.ban)
if (!text) return reply(`*Contoh* :\n#sewabot 1 minggu `)
await loading()
let cret = await kayyoffc.groupCreate(args.join(" "), [])
let ky = await kayyoffc.groupInviteCode(cret.id)
kayyoffc.sendMessage(m.chat, { text: `「 *Create Group Sewa* 」

Sewa Bot Selama *${text}* Sedang Dalam Prosess Silahkan Masuk Melalui Link Group Yang Sudah Di Sediakan..

_▸ Owner : ${botname}
_▸ Time : ${moment(cret.creation * 1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")} WIB_https://chat.whatsapp.com/${ky}
`, m})
reply('pesan dan link group khusus sudah terkirim di chat privasi anda')
break
//=================== G R O U P =====================//
case 'totag': {
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(`Ehh Bot Nya Belum Jadi Admin ☝️😅`)
if (!isAdmins) return reply(mess.admin)
if (!m.quoted) return `Reply pesan dengan caption ${prefix + command}`
kayyoffc.sendMessage(m.chat, { forward: m.quoted.fakeObj, mentions: participants.map(a => a.id) })
}
break
case 'linkgroup': case 'linkgc': {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.badm)
await loading()
let response = await kayyoffc.groupInviteCode(from)
kayyoffc.sendText(from, `https://chat.whatsapp.com/${response}\n\nLink Group : ${groupMetadata.subject}`, m, { detectLink: true })
}
break
case 'resetlinkgc':
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.badm)
await loading()
kayyoffc.groupRevokeInvite(from)
break
case 'sendlinkgc': {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.badm)
await loading()
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6281214281312`)
bnnd = text.split("|")[0]+'@s.whatsapp.net'
let response = await kayyoffc.groupInviteCode(from)
kayyoffc.sendText(bnnd, `https://chat.whatsapp.com/${response}\n\nLink Group : ${groupMetadata.subject}`, m, { detectLink: true })

}
break
case 'kick': {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.badm)
if (!isAdmins) return reply(mess.admin)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await kayyoffc.groupParticipantsUpdate(from, [users], 'remove')
reply(mess.done)
}
break
case 'add': {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.badm)
if (!isAdmins) return reply(mess.admin)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await kayyoffc.groupParticipantsUpdate(from, [users], 'add')
reply(mess.done)
}
break
case 'promote': {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.badm)
if (!isAdmins) return reply(mess.admin)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await kayyoffc.groupParticipantsUpdate(from, [users], 'promote')
reply(mess.done)
}
break
case 'demote': {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.badm)
if (!isAdmins) return reply(mess.admin)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await kayyoffc.groupParticipantsUpdate(from, [users], 'demote')
reply(mess.done)
}
break
case 'hidetag': {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
await loading()
kayyoffc.sendMessage(from, { text : q ? q : '' , mentions: participants.map(a => a.id)}, {quoted:fcall})
}
break
case 'tagall': {
if (!isAdmins) return reply(mess.admin)
if (!m.isGroup) return
await loading()
let teks = `══✪〘 *👥 Tag All* 〙✪══
 ➲ *Pesan : ${q ? q : 'kosong'}*\n\n`
for (let mem of participants) {
teks += `⭔ @${mem.id.split('@')[0]}\n`
}
kayyoffc.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, { quoted:fcall })
}
break

case 'pushkontak2':{
if (!isCreator) return reply(mess.owner)
let idgc = text.split("|")[0]
let pesan = text.split("|")[1]
if (!idgc && !pesan) return reply(`Example: ${prefix + command} idgc|pesan`)
let metaDATA = await kayyoffc.groupMetadata(idgc).catch((e) => reply(e))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
let count = getDATA.length;
let sentCount = 0;
reply(`*_Sedang Push ID..._*\n*_Mengirim pesan ke ${getDATA.length} orang, waktu selesai ${getDATA.length * 3} detik_*`)
for (let i = 0; i < getDATA.length; i++) {
setTimeout(function() {
kayyoffc.sendMessage(getDATA[i], { text: pesan });
count--;
sentCount++;
if (count === 0) {
reply(`*_Semua pesan telah dikirim!:_* *_✓_*\n*_Jumlah pesan terkirim:_* *_${sentCount}_*`);
}
}, i * 3000);
}
}
break;
case 'pushkontak':{
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(`di group coy`)
if (!text) return reply(`Teks Nya Kak?`)
let mem = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
let teksnye = `${q}`
reply(`*Mengirim pesan ke ${mem.length} orang, waktu selesai ${mem.length * 3} detik*`)
for (let geek of mem) {
await sleep(3000)
kayyoffc.sendMessage(geek, {text: `${teksnye}`}, {quoted:fcall})
}
reply(`*Sukses mengirim pesan Ke ${mem.length} orang*`)
}
break
case "cekidgc": {
if (!isCreator) return reply(mess.premium)
let getGroups = await kayyoffc.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
let teks = `⬣ *LIST GROUP DI BAWAH*\n\nTotal Group : ${anu.length} Group\n\n`
for (let x of anu) {
let metadata2 = await kayyoffc.groupMetadata(x)
teks += `◉ Nama : ${metadata2.subject}\n◉ ID : ${metadata2.id}\n◉ Member : ${metadata2.participants.length}\n\n────────────────────────\n\n`
}
reply(teks + `Untuk Penggunaan Silahkan Ketik Command ${prefix}pushkontak id|teks\n\nSebelum Menggunakan Silahkan Salin Dulu Id Group Nya Di Atas`)
}
break
case 'getidgc':
if (!m.isGroup) return reply('kusus Group')
ewe = `${m.chat}`
await kayyoffc.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: 1000000000,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: ewe,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {})
break
case 'join': {
if (!isCreator) return reply(mess.owner)
if (!text) throw 'Masukkan Link Group!'
if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) throw 'Link Invalid!'
await loading()
let result = args[0].split('https://chat.whatsapp.com/')[1]
await kayyoffc.groupAcceptInvite(result).then((res) => reply(jsonformat(res))).catch((err) => reply(jsonformat(err)))
}
break
//==================================================//
// Linode
case "deletelinode": {
  if (!isCreator) return reply('Maaf, command ini hanya untuk pemilik.');

  let linodeId = args[0];
  if (!linodeId) return reply('ID Linode belum diberikan.');

  let deleteLinode = async () => {
    try {
      let response = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINODE_API_TOKEN}`
        }
      });

      if (response.status === 204) {
        reply('Linode berhasil dihapus.');
      } else {
        throw new Error('Gagal menghapus Linode.');
      }
    } catch (error) {
      console.error('Terjadi kesalahan saat menghapus Linode:', error);
      reply('Sukses Menghapus Linode.');
    }
  };

  deleteLinode();

  break;
}
case "sisalinode": {
  if (!isCreator) return reply(mess.owner);

  async function getLinodeInfo() {
    try {
      const response = await fetch('https://api.linode.com/v4/account', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINODE_API_TOKEN}`,
        },
      });

      if (response.ok) {
        const accountInfo = await response.json();
        const linodeLimit = accountInfo.data.active_promo?.total || 0;
        const linodesCount = accountInfo.data.active_promo?.remaining || 0;

        return {
          linodeLimit,
          remainingLinodes: linodesCount,
          totalLinodes: linodeLimit - linodesCount,
        };
      } else {
        throw new Error('Gagal mendapatkan data akun Linode.');
      }
    } catch (error) {
      throw error;
    }
  }

  // Definisikan fungsi untuk mengeksekusi kasus "sisalinode"
  async function sisalinodeHandler() {
    try {
      if (!isCreator) {
        return reply('Lu Siapanya Gua Anjg');
      }

      const linodeInfo = await getLinodeInfo();
      reply(`*Sisa VPS Linode Yang Dapat Anda Buat: ${linodeInfo.remainingLinodes}*

*Total VPS Linode Yang Sudah Terbuat: ${linodeInfo.totalLinodes}*`);
    } catch (error) {
      reply(`Terjadi kesalahan: ${error.message}`);
    }
  }

  sisalinodeHandler();
  break;
}



case "rebuildlinode": {
  if (!isCreator) return reply(`Lu Siapanya Gua Anjg Gausah Nyuruh Nyuruh Gua Anjg`);

  let linodeId = args[0];
  if (!linodeId) return reply('ID Linode belum diberikan.');

  let password = args[1]; // Mengambil password dari argumen kedua (jika ada)
  if (!password) return reply('Password belum diberikan.');

  let rebuildVPS = async () => {
    try {
      // Rebuild VPS menggunakan API Linode
      const response = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}/rebuild`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINODE_API_TOKEN}`
        },
        body: JSON.stringify({
          image: 'linode/ubuntu20.04', // Ganti dengan ID atau label image yang ingin digunakan untuk rebuild
          root_pass: password // Menggunakan password yang diberikan
        })
      });

      if (response.ok) {
        reply('Rebuild VPS berhasil dimulai.');

        // Mendapatkan informasi VPS setelah rebuild
        const vpsInfo = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${LINODE_API_TOKEN}`
          }
        });

        if (vpsInfo.ok) {
          const vpsData = await vpsInfo.json();
          const ipAddress = vpsData.ipv4[0] || 'Tidak ada IP';

          const textvps = `*VPS SUKSES REBUILD*\nIP VPS: ${ipAddress}\nSYSTEM IMAGE: Ubuntu 20.04\nPASSWORD: ${password}`;
          await sleep(60000);
          kayyoffc.sendMessage(m.chat, { text: textvps });
        } else {
          reply('Gagal mendapatkan informasi VPS setelah rebuild.');
        }
      } else {
        const errorData = await response.json();
        reply('Gagal melakukan rebuild VPS:', errorData.errors[0].reason);
      }
    } catch (error) {
      reply('Terjadi kesalahan saat melakukan rebuild VPS:', error.message);
    }
  };

  rebuildVPS();
  break;
}

case "linode8gb": {
  if (!isCreator) return reply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
  try {
    let linodeData = {
      label: `${args[0]}`,
      region: 'ap-south', // Ganti dengan region yang diinginkan
      type: 'g6-standard-4', // Spesifikasi 8GB RAM 4 Core CPU
      image: 'linode/ubuntu20.04', // Ganti dengan image yang diinginkan
      root_pass: generateRandomPassword(),
      stackscript_id: null,
      authorized_keys: null,
      backups_enabled: false
    };

    const response = await fetch('https://api.linode.com/v4/linode/instances', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${LINODE_API_TOKEN}`
      },
      body: JSON.stringify(linodeData)
    });

    const responseData = await response.json();

    if (response.ok) {
      const linodeId = responseData.id;

      // Menunggu hingga Linode selesai dibuat
      reply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang Linode
      const linodeResponse = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINODE_API_TOKEN}`
        }
      });

      const linodeInfo = await linodeResponse.json();
      const ipAddress = linodeInfo.ipv4[0]; // Alamat IP Linode

      let messageText = `Linode berhasil dibuat!\n\n`;
      messageText += `ID: ${linodeId}\n`;
      messageText += `IP Linode: ${ipAddress}\n`;
      messageText += `Password: ${linodeData.root_pass}\n`;

      await kayyoffc.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat Linode: ${responseData.errors[0].reason}`);
    }
  } catch (err) {
    console.error(err);
    reply(`Terjadi kesalahan saat membuat Linode: ${err}`);
  }
}
break;

case "linode16gb": {
  if (!isCreator) return reply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
  try {
    let linodeData = {
      label: `${args[0]}`,
      region: 'ap-south',
      type: 'g6-standard-8',
      image: 'linode/ubuntu20.04',
      root_pass: generateRandomPassword(),
      stackscript_id: null,
      authorized_keys: null,
      backups_enabled: false
    };

    const response = await fetch('https://api.linode.com/v4/linode/instances', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${LINODE_API_TOKEN}`
      },
      body: JSON.stringify(linodeData)
    });

    const responseData = await response.json();

    if (response.ok) {
      const linodeId = responseData.id;

      // Menunggu hingga Linode selesai dibuat
      reply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang Linode
      const linodeResponse = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINODE_API_TOKEN}`
        }
      });

      const linodeInfo = await linodeResponse.json();
      const ipAddress = linodeInfo.ipv4[0]; // Alamat IP Linode

      let messageText = `Linode berhasil dibuat!\n\n`;
      messageText += `ID: ${linodeId}\n`;
      messageText += `IP Linode: ${ipAddress}\n`;
      messageText += `Password: ${linodeData.root_pass}\n`;

      await kayyoffc.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat Linode: ${responseData.errors[0].reason}`);
    }
  } catch (err) {
    console.error(err);
    reply(`Terjadi kesalahan saat membuat Linode: ${err}`);
  }
}
break;

case "cekvpslinode": {
  if (!isCreator) return reply('Maaf, perintah ini hanya untuk pemilik.');

  let linodeId = args[0];
  if (!linodeId) return reply('ID Linode belum diberikan.');

  // Mendapatkan informasi VPS Linode berdasarkan ID
  const getLinodeInfo = async (linodeId) => {
    try {
      const apiUrl = `https://api.linode.com/v4/linode/instances/${linodeId}`;
      const response = await fetch(apiUrl, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINODE_API_TOKEN}`
        }
      });

      if (response.ok) {
        const linodeInfo = await response.json();

        const ipAddress = linodeInfo.ipv4[0]; // Alamat IP Linode
        const ram = `${linodeInfo.specs.memory / 1024} GB`; // RAM VPS dalam GB
        const os = linodeInfo.image.distribution; // Nama OS
        const cpu = `${linodeInfo.specs.vcpus} vCPUs`; // Jumlah vCPUs
        const storage = linodeInfo.specs.disk; // Kapasitas penyimpanan
        const status = linodeInfo.status; // Status VPS

        const createDate = new Date(linodeInfo.created); // Tanggal pembuatan VPS
        const formattedCreateDate = createDate.toLocaleDateString();

        return {
          linodeid: linodeInfo.id,
          label: linodeInfo.label,
          ip: ipAddress,
          ram,
          os,
          cpu,
          storage,
          status,
          createDate: formattedCreateDate
        };
      } else {
        const errorData = await response.json();
        throw new Error(`Gagal memeriksa detail Linode: ${errorData.errors[0].reason}`);
      }
    } catch (error) {
      throw new Error(`Terjadi kesalahan saat memeriksa detail Linode: ${error.message}`);
    }
  };

  getLinodeInfo(linodeId)
    .then((info) => {
      let textku = `*DETAIL VPS LINODE*\nLinode Id: ${info.linodeid}\nLabel: ${info.label}\nIP: ${info.ip}\nRAM: ${info.ram}\nOS: ${info.os}\nCPU: ${info.cpu}\nStorage: ${info.storage}\nStatus: ${info.status}\nCreate On: ${info.createDate}\n`;
      kayyoffc.sendMessage(m.chat, { text: textku });
    })
    .catch((err) => {
      reply(err);
      kayyoffc.sendMessage(m.chat, { text: 'Terjadi kesalahan saat memeriksa detail VPS Linode.' });
    });

  break;
}




case "linode2gb": {
  if (!isCreator) return reply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
  try {
    let linodeData = {
      label: `${args[0]}`,
      region: 'ap-south', // Ganti dengan region yang diinginkan
      type: 'g6-standard-1', // Spesifikasi 1GB RAM 1 Core CPU
      image: 'linode/ubuntu20.04', // Ganti dengan image yang diinginkan
      root_pass: generateRandomPassword(),
      stackscript_id: null,
      authorized_keys: null,
      backups_enabled: false
    };

    const response = await fetch('https://api.linode.com/v4/linode/instances', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${LINODE_API_TOKEN}`
      },
      body: JSON.stringify(linodeData)
    });

    const responseData = await response.json();

    if (response.ok) {
      const linodeId = responseData.id;

      // Menunggu hingga Linode selesai dibuat
      reply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang Linode
      const linodeResponse = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINODE_API_TOKEN}`
        }
      });

      const linodeInfo = await linodeResponse.json();
      const ipAddress = linodeInfo.ipv4[0]; // Alamat IP Linode

      let messageText = `Linode berhasil dibuat!\n\n`;
      messageText += `ID: ${linodeId}\n`;
      messageText += `IP Linode: ${ipAddress}\n`;
      messageText += `Password: ${linodeData.root_pass}\n`;

      await kayyoffc.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat Linode: ${responseData.errors[0].reason}`);
    }
  } catch (err) {
    console.error(err);
    reply(`Terjadi kesalahan saat membuat Linode: ${err}`);
  }
}
break;


 case "linode4gb": {
  if (!isCreator) return reply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
  try {
    let linodeData = {
      label: `${args[0]}`,
      region: 'ap-south', // Ganti dengan region yang diinginkan
      type: 'g6-standard-2', // Spesifikasi 2GB RAM 1 Core CPU
      image: 'linode/ubuntu20.04', // Ganti dengan image yang diinginkan
      root_pass: generateRandomPassword(),
      stackscript_id: null,
      authorized_keys: null,
      backups_enabled: false
    };

    const response = await fetch('https://api.linode.com/v4/linode/instances', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${LINODE_API_TOKEN}`
      },
      body: JSON.stringify(linodeData)
    });

    const responseData = await response.json();

    if (response.ok) {
      const linodeId = responseData.id;

      // Menunggu hingga Linode selesai dibuat
      reply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang Linode
      const linodeResponse = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINODE_API_TOKEN}`
        }
      });

      const linodeInfo = await linodeResponse.json();
      const ipAddress = linodeInfo.ipv4[0]; // Alamat IP Linode

      let messageText = `Linode berhasil dibuat!\n\n`;
      messageText += `ID: ${linodeId}\n`;
      messageText += `IP Linode: ${ipAddress}\n`;
      messageText += `Password: ${linodeData.root_pass}\n`;

      await kayyoffc.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat Linode: ${responseData.errors[0].reason}`);
    }
  } catch (err) {
    console.error(err);
    reply(`Terjadi kesalahan saat membuat Linode: ${err}`);
  }
}
break;


case "saldolinode":
  if (!isCreator) return reply(mess.owner);

  // Endpoint untuk mengambil informasi saldo promosi Linode
  const linodePromotionsEndpoint = 'https://api.linode.com/v4/profile';

  // Konfigurasi untuk melakukan permintaan ke API Linode
  const config = {
    headers: {
      'Authorization': `Bearer ${LINODE_API_TOKEN}`
    }
  };

  // Mengambil informasi saldo promosi dari Linode
  axios.get(linodePromotionsEndpoint, config)
    .then(response => {
      // Periksa apakah saldo promosi tersedia dalam respons
      if (response.data && Array.isArray(response.data.data)) {
        // Saldo promosi dapat ada dalam elemen pertama jika ada
        const saldoPromosi = response.data.data[0].balance;
        const teksSaldo = `Sisa Kredit Promosi Linode Dalam Akun Anda Adalah $${saldoPromosi}`;
        reply(teksSaldo);
      } else {
        reply('Informasi saldo promosi tidak ditemukan atau akun tidak memiliki saldo promosi.');
      }
    })
    .catch(error => {
      console.error(error);
      reply('Terjadi kesalahan saat mengambil informasi saldo promosi.');
    });

  break;





case "resetpassword": {
  if (!isCreator) return reply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
  let linodeId = args[0];
  let newPassword = args[1];

  if (!linodeId || !newPassword) {
    return reply("Format: !resetpassword [Linode ID] [New Password]");
  }

  // Periksa apakah kata sandi memenuhi persyaratan keamanan yang diharapkan
  if (newPassword.length < 8) {
    return reply("Kata sandi harus memiliki setidaknya 8 karakter.");
  }

  try {
    const resetPassword = async () => {
      try {
        const response = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}/password`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${LINODE_API_TOKEN}`
          },
          body: JSON.stringify({ root_pass: newPassword })
        });

        if (response.ok) {
          reply(`Kata sandi VPS Linode ID ${linodeId} berhasil direset.`);
        } else {
          const responseData = await response.json();
          throw new Error(`Gagal mereset kata sandi VPS Linode: ${responseData.errors[0].reason}`);
        }
      } catch (error) {
        reply(`Terjadi kesalahan saat mereset kata sandi VPS Linode: ${error}`);
      }
    };

    resetPassword();
  } catch (err) {
    console.error(err);
    reply(`Terjadi kesalahan saat mereset kata sandi VPS Linode: ${err}`);
  }
}
break;




    case 'listlinode': {
  if (!isCreator) return reply("Anda bukan pemilik.");

  try {
    const getLinodes = async () => {
      try {
        const response = await fetch('https://api.linode.com/v4/linode/instances', {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${LINODE_API_TOKEN}`
          }
        });
        const data = await response.json();
        return data.data || [];
      } catch (error) {
        reply('Error fetching Linodes: ' + error);
        return [];
      }
    };

    getLinodes().then(linodes => {
      let totalvps = linodes.length;
      let message = `List VPS Linode Anda: ${totalvps}\n\n▬▭▬▭▬▭▬▭▬▭▬▭▬\n`;

      if (linodes.length === 0) {
        message += 'Tidak ada VPS yang tersedia.';
      } else {
        linodes.forEach(linode => {
          message += `- Linode Id: ${linode.id}\n- Label: ${linode.label}\n- Region: ${linode.region}\n- IP: ${linode.ipv4[0]}\n- Ram: ${linode.specs.memory / 1024} GB\n- Cpu: ${linode.specs.vcpus} CPU\n- Status: ${linode.status}\n- Harga: $\n▬▬▭▬▭▬▭▬▭▬▭▬\n`;
        });
      }
      kayyoffc.sendMessage(m.chat, { text: message });
    });
  } catch (err) {
    reply('Terjadi kesalahan saat mengambil data Linode: ' + err);
  }

  break;
}


 case "offlinode": {
  if (!isCreator) return reply(`Sok Asik Anjg`);

  let linodeId = args[0];
  if (!linodeId) return reply('ID Linode belum diberikan.');

  async function turnOffLinode() {
    try {
      const response = await axios.post(
        `https://api.linode.com/v4/linode/instances/${linodeId}/shutdown`,
        {},
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${LINODE_API_TOKEN}`,
          },
        }
      );

      if (response.status === 200) {
        reply('VPS (Linode) sedang dimatikan...');
      } else {
        reply('Gagal mematikan VPS (Linode).');
      }
    } catch (error) {
      reply('Terjadi kesalahan saat mematikan VPS (Linode):', error.message);
    }
  }

  turnOffLinode();
  break;
}

case "onlinode": {
  if (!isCreator) return reply(`Sok Asik Anjg`);

  let linodeId = args[0];
  if (!linodeId) return reply('ID Linode belum diberikan.');

  async function turnOnLinode() {
    try {
      const response = await axios.post(
        `https://api.linode.com/v4/linode/instances/${linodeId}/boot`,
        {},
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${LINODE_API_TOKEN}`,
          },
        }
      );

      if (response.status === 200) {
        reply('VPS (Linode) sedang diaktifkan...');
      } else {
        reply('Gagal mengaktifkan VPS (Linode).');
      }
    } catch (error) {
      reply('Terjadi kesalahan saat mengaktifkan VPS (Linode):', error.message);
    }
  }

  turnOnLinode();
  break;
}
case "rebootlinode": {
  if (!isCreator) return reply(`Sok Asik Anjg`);

  let linodeId = args[0];
  if (!linodeId) return reply('ID Linode belum diberikan.');

  async function rebootLinode() {
    try {
      const response = await axios.post(
        `https://api.linode.com/v4/linode/instances/${linodeId}/reboot`,
        {},
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${LINODE_API_TOKEN}`,
          },
        }
      );

      if (response.status === 200) {
        reply('VPS (Linode) sedang direboot...');
      } else {
        reply('Gagal me-reboot VPS (Linode).');
      }
    } catch (error) {
      reply('Terjadi kesalahan saat me-reboot VPS (Linode):', error.message);
    }
  }

  rebootLinode();
  break;
}
//==================================================//
// DO
case "sisadroplet":{
if (!isCreator) return reply(`Ngapain Woi Tolol Yatim`)
async function getDropletInfo() {
  try {
    const accountResponse = await axios.get('https://api.digitalocean.com/v2/account', {
      headers: {
        Authorization: `Bearer ${API_TOKEN}`,
      },
    });

    const dropletsResponse = await axios.get('https://api.digitalocean.com/v2/droplets', {
      headers: {
        Authorization: `Bearer ${API_TOKEN}`,
      },
    });

    if (accountResponse.status === 200 && dropletsResponse.status === 200) {
      const dropletLimit = accountResponse.data.account.droplet_limit;
      const dropletsCount = dropletsResponse.data.droplets.length;
      const remainingDroplets = dropletLimit - dropletsCount;

      return {
        dropletLimit,
        remainingDroplets,
        totalDroplets: dropletsCount,
      };
    } else {
      throw new Error('Gagal mendapatkan data akun DigitalOcean atau droplet.');
    }
  } catch (error) {
    throw error;
  }
}

// Definisikan fungsi untuk mengeksekusi kasus "sisadroplet"
async function sisadropletHandler() {
  try {
    if (!isCreator) {
      return reply('Lu Siapanya Gua Anjg');
    }

    const dropletInfo = await getDropletInfo();
    reply(`*Sisa Droplet Yang Dapat Anda Pakai: ${dropletInfo.remainingDroplets}*

*Total Droplet Yang Sudah Terpakai: ${dropletInfo.totalDroplets}*`);
  } catch (error) {
    reply(`Terjadi kesalahan: ${error.message}`);
  }
}

  sisadropletHandler();
  break;
}
case "restartvps": {
    if (!isCreator) return reply(`Idih Yatim So Asik Kontol`)
  let dropletId = args[0];
  if (!dropletId) return reply('ID droplet belum diberikan.');

  // Fungsi untuk melakukan restart VPS berdasarkan ID droplet
  const restartVPS = async (dropletId) => {
    try {
      const apiUrl = `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`;

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${API_TOKEN}`
        },
        body: JSON.stringify({
          type: 'reboot'
        })
      });

      if (response.ok) {
        const data = await response.json();
        return data.action;
      } else {
        const errorData = await response.json();
        reply(`Gagal melakukan restart VPS: ${errorData.message}`);
      }
    } catch (error) {
      reply('Terjadi kesalahan saat melakukan restart VPS:', error.message);
      reply('Terjadi kesalahan saat melakukan restart VPS.');
    }
  };

  restartVPS(dropletId)
    .then((action) => {
      reply(`Aksi restart VPS berhasil dimulai. Status aksi: ${action.status}`);
    })
    .catch((err) => {
      reply(err);
    });

  break;
}
case "turnoff": {
  if (!isCreator) return reply(`Yatim Kontol Rese`);

  let dropletId = args[0];
  if (!dropletId) return reply('ID droplet belum diberikan.');

  async function turnOffDroplet() {
    try {
      const response = await axios.post(
        `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`,
        {
          type: 'power_off',
        },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${API_TOKEN}`,
          },
        }
      );

      if (response.status === 201 && response.data.action && response.data.action.status === 'in-progress') {
        reply('VPS (Droplet) sedang dimatikan...');
      } else {
        reply('Gagal mematikan VPS (Droplet).');
      }
    } catch (error) {
      reply('Terjadi kesalahan saat mematikan VPS (Droplet):', error.message);
    }
  }

  turnOffDroplet();
  break;
}


case "turnon": {
  if (!isCreator) return reply(`Sok Asik Anjg`);

  let dropletId = args[0];
  if (!dropletId) return reply('ID droplet belum diberikan.');

  async function turnOnDroplet() {
    try {
      const response = await axios.post(
        `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`,
        {
          type: 'power_on',
        },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${API_TOKEN}`,
          },
        }
      );

      if (response.status === 201 && response.data.action && response.data.action.status === 'in-progress') {
        reply('VPS (Droplet) sedang dihidupkan...');
      } else {
        reply('Gagal menghidupkan VPS (Droplet).');
      }
    } catch (error) {
      reply('Terjadi kesalahan saat menghidupkan VPS (Droplet):', error.message);
    }
  }

  turnOnDroplet();
  break;
}


case "rebuild": {
  if (!isCreator) return reply(`Lu Siapanya Gua Anjg Gausah Nyuruh Nyuruh Gua Yatim`);

  let dropletId = args[0];
  if (!dropletId) return reply('ID droplet belum diberikan.');

  let rebuildVPS = async () => {
    try {
      // Rebuild droplet menggunakan API DigitalOcean
      const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${API_TOKEN}`
        },
        body: JSON.stringify({
          type: 'rebuild',
          image: 'ubuntu-20-04-x64' // Ganti dengan slug image yang ingin digunakan untuk rebuild (misal: 'ubuntu-18-04-x64')
        })
      });

      if (response.ok) {
        const data = await response.json();
        reply('Rebuild VPS berhasil dimulai. Status aksi:', data.action.status);

        // Mendapatkan informasi VPS setelah rebuild
        const vpsInfo = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${API_TOKEN}`
          }
        });

        if (vpsInfo.ok) {
          const vpsData = await vpsInfo.json();
          const droplet = vpsData.droplet;
          const ipv4Addresses = droplet.networks.v4.filter(network => network.type === 'public');
          const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP';

          const textvps = `*VPS SUKSES REBUILD*\nIP VPS: ${ipAddress}\nSYSTEM IMAGE: ${droplet.image.slug}`;
          await sleep(60000) 
 kayyoffc.sendMessage(m.chat, { text: textvps });
        } else {
          reply('Gagal mendapatkan informasi VPS setelah rebuild.');
        }
      } else {
        const errorData = await response.json();
        reply('Gagal melakukan rebuild VPS:', errorData.message);
      }
    } catch (error) {
      reply('Terjadi kesalahan saat melakukan rebuild VPS:', error);
    }
  };

  rebuildVPS();
}
break;

        case "deldroplet": {
  if (!isCreator) return reply('Maaf, command ini hanya untuk pemilik.');

  let dropletId = args[0];
  if (!dropletId) return reply('ID droplet belum diberikan.');

  let deleteDroplet = async () => {
    try {
      let response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${API_TOKEN}`
        }
      });

      if (response.ok) {
        reply('Droplet berhasil dihapus.');
      } else {
        const errorData = await response.json();
        throw new Error(`Gagal menghapus droplet: ${errorData.message}`);
      }
    } catch (error) {
      console.error('Terjadi kesalahan saat menghapus droplet:', error);
      reply('Terjadi kesalahan saat menghapus droplet.');
    }
  };

  deleteDroplet();

  break;
}
case "listdroplet": {
  if (!isCreator) return reply("Anda bukan pemilik.");

  try {
    const getDroplets = async () => {
      try {
        const response = await fetch('https://api.digitalocean.com/v2/droplets', {
          headers: {
            Authorization: "Bearer " + API_TOKEN
          }
        });
        const data = await response.json();
        return data.droplets || [];
      } catch (error) {
        reply('Error fetching droplets: ' + error);
        return [];
      }
    };

    getDroplets().then(droplets => {
      let totalvps = droplets.length;
      let mesej = `List Droplet Digital Ocean Anda: ${totalvps}\n\n▬▭▬▭▬▭▬▭▬▭▬▭▬\n`;

      if (droplets.length === 0) {
        mesej += 'Tidak ada Droplet yang tersedia.';
      } else {
        droplets.forEach(droplet => {
          const ipv4Addresses = droplet.networks.v4.filter(network => network.type === "public");
          const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP';
          mesej += `- Droplet Id: ${droplet.id}\n- Hostname: ${droplet.name}\n- Username Login: root\n- IP: ${ipAddress}\n- Ram: ${droplet.memory} MB\n- Cpu: ${droplet.vcpus} CPU\n- OS: ${droplet.image.distribution}\n- Storage: ${droplet.disk} GB\n- Status: ${droplet.status}\n▬▭▬▭▬▭▬▭▬▭▬▭▬\n`;
        });
      }
      kayyoffc.sendMessage(m.chat, { text: mesej });
    });
  } catch (err) {
    reply('Terjadi kesalahan saat mengambil data droplet: ' + err);
  }

  break;
}

 case "cekdroplet": {
  if (!isCreator) return reply(`Ngapain? Kepo Amat Dah`);

  let dropletId = args[0];
  if (!dropletId) return reply('ID droplet belum diberikan.');

  // Mendapatkan informasi droplet (VPS) berdasarkan ID
  const getDropletInfo = async (dropletId) => {
    try {
      const apiUrl = `https://api.digitalocean.com/v2/droplets/${dropletId}`;
      const response = await fetch(apiUrl, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${API_TOKEN}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        const droplet = data.droplet;
        const ipv4Addresses = droplet.networks.v4.filter(network => network.type === 'public');
        const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP';
        const vpsRam = droplet.memory / 1024;

        return {
          dropletid: droplet.id,
          username: droplet.name,
          ip: ipAddress,
          ram: `${vpsRam} GB`,
          os: droplet.image.distribution,
          cpu: droplet.vcpus > 1 ? `${droplet.vcpus} vCPU` : `${droplet.vcpus} vCPUs`,
          storage: droplet.disk,
          status: droplet.status // Menambahkan status VPS
        };
      } else {
        const errorData = await response.json();
        throw new Error(`Gagal memeriksa detail droplet: ${errorData.message}`);
      }
    } catch (error) {
      reply('Terjadi kesalahan saat memeriksa detail droplet:', error.message);
      throw new Error('Terjadi kesalahan saat memeriksa detail droplet.');
    }
  };

  getDropletInfo(dropletId)
    .then((info) => {
      let textku = `*DETAIL VPS ANDA*\nDroplet Id: ${info.dropletid}\nHostname: ${info.username}\nIpv4 : ${info.ip}\nRam : ${info.ram}\nOS : ${info.os}\nCPU: ${info.cpu}\nStorage: ${info.storage}\nStatus : ${info.status}`;
      kayyoffc.sendMessage(m.chat, { text: textku });
    })
    .catch((err) => {
      reply(err);
      kayyoffc.sendMessage(m.chat, { text: 'Terjadi kesalahan saat memeriksa detail VPS.' });
    });

  break;
}


    case "vps1g1c": {
  if (!isCreator) return reply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
    let hostname = args[0];
  if (!hostname) return reply('Masukan Hostname Vps.');

  try {
    let dropletData = {
      name: hostname,
      region: 'sgp1',
      size: 's-1vcpu-1gb',
      image: 'ubuntu-20-04-x64',
      ssh_keys: null,
      backups: false,
      ipv6: true,
      user_data: null,
      private_networking: null,
      volumes: null,
      tags: ['T']
    };

    let password = generateRandomPassword();
    dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': "Bearer " + API_TOKEN
      },
      body: JSON.stringify(dropletData)
    });

    let responseData = await response.json();

    if (response.ok) {
      let dropletConfig = responseData.droplet;
      let dropletId = dropletConfig.id;

      // Menunggu hingga VPS selesai dibuat
      reply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang VPS
      let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': "Bearer " + API_TOKEN
        }
      });

      let dropletData = await dropletResponse.json();
      // Memeriksa apakah ada alamat IP VPS yang tersedia
      let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 ? dropletData.droplet.networks.v4[0].ip_address : "Tidak ada alamat IP yang tersedia";

      let messageText = `VPS berhasil dibuat!\n\n`;

      messageText += `ID: ${dropletId}\n`;
      messageText += `IP VPS: ${ipVPS}\n`;
      messageText += `Password: ${password}\n`;

      await kayyoffc.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat VPS: ${responseData.message}`);
    }
  } catch (err) {
    console.error(err);
    reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
  }}
break

    case "vps2g1c": {
  if (!isCreator) return reply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
    let hostname = args[0];
  if (!hostname) return reply('Masukan Hostname Vps.');

  try {
    let dropletData = {
      name: hostname,
      region: 'sgp1',
      size: 's-1vcpu-2gb',
      image: 'ubuntu-20-04-x64',
      ssh_keys: null,
      backups: false,
      ipv6: true,
      user_data: null,
      private_networking: null,
      volumes: null,
      tags: ['T']
    };

    let password = generateRandomPassword();
    dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': "Bearer " + API_TOKEN
      },
      body: JSON.stringify(dropletData)
    });

    let responseData = await response.json();

    if (response.ok) {
      let dropletConfig = responseData.droplet;
      let dropletId = dropletConfig.id;

      // Menunggu hingga VPS selesai dibuat
      reply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang VPS
      let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': "Bearer " + API_TOKEN
        }
      });

      let dropletData = await dropletResponse.json();
      // Memeriksa apakah ada alamat IP VPS yang tersedia
      let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 ? dropletData.droplet.networks.v4[0].ip_address : "Tidak ada alamat IP yang tersedia";

      let messageText = `VPS berhasil dibuat!\n\n`;

      messageText += `ID: ${dropletId}\n`;
      messageText += `IP VPS: ${ipVPS}\n`;
      messageText += `Password: ${password}\n`;

      await kayyoffc.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat VPS: ${responseData.message}`);
    }
  } catch (err) {
    console.error(err);
    reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
  }}
break  

    case "vps2g2c": {
  if (!isCreator) return reply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
    let hostname = args[0];
  if (!hostname) return reply('Masukan Hostname Vps.');

  try {
    let dropletData = {
      name: hostname,
      region: 'sgp1',
      size: 's-2vcpu-2gb',
      image: 'ubuntu-20-04-x64',
      ssh_keys: null,
      backups: false,
      ipv6: true,
      user_data: null,
      private_networking: null,
      volumes: null,
      tags: ['T']
    };

    let password = generateRandomPassword();
    dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': "Bearer " + API_TOKEN
      },
      body: JSON.stringify(dropletData)
    });

    let responseData = await response.json();

    if (response.ok) {
      let dropletConfig = responseData.droplet;
      let dropletId = dropletConfig.id;

      // Menunggu hingga VPS selesai dibuat
      reply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang VPS
      let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': "Bearer " + API_TOKEN
        }
      });

      let dropletData = await dropletResponse.json();
      // Memeriksa apakah ada alamat IP VPS yang tersedia
      let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 ? dropletData.droplet.networks.v4[0].ip_address : "Tidak ada alamat IP yang tersedia";

      let messageText = `VPS berhasil dibuat!\n\n`;

      messageText += `ID: ${dropletId}\n`;
      messageText += `IP VPS: ${ipVPS}\n`;
      messageText += `Password: ${password}\n`;

      await kayyoffc.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat VPS: ${responseData.message}`);
    }
  } catch (err) {
    console.error(err);
    reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
  }}
break      
    case "vps4g2c": {
  if (!isCreator) return reply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
    let hostname = args[0];
  if (!hostname) return reply('Masukan Hostname Vps.');

  try {
    let dropletData = {
      name: hostname,
      region: 'sgp1',
      size: 's-2vcpu-4gb',
      image: 'ubuntu-20-04-x64',
      ssh_keys: null,
      backups: false,
      ipv6: true,
      user_data: null,
      private_networking: null,
      volumes: null,
      tags: ['T']
    };

    let password = generateRandomPassword();
    dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': "Bearer " + API_TOKEN
      },
      body: JSON.stringify(dropletData)
    });

    let responseData = await response.json();

    if (response.ok) {
      let dropletConfig = responseData.droplet;
      let dropletId = dropletConfig.id;

      // Menunggu hingga VPS selesai dibuat
      reply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang VPS
      let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': "Bearer " + API_TOKEN
        }
      });

      let dropletData = await dropletResponse.json();
      // Memeriksa apakah ada alamat IP VPS yang tersedia
      let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 ? dropletData.droplet.networks.v4[0].ip_address : "Tidak ada alamat IP yang tersedia";

      let messageText = `VPS berhasil dibuat!\n\n`;

      messageText += `ID: ${dropletId}\n`;
      messageText += `IP VPS: ${ipVPS}\n`;
      messageText += `Password: ${password}\n`;

      await kayyoffc.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat VPS: ${responseData.message}`);
    }
  } catch (err) {
    console.error(err);
    reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
  }}
break        
     case "vps8g4c": {
  if (!isCreator) return reply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
    let hostname = args[0];
  if (!hostname) return reply('Masukan Hostname Vps.');

  try {
    let dropletData = {
      name: hostname,
      region: 'sgp1',
      size: 's-4vcpu-8gb',
      image: 'ubuntu-20-04-x64',
      ssh_keys: null,
      backups: false,
      ipv6: true,
      user_data: null,
      private_networking: null,
      volumes: null,
      tags: ['T']
    };

    let password = generateRandomPassword();
    dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': "Bearer " + API_TOKEN
      },
      body: JSON.stringify(dropletData)
    });

    let responseData = await response.json();

    if (response.ok) {
      let dropletConfig = responseData.droplet;
      let dropletId = dropletConfig.id;

      // Menunggu hingga VPS selesai dibuat
      reply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang VPS
      let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': "Bearer " + API_TOKEN
        }
      });

      let dropletData = await dropletResponse.json();
      // Memeriksa apakah ada alamat IP VPS yang tersedia
      let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 ? dropletData.droplet.networks.v4[0].ip_address : "Tidak ada alamat IP yang tersedia";

      let messageText = `VPS berhasil dibuat!\n\n`;

      messageText += `ID: ${dropletId}\n`;
      messageText += `IP VPS: ${ipVPS}\n`;
      messageText += `Password: ${password}\n`;

      await kayyoffc.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat VPS: ${responseData.message}`);
    }
  } catch (err) {
    console.error(err);
    reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
  }}
break
case 'svps': case 'sendvps': {
     if (!isCreator) return (`Ngapain Pea`)
          if (!text) return reply(`Example : ${prefix + command} 6285xxxxx,ip,ram,harga,passwordvps`)
            reply('Pesanan Telah Sukses Dikirim') 
            var mon = args.join(' ')
            var m1 = mon.split(",")[0]
            var m2 = mon.split(",")[1]
            var m3 = mon.split(",")[2]
            var m4 = mon.split(",")[3]
            var m5 = mon.split(",")[4]
                    let mq1 = m1 + '@s.whatsapp.net'
                  let ownernya = owner + '@s.whatsapp.net'
               let me = m.sender
               let ments = [mq1, ownernya, me]
kayyoffc.sendMessage(mq1, {text:`*───❖》kayy Offcial《❖───*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n*📦 Pesananmu Datang 📦*\n*Harga : ${m4}*\n*Hari : ${hariini}*\n*Tanggal : ${tanggal2}*\n*Jam : ${time}*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n*[+] Ip : ${m2}*\n*[+] Username : root*\n*[+] Password : ${m5}*\n*[+] Ram : ${m3}*\n\n*───《TOS VPS》───*\n\n*-JANGAN SAMPAI TERKENA DDOS*\n*-JANGAN GUNAKAN UNTUK DDOS*\n*-JANGAN GUNAKAN UNTUK MINING*\n*-CPU JANGAN SAMPAI 100%*\n*-MELANGGAR RULES? GARANSI ANGUS*\n*-PANEL SUS NO REFF*`}, m) 
                 }
            break
//=================D O M A I N=======================//
case 'addgc':

    if (!m.isGroup) return reply(mess.group)         

if (!isCreator) return reply(`khusus Creator`)

ntilink.push(m.chat)
        fs.writeFileSync('./database/idgroup.json', JSON.stringify(ntilink))

reply(`${command} sukses`)

           break
case 'delgc':

  if (!isCreator) return reply(`khusus Creator`)

    if (!m.isGroup) return reply(mess.group)

var ini = ntilink.indexOf(m.chat)

ntilink.splice(ini, 1)

fs.writeFileSync('./database/idgruop.json', JSON.stringify(ntilink))

reply(`${command} sukses`)

break

case 'domain1': {
    if (!jangan) return reply("Fitur Ini Khusus Untuk Reseller Subdomain Kayy Offc\nMau Join? Cuman 5.000 Ajaa\n\nHubungi Wa.me/6285963142450")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "ec4430e647897d90930cbb9085dbba06";
               let apitoken = "5rBaTXV30xYNXTVbeB6okU6-61R04HN1lkZNxghp-dpwXqvg_n9HWq_jV4fzL";
               let tld = "celiaofficial.my.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }

           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");

           subDomain1(host1, ip1).then((e) => {
             if (e[mess.success]) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By Kayy Offc⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }

           break
case 'domain2': {
    if (!jangan) return reply("Fitur Ini Khusus Untuk Reseller Subdomain kayy Offc\nMau Join? Cuman 5.000 Ajaa\n\nHubungi Wa.me/6285963142450")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "0eb97a28633fbb51b17a32d6fe52dcaf";
               let apitoken = "5rBaTXV30xYNXTVbeB6okU6-61R04HN1lkZNxghp";
               let tld = "celiastore.my.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }

           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");

           subDomain1(host1, ip1).then((e) => {
                          if (e[mess.success]) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By Kayy Offc⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
case 'domain3': {
    if (!jangan) return reply("Fitur Ini Khusus Untuk Reseller Subdomain Kayy Offc\nMau Join? Cuman 5.000 Ajaa\n\nHubungi Wa.me/6285963142450")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "5ac16dadc6a80d53657786f70c509a92";
               let apitoken = "5rBaTXV30xYNXTVbeB6okU6-61R04HN1lkZNxghp";
               let tld = "panellofficial.site";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }

           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");

           subDomain1(host1, ip1).then((e) => {
                          if (e[mess.success]) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By Kayy Offc⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
case 'domain4': {
    if (!jangan) return reply("Fitur Ini Khusus Untuk Reseller Subdomain Kayy Offc\nMau Join? Cuman 5.000 Ajaa\n\nHubungi Wa.me/6285963142450")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "f2bc5ee0d4471aa74dd689c297c7aa43";
               let apitoken = "5rBaTXV30xYNXTVbeB6okU6-61R04HN1lkZNxghp";
               let tld = "panellofficial.my.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }

           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");

           subDomain1(host1, ip1).then((e) => {
                          if (e[mess.success]) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By Kayy Offc⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
case 'domain5': {
    if (!jangan) return reply("Fitur Ini Khusus Untuk Reseller Subdomain Kayy Offc\nMau Join? Cuman 5.000 Ajaa\n\nHubungi Wa.me/6285963142450")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "57671edad3d50d309860d91d25385e05";
               let apitoken = "5rBaTXV30xYNXTVbeB6okU6-61R04HN1lkZNxghp";
               let tld = "celiapanellstore.my.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }

           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");

           subDomain1(host1, ip1).then((e) => {
                          if (e[mess.success]) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By Kayy Offc⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
case 'domain6': {
    if (!jangan) return reply("Fitur Ini Khusus Untuk Reseller Subdomain Kayy Offc\nMau Join? Cuman 5.000 Ajaa\n\nHubungi Wa.me/6285963142450")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "034a5ceff63666337614606715f16e36";
               let apitoken = "KGhjPqE6foR70mzTnrd4X1DSopNBVtMJJSudc6wi";
               let tld = "kayy.me";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }

           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");

           subDomain1(host1, ip1).then((e) => {
                          if (e[mess.success]) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By Kayy Offc⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }

        break
case 'domain7': {
    if (!jangan) return reply("Fitur Ini Khusus Untuk Reseller Subdomain Kayy Offc\nMau Join? Cuman 5.000 Ajaa\n\nHubungi Wa.me/6285963142450")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "144f7c48ca035135390fe5adb49d642f";
               let apitoken = "KGhjPqE6foR70mzTnrd4X1DSopNBVtMJJSudc6wi";
               let tld = "kayyoffc.tech";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }

           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");

           subDomain1(host1, ip1).then((e) => {
                          if (e[mess.success]) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By Kayy Offc⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
case 'domain8': {
    if (!jangan) return reply("Fitur Ini Khusus Untuk Reseller Subdomain Kayy Offc\nMau Join? Cuman 5.000 Ajaa\n\nHubungi Wa.me/6285963142450")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "4fc8192dd8160307100b207d308da80c";
               let apitoken = "KGhjPqE6foR70mzTnrd4X1DSopNBVtMJJSudc6wi";
               let tld = "kayypedia.com";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }

           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");

           subDomain1(host1, ip1).then((e) => {
                          if (e[mess.success]) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By Kayy Offc⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
case 'domain9': {
    if (!jangan) return reply("Fitur Ini Khusus Untuk Reseller Subdomain Kayy Offc\nMau Join? Cuman 5.000 Ajaa\n\nHubungi Wa.me/6285963142450")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "a1fa0ffcde9549bd36e9ae3de4b66b4a";
               let apitoken = "KGhjPqE6foR70mzTnrd4X1DSopNBVtMJJSudc6wi";
               let tld = "panell.icu";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }

           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");

           subDomain1(host1, ip1).then((e) => {
                          if (e[mess.success]) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By Kayy Offc⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
case 'domain10': {
    if (!jangan) return reply("Fitur Ini Khusus Untuk Reseller Subdomain Kayy Offc\nMau Join? Cuman 5.000 Ajaa\n\nHubungi Wa.me/6285963142450")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "a112599ddfdd5a2bac5dc91864020015";
               let apitoken = "KGhjPqE6foR70mzTnrd4X1DSopNBVtMJJSudc6wi";
               let tld = "panellstoree.com";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }

           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");

           subDomain1(host1, ip1).then((e) => {
                          if (e[mess.success]) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By Kayy Offc⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
// game
         case 'wwpc':
case 'ww':
case 'werewolf': {
let jimp = require("jimp")
const resize = async (image, width, height) => {
    const read = await jimp.read(image);
    const data = await read.resize(width, height).getBufferAsync(jimp.MIME_JPEG);
    return data;
};

let {
    emoji_role,
    sesi,
    playerOnGame,
    playerOnRoom,
    playerExit,
    dataPlayer,
    dataPlayerById,
    getPlayerById,
    getPlayerById2,
    killWerewolf,
    killww,
    dreamySeer,
    sorcerer,
    protectGuardian,
    roleShuffle,
    roleChanger,
    roleAmount,
    roleGenerator,
    addTimer,
    startGame,
    playerHidup,
    playerMati,
    vote,
    voteResult,
    clearAllVote,
    getWinner,
    win,
    pagi,
    malam,
    skill,
    voteStart,
    voteDone,
    voting,
    run,
    run_vote,
    run_malam,
    runprefixagi
} = require('./lib/werewolf.js')

// [ Thumbnail ] 
let thumb =
    "https://user-images.githubusercontent.com/72728486/235316834-f9f84ba0-8df3-4444-81d8-db5270995e6d.jpg";

    const {
        sender,
        chat
    } = m;
    kayyoffc.werewolf = kayyoffc.werewolf ? kayyoffc.werewolf : {};
    const ww = kayyoffc.werewolf ? kayyoffc.werewolf : {};
    const data = ww[chat];
    const value = args[0];
    const target = args[1];
let byId = getPlayerById2(sender, parseInt(target), ww); 
    // [ Membuat Room ]
    if (value === "create") {
        if (chat in ww) return m.reply("Group masih dalam sesi permainan");
        if (playerOnGame(sender, ww) === true)
            return m.reply("Kamu masih dalam sesi game");
        ww[chat] = {
            room: chat,
            owner: sender,
            status: false,
            iswin: null,
            cooldown: null,
            day: 0,
            time: "malem",
            player: [],
            dead: [],
            voting: false,
            seer: false,
            guardian: [],
        };
        await m.reply("Room berhasil dibuat, ketik *.ww join* untuk bergabung");

        // [ Join sesi permainan ]
    } else if (value === "join") {
        if (!ww[chat]) return m.reply("Belum ada sesi permainan");
        if (ww[chat].status === true)
            return m.reply("Sesi permainan sudah dimulai");
        if (ww[chat].player.length > 16)
            return m.reply("Maaf jumlah player telah penuh");
        if (playerOnRoom(sender, chat, ww) === true)
            return m.reply("Kamu sudah join dalam room ini");
        if (playerOnGame(sender, ww) === true)
            return m.reply("Kamu masih dalam sesi game");
        let data = {
            id: sender,
            number: ww[chat].player.length + 1,
            sesi: chat,
            status: false,
            role: false,
            effect: [],
            vote: 0,
            isdead: false,
            isvote: false,
        };
        ww[chat].player.push(data);
        let player = [];
        let text = `\n*⌂ W E R E W O L F - P L A Y E R*\n\n`;
        for (let i = 0; i < ww[chat].player.length; i++) {
            text += `${ww[chat].player[i].number}) @${ww[chat].player[i].id.replace(
          "@s.whatsapp.net",
          ""
        )}\n`;
            player.push(ww[chat].player[i].id);
        }
        text += "\nJumlah player minimal adalah 5 dan maximal 15";
        kayyoffc.sendMessage(
            m.chat, {
                text: text.trim(),
                contextInfo: {
                    externalAdReply: {
                        title: "W E R E W O L F",
                        mediaType: 1,
                        renderLargerThumbnail: true,
                        thumbnail: await resize(thumb, 300, 175),
                        sourceUrl: websitex,
                        mediaUrl: thumb,
                    },
                    mentionedJid: player,
                },
            }, {
                quoted: m
            }
        );

        // [ Game Play ]
    } else if (value === "start") {
        if (!ww[chat]) return m.reply("Belum ada sesi permainan");
        if (ww[chat].player.length === 0)
            return m.reply("Room belum memiliki player");
        if (ww[chat].player.length < 5)
            return m.reply("Maaf jumlah player belum memenuhi syarat");
        if (playerOnRoom(sender, chat, ww) === false)
            return m.reply("Kamu belum join dalam room ini");
        if (ww[chat].cooldown > 0) {
            if (ww[chat].time === "voting") {
                clearAllVote(chat, ww);
                addTimer(chat, ww);
                return await run_vote(kayyoffc. chat, ww);
            } else if (ww[chat].time === "malem") {
                clearAllVote(chat, ww);
                addTimer(chat, ww);
                return await run_malam(kayyoffc. chat, ww);
            } else if (ww[chat].time === "pagi") {
                clearAllVote(chat, ww);
                addTimer(chat, ww);
                return await runprefixagi(kayyoffc. chat, ww);
            }
        }
        if (ww[chat].status === true)
            return m.reply("Sesi permainan telah dimulai");
        if (ww[chat].owner !== sender)
            return m.reply(
                `Hanya @${ww[chat].owner.split("@")[0]} yang dapat memulai permainan`
            );
        let list1 = "";
        let list2 = "";
        let player = [];
        roleGenerator(chat, ww);
        addTimer(chat, ww);
        startGame(chat, ww);
        for (let i = 0; i < ww[chat].player.length; i++) {
            list1 += `(${ww[chat].player[i].number}) @${ww[chat].player[
          i
        ].id.replace("@s.whatsapp.net", "")}\n`;
            player.push(ww[chat].player[i].id);
        }
        for (let i = 0; i < ww[chat].player.length; i++) {
            list2 += `(${ww[chat].player[i].number}) @${ww[chat].player[
          i
        ].id.replace("@s.whatsapp.net", "")} ${
          ww[chat].player[i].role === "werewolf" ||
          ww[chat].player[i].role === "sorcerer"
            ? `[${ww[chat].player[i].role}]`
            : ""
        }\n`;
            player.push(ww[chat].player[i].id);
        }
        for (let i = 0; i < ww[chat].player.length; i++) {
            // [ Werewolf ]
            if (ww[chat].player[i].role === "werewolf") {
                if (ww[chat].player[i].isdead != true) {
                    var textt = `Hai ${kayyoffc.getName(
              ww[chat].player[i].id
            )}, Kamu telah dipilih untuk memerankan *Werewolf* ${emoji_role(
              "werewolf"
            )} pada permainan kali ini, silahkan pilih salah satu player yang ingin kamu makan pada malam hari ini\n*LIST PLAYER*:\n${list2}\n\nKetik *.wwpc kill nomor* untuk membunuh player`;
                    await kayyoffc.sendMessage(ww[chat].player[i].id, {
                        text: textt,
                        mentions: player,
                    });
                }
                        // [ villager ]
            } else if (ww[chat].player[i].role === "warga") {
                if (ww[chat].player[i].isdead != true) {
                    let texttt = `*⌂ W E R E W O L F - G A M E*\n\nHai ${kayyoffc.getName(
              ww[chat].player[i].id
            )} Peran kamu adalah *Warga Desa* ${emoji_role(
              "warga"
            )}, tetap waspada, mungkin *Werewolf* akan memakanmu malam ini, silakan masuk kerumah masing masing.\n*LIST PLAYER*:\n${list1}`;
                    await kayyoffc.sendMessage(ww[chat].player[i].id, {
                        text: texttt,
                        mentions: player,
                    });
                }

                // [ Penerawangan ]
            } else if (ww[chat].player[i].role === "seer") {
                if (ww[chat].player[i].isdead != true) {
                    let texxt = `Hai ${kayyoffc.getName(
              ww[chat].player[i].id
            )} Kamu telah terpilih  untuk menjadi *Penerawang* ${emoji_role(
              "seer"
            )}. Dengan sihir yang kamu punya, kamu bisa mengetahui peran pemain pilihanmu.\n*LIST PLAYER*:\n${list1}\n\nKetik *.wwpc dreamy nomor* untuk melihat role player`;

                    await kayyoffc.sendMessage(ww[chat].player[i].id, {
                        text: texxt,
                        mentions: player,
                    });
                }

                // [ Guardian ]
            } else if (ww[chat].player[i].role === "guardian") {
                if (ww[chat].player[i].isdead != true) {
                    let teext = `Hai ${kayyoffc.getName(
              ww[chat].player[i].id
            )} Kamu terpilih untuk memerankan *Malaikat Pelindung* ${emoji_role(
              "guardian"
            )}, dengan kekuatan yang kamu miliki, kamu bisa melindungi para warga, silahkan pilih salah 1 player yang ingin kamu lindungi\n*LIST PLAYER*:\n${list1}\n\nKetik *.wwpc deff nomor* untuk melindungi player`;
  
                    await kayyoffc.sendMessage(ww[chat].player[i].id, {
                        text: teext,
                        mentions: player,
                    });
                }

                // [ Sorcerer ]
            } else if (ww[chat].player[i].role === "sorcerer") {
                if (ww[chat].player[i].isdead != true) {
                    let textu = `Hai ${kayyoffc.getName(
              ww[chat].player[i].id
            )} Kamu terpilih sebagai Penyihir ${emoji_role(
              "sorcerer"
            )}, dengan kekuasaan yang kamu punya, kamu bisa membuka identitas para player, silakan pilih 1 orang yang ingin kamu buka identitasnya\n*LIST PLAYER*:\n${list2}\n\nKetik *.wwpc sorcerer nomor* untuk melihat role player`;

                    await kayyoffc.sendMessage(ww[chat].player[i].id, {
                        text: textu,
                        mentions: player,
                    });
                }
            }
        }
        await kayyoffc.sendMessage(m.chat, {
            text: "*⌂ W E R E W O L F - G A M E*\n\nGame telah dimulai, para player akan memerankan perannya masing masing, silahkan cek chat pribadi untuk melihat role kalian. Berhati-hatilah para warga, mungkin malam ini adalah malah terakhir untukmu",
            contextInfo: {
                externalAdReply: {
                    title: "W E R E W O L F",
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    thumbnail: await resize(thumb, 300, 175),
                    sourceUrl: websitex,
                    mediaUrl: thumb,
                },
                mentionedJid: player,
            },
        });
        await run(kayyoffc. chat, ww);
    } else      if (value === "kill") { 
         if (dataPlayer(sender, ww).role !== "werewolf") 
             return m.reply("Peran ini bukan untuk kamu"); 
         if (byId.db.role === "sorcerer") 
             return m.reply("Tidak bisa menggunakan skill untuk teman"); 
                  if (playerOnGame(sender, ww) === false)
        return m.reply("Kamu tidak dalam sesi game")
    if (dataPlayer(sender, ww).status === true)
        return m.reply("Skill telah digunakan, skill hanya bisa digunakan sekali setiap malam")
    if (dataPlayer(sender, ww).isdead === true)
        return m.reply("Kamu sudah mati")
    if (!target || target.length < 1 || target.split('').length > 2) 
        return m.reply(`Masukan nomor player \nContoh : \n${prefix + command} kill 1`)
    if (isNaN(target)) 
        return m.reply("Gunakan hanya nomor")
    let byId = getPlayerById2(sender, parseInt(target), ww)
    if (byId.db.isdead === true) 
        return m.reply("Player sudah mati")
    if (byId.db.id === sender)
        return m.reply("Tidak bisa menggunakan skill untuk diri sendiri")
    if (byId === false) 
        return m.reply("Player tidak terdaftar")
      m.reply("Berhasil membunuh player " + parseInt(target)) 
             .then(() => { 
                 dataPlayer(sender, ww).status = true; 
                 killWerewolf(sender, parseInt(target), ww); 
             }); 
     } else if (value === "dreamy") { 
         if (dataPlayer(sender, ww).role !== "seer") 
             return m.reply("Peran ini bukan untuk kamu"); 
                  if (playerOnGame(sender, ww) === false)
        return m.reply("Kamu tidak dalam sesi game")
    if (dataPlayer(sender, ww).status === true)
        return m.reply("Skill telah digunakan, skill hanya bisa digunakan sekali setiap malam")
    if (dataPlayer(sender, ww).isdead === true)
        return m.reply("Kamu sudah mati")
    if (!target || target.length < 1 || target.split('').length > 2) 
        return m.reply(`Masukan nomor player \nContoh : \n${prefix + command} kill 1`)
    if (isNaN(target)) 
        return m.reply("Gunakan hanya nomor")
    let byId = getPlayerById2(sender, parseInt(target), ww)
    if (byId.db.isdead === true) 
        return m.reply("Player sudah mati")
    if (byId.db.id === sender)
        return m.reply("Tidak bisa menggunakan skill untuk diri sendiri")
    if (byId === false) 
        return m.reply("Player tidak terdaftar")
         let dreamy = dreamySeer(m.sender, parseInt(target), ww); 
         m.reply(`Berhasil membuka identitas player ${target} adalah ${dreamy}`) 
             .then(() => { 
                 dataPlayer(sender, ww).status = true; 
             }); 
     } else if (value === "deff") { 
         if (dataPlayer(sender, ww).role !== "guardian") 
             return m.reply("Peran ini bukan untuk kamu"); 
                  if (playerOnGame(sender, ww) === false)
        return m.reply("Kamu tidak dalam sesi game")
    if (dataPlayer(sender, ww).status === true)
        return m.reply("Skill telah digunakan, skill hanya bisa digunakan sekali setiap malam")
    if (dataPlayer(sender, ww).isdead === true)
        return m.reply("Kamu sudah mati")
    if (!target || target.length < 1 || target.split('').length > 2) 
        return m.reply(`Masukan nomor player \nContoh : \n${prefix + command} kill 1`)
    if (isNaN(target)) 
        return m.reply("Gunakan hanya nomor")
    let byId = getPlayerById2(sender, parseInt(target), ww)
    if (byId.db.isdead === true) 
        return m.reply("Player sudah mati")
    if (byId.db.id === sender)
        return m.reply("Tidak bisa menggunakan skill untuk diri sendiri")
    if (byId === false) 
        return m.reply("Player tidak terdaftar")
         m.reply(`Berhasil melindungi player ${target}`).then(() => { 
             protectGuardian(m.sender, parseInt(target), ww); 
             dataPlayer(sender, ww).status = true; 
         }); 
     } else if (value === "sorcerer") { 
         if (dataPlayer(sender, ww).role !== "sorcerer") 
             return m.reply("Peran ini bukan untuk kamu"); 
             if (playerOnGame(sender, ww) === false)
        return m.reply("Kamu tidak dalam sesi game")
    if (dataPlayer(sender, ww).status === true)
        return m.reply("Skill telah digunakan, skill hanya bisa digunakan sekali setiap malam")
    if (dataPlayer(sender, ww).isdead === true)
        return m.reply("Kamu sudah mati")
    if (!target || target.length < 1 || target.split('').length > 2) 
        return m.reply(`Masukan nomor player \nContoh : \n${prefix + command} kill 1`)
    if (isNaN(target)) 
        return m.reply("Gunakan hanya nomor")
    let byId = getPlayerById2(sender, parseInt(target), ww)
    if (byId.db.isdead === true) 
        return m.reply("Player sudah mati")
    if (byId.db.id === sender)
        return m.reply("Tidak bisa menggunakan skill untuk diri sendiri")
    if (byId === false) 
        return m.reply("Player tidak terdaftar")
         let sorker = sorcerer(sesi(m.sender), target); 
          m.reply(`Berhasil membuka identitas player ${player} adalah ${sorker}`) 
             .then(() => { 
                 dataPlayer(sender, ww).status = true; 
             }); 
     } else if (value === "vote") {
        if (!ww[chat]) return m.reply("Belum ada sesi permainan");
        if (ww[chat].status === false)
            return m.reply("Sesi permainan belum dimulai");
        if (ww[chat].time !== "voting")
            return m.reply("Sesi voting belum dimulai");
        if (playerOnRoom(sender, chat, ww) === false)
            return m.reply("Kamu bukan player");
        if (dataPlayer(sender, ww).isdead === true)
            return m.reply("Kamu sudah mati");
        if (!target || target.length < 1)
            return m.reply("Masukan nomor player");
        if (isNaN(target)) return m.reply("Gunakan hanya nomor");
        if (dataPlayer(sender, ww).isvote === true)
            return m.reply("Kamu sudah melakukan voting");
        b = getPlayerById(chat, sender, parseInt(target), ww);
        if (b.db.isdead === true)
            return m.reply(`Player ${target} sudah mati.`);
        if (ww[chat].player.length < parseInt(target))
            return m.reply("Invalid");
        if (getPlayerById(chat, sender, parseInt(target), ww) === false)
            return m.reply("Player tidak terdaftar!");
        vote(chat, parseInt(target), sender, ww);
        return m.reply("✅ Vote");
    } else if (value == "exit") {
        if (!ww[chat]) return m.reply("Tidak ada sesi permainan");
        if (playerOnRoom(sender, chat, ww) === false)
            return m.reply("Kamu tidak dalam sesi permainan");
        if (ww[chat].status === true)
            return m.reply("Permainan sudah dimulai, kamu tidak bisa keluar");
        let exitww = `${sender.split("@")[0]} Keluar dari permainan`
                kayyoffc.sendMessage(
            m.chat, {
                text: exitww,
                contextInfo: {
                    externalAdReply: {
                        title: "W E R E W O L F",
                        mediaType: 1,
                        renderLargerThumbnail: true,
                        thumbnail: await resize(thumb, 300, 175),
                        sourceUrl: websitex,
                        mediaUrl: thumb,
                    },
                    mentionedJid: sender,
                },
            }, {
                quoted: m
            }
        );  
        playerExit(chat, sender, ww);
    } else if (value === "delete") {
        if (!ww[chat]) return m.reply("Tidak ada sesi permainan");
        if (ww[chat].owner !== sender)
            return m.reply(
                `Hanya @${
            ww[chat].owner.split("@")[0]
          } yang dapat menghapus sesi permainan ini`
            );
        m.reply("Sesi permainan berhasil dihapus").then(() => {
            delete ww[chat];
        });
    } else if (value === "player") {
        if (!ww[chat]) return m.reply("Tidak ada sesi permainan");
        if (playerOnRoom(sender, chat, ww) === false)
            return m.reply("Kamu tidak dalam sesi permainan");
        if (ww[chat].player.length === 0)
            return m.reply("Sesi permainan belum memiliki player");
        let player = [];
        let text = "\n*⌂ W E R E W O L F - G A M E*\n\nLIST PLAYER:\n";
        for (let i = 0; i < ww[chat].player.length; i++) {
            text += `(${ww[chat].player[i].number}) @${ww[chat].player[i].id.replace(
          "@s.whatsapp.net",
          ""
        )} ${
          ww[chat].player[i].isdead === true
            ? `☠️ ${ww[chat].player[i].role}`
            : ""
        }\n`;
            player.push(ww[chat].player[i].id);
        }
        kayyoffc.sendMessage(
            m.chat, {
                text: text,
                contextInfo: {
                    externalAdReply: {
                        title: "W E R E W O L F",
                        mediaType: 1,
                        renderLargerThumbnail: true,
                        thumbnail: await resize(thumb, 300, 175),
                        sourceUrl: websitex,
                        mediaUrl: thumb,
                    },
                    mentionedJid: player,
                },
            }, {
                quoted: m
            }
        );
    } else {
    let text = `\n*⌂ W E R E W O L F - G A M E*\n\nPermainan Sosial Yang Berlangsung Dalam Beberapa Putaran/ronde. Para Pemain Dituntut Untuk Mencari Seorang Penjahat Yang Ada Dipermainan. Para Pemain Diberi Waktu, Peran, Serta Kemampuannya Masing-masing Untuk Bermain Permainan Ini\n\n*⌂ C O M M A N D*\n`;
        text += ` • ww create\n`;
        text += ` • ww join\n`;
        text += ` • ww start\n`;
        text += ` • ww exit\n`;
        text += ` • ww delete\n`;
        text += ` • ww player\n`;
        text += `\nPermainan ini dapat dimainkan oleh 5 sampai 15 orang.`;
        kayyoffc.sendMessage(
            m.chat, {
                text: text.trim(),
                contextInfo: {
                    externalAdReply: {
                        title: "W E R E W O L F",
                        mediaType: 1,
                        renderLargerThumbnail: true,
                        thumbnail: await resize(thumb, 300, 175),
                        sourceUrl: websitex,
                        mediaUrl: thumb,
                    },
                },
            }, {
                quoted: m
            }
        );
    }
}
breakresize                    mediaUrl: thumb,
                    },
                },
            }, {
                quoted: m
            }
        );
    }
}
break

case 'ttc': case 'ttt': case 'tictactoe': {
if (isBan) return m.reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
if (!isPrem && global.db.data.users[sender].limit < 1) return reply('Maaf Kak Limit Anda Habis Ingin Membeli Limit Ketik .buylimit')
             db.data.users[sender].limit -= 1 // -1 limit
                reply('1 Limit Anda Terpakai')
 let TicTacToe = require("./lib/tictactoe")
this.game = this.game ? this.game : {}
if (Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))) throw 'Kamu masih didalam game'
let room = Object.values(this.game).find(room => room.state === 'WAITING' && (text ? room.name === text : true))
if (room) {
m.reply('Partner ditemukan!')
room.o = from
room.game.playerO = m.sender
room.state = 'PLAYING'
let arr = room.game.render().map(v => {
return {
X: '❌',
O: '⭕',
1: '1️⃣',
2: '2️⃣',
3: '3️⃣',
4: '4️⃣',
5: '5️⃣',
6: '6️⃣',
7: '7️⃣',
8: '8️⃣',
9: '9️⃣',
}[v]
})
let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

Menunggu @${room.game.currentTurn.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
if (room.x !== room.o) await kayyoffc.sendText(room.x, str, m, { mentions: parseMention(str) } )
await kayyoffc.sendText(room.o, str, m, { mentions: parseMention(str) } )
} else {
room = {
id: 'tictactoe-' + (+new Date),
x: from,
o: '',
game: new TicTacToe(m.sender, 'o'),
state: 'WAITING'
}
if (text) room.name = text
m.reply('Menunggu partner' + (text ? ` mengetik command dibawah ini ${prefix}${command} ${text}` : ''))
this.game[room.id] = room
}
}
break
//=================================================//
case 'delttc': case 'delttt': {
if (isBan) return m.reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
if (!isPrem && global.db.data.users[sender].limit < 1) return reply('Maaf Kak Limit Anda Habis Ingin Membeli Limit Ketik .buylimit')
             db.data.users[sender].limit -= 1 // -1 limit
                reply('1 Limit Anda Terpakai')
 let roomnya = Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))
if (!roomnya) throw `Kamu sedang tidak berada di room tictactoe !`
delete this.game[roomnya.id]
m.reply(`Berhasil delete session room tictactoe !`)
}
break
//=================================================//
case 'suitpvp': case 'suit': {
if (isBan) return m.reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
if (!isPrem && global.db.data.users[sender].limit < 1) return reply('Maaf Kak Limit Anda Habis Ingin Membeli Limit Ketik .buylimit')
             db.data.users[sender].limit -= 1 // -1 limit
                reply('1 Limit Anda Terpakai')
this.suit = this.suit ? this.suit : {}
let poin = 10
let poin_lose = 10
let timeout = 60000
if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.sender))) m.reply(`Selesaikan suit mu yang sebelumnya`)
if (m.mentionedJid[0] === m.sender) return m.reply(`Tidak bisa bermain dengan diri sendiri !`)
if (!m.mentionedJid[0]) return m.reply(`_Siapa yang ingin kamu tantang?_\nTag orangnya..\n\nContoh : ${prefix}suit @${owner[1]}`, from, { mentions: [owner[1] + '@s.whatsapp.net'] })
if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.mentionedJid[0]))) throw `Orang yang kamu tantang sedang bermain suit bersama orang lain :(`
let id = 'suit_' + new Date() * 1
let caption = `_*SUIT PvP*_

@${m.sender.split`@`[0]} menantang @${m.mentionedJid[0].split`@`[0]} untuk bermain suit

Silahkan @${m.mentionedJid[0].split`@`[0]} untuk ketik terima/tolak`
this.suit[id] = {
chat: await kayyoffc.sendText(from, caption, m, { mentions: parseMention(caption) }),
id: id,
p: m.sender,
p2: m.mentionedJid[0],
status: 'wait',
waktu: setTimeout(() => {
if (this.suit[id]) kayyoffc.sendText(from, `_Waktu suit habis_`, m)
delete this.suit[id]
}, 60000), poin, poin_lose, timeout
}
}
break
//=================================================//
default:
if (budy.startsWith('=>')) {
if (!isCreator) return false
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return reply(bang)}
try {
reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
reply(String(e))}}
if (budy.startsWith('>')) {
if (!isCreator) return false
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
await reply(String(err))}}
if (budy.startsWith('$')) {
if(!isCreator) return false
exec(budy.slice(2), (err, stdout) => {
if(err) return reply(err)
if (stdout) return reply(stdout)})}

if ((budy.match) && ["Assalamualaikum", "assalamualaikum", "Assalamu'alaikum",].includes(budy) && !isCmd) {
reply(`*Waalaikummussalam warahmatullahi wabarokatuh*\n\n\n_📚 Baca yang dibawah ya!_
"Orang yang mengucapkan salam seperti ini maka ia mendapatkan 30 pahala, kemudian, orang yang dihadapan atau mendengarnya membalas dengan kalimat yang sama yaitu “Wa'alaikum salam warahmatullahi wabarakatuh atau ditambah dengan yang lain (waridhwaana). Artinya selain daripada do'a selamat juga meminta pada Allah SWT`)
}
        if ((budy.match) && ["kontol", "asu", "Anjing", "ngentod", "bokep", "kampret", "puki", "cukimay", "pukmak", "pukimak", "persetan", "kuda cuking", "kudacuking", "ngntd", "bangsat", "sinting", "Sinting", "Ngentod", "Kontol", "KOntol", "kntl", "Kntl", "K0ntol", "Asu", "Cuking", "Cukimay", "CukiMay", "Puki", "Kalomban", "Kuda Cuking"].includes(budy) && !isCmd) {

reply(`We pukik mak ${pushname} bicara itu yang sopan dong, demi nama baik karina - botsz, anda di harapkan untuk tidak mengatakan hal hal kotor lagi ingat itu ${m.sender.split()[0]}

`)

}
//=================================================//
if (isCmd && budy.toLowerCase() != undefined) {
if (from.endsWith('broadcast')) return
if (m.isBaileys) return
let msgs = global.db.data.database
if (!(budy.toLowerCase() in msgs)) return
kayyoffc.copyNForward(from, msgs[budy.toLowerCase()], true)}}
} catch (err) {
m.reply(util.format(err))}}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})
